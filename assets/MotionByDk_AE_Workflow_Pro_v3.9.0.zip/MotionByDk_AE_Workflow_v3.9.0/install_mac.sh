#!/usr/bin/env bash

# MotionByDk AEworkflow - macOS Installer (v3.9.0)
# Compatible with macOS Intel & Apple Silicon (M1/M2/M3/M4)

set -e

echo "========================================================================="
echo "             MOTIONBYDK AEWORKFLOW v3.9.0 INSTALLER (macOS)              "
echo "========================================================================="
echo ""

# 1. Enable PlayerDebugMode for all Adobe CSXS versions
echo "[1/4] Enabling PlayerDebugMode for Adobe CSXS versions..."
for v in 9 10 11 12 13 14 15 16 17; do
    defaults write "com.adobe.CSXS.${v}" PlayerDebugMode 1 2>/dev/null || true
    echo "  [+] Enabled com.adobe.CSXS.${v} PlayerDebugMode"
done
echo ""

# 2. Setup CEP extensions directory
CEP_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
TARGET_DIR="${CEP_DIR}/com.motionbydk.aeworkflow"
LEGACY_DIR="${CEP_DIR}/MotionByDk AE Workflow"

echo "[2/4] Cleaning previous / duplicate versions from CEP extensions..."
rm -rf "${LEGACY_DIR}" 2>/dev/null || true
rm -rf "${TARGET_DIR}" 2>/dev/null || true
rm -rf "/Library/Application Support/Adobe/CEP/extensions/MotionByDk AE Workflow" 2>/dev/null || true
rm -rf "/Library/Application Support/Adobe/CEP/extensions/com.motionbydk.aeworkflow" 2>/dev/null || true
echo "  [+] Purged old extension directories"

mkdir -p "${TARGET_DIR}"

# 3. Clean and Copy Core Extension Files
echo ""
echo "[3/4] Installing core extension components (CSXS, client, host, bin, extra_plugins)..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cp -R "${SCRIPT_DIR}/CSXS" "${TARGET_DIR}/"
echo "  [+] Copied CSXS directory"

cp -R "${SCRIPT_DIR}/client" "${TARGET_DIR}/"
echo "  [+] Copied client directory"

cp -R "${SCRIPT_DIR}/host" "${TARGET_DIR}/"
echo "  [+] Copied host directory"

if [ -d "${SCRIPT_DIR}/bin" ]; then
    cp -R "${SCRIPT_DIR}/bin" "${TARGET_DIR}/"
    echo "  [+] Copied bin directory"
fi

if [ -d "${SCRIPT_DIR}/extra_plugins" ]; then
    cp -R "${SCRIPT_DIR}/extra_plugins" "${TARGET_DIR}/"
    echo "  [+] Staged extra_plugins directory"
fi

if [ -f "${SCRIPT_DIR}/.debug" ]; then
    cp "${SCRIPT_DIR}/.debug" "${TARGET_DIR}/"
fi

# Clean any residual junk like .DS_Store from target
find "${TARGET_DIR}" -name ".DS_Store" -delete 2>/dev/null || true

# 4. Automatically Install Liquid Glass Plugin into Universal MediaCore & After Effects
SOURCE_PLUGIN=""
if [ -d "${SCRIPT_DIR}/extra_plugins/Mac/LiquidGlass/LiquidGlass.plugin" ]; then
    SOURCE_PLUGIN="${SCRIPT_DIR}/extra_plugins/Mac/LiquidGlass/LiquidGlass.plugin"
fi

if [ -n "${SOURCE_PLUGIN}" ]; then
    echo ""
    echo "[4/4] Installing Liquid Glass native plugin into Adobe MediaCore..."
    installed_count=0

    # A. Universal User MediaCore (Loaded automatically by After Effects & Premiere Pro)
    USER_MEDIACORE="$HOME/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore"
    mkdir -p "${USER_MEDIACORE}/LiquidGlass" 2>/dev/null || true
    rm -rf "${USER_MEDIACORE}/ToolsForMotion" 2>/dev/null || true
    rm -rf "${USER_MEDIACORE}/LiquidGlass/LiquidGlass.plugin" 2>/dev/null || true
    cp -R "${SOURCE_PLUGIN}" "${USER_MEDIACORE}/LiquidGlass/" 2>/dev/null || true
    xattr -dr com.apple.quarantine "${USER_MEDIACORE}/LiquidGlass/LiquidGlass.plugin" 2>/dev/null || true
    echo "  [+] Installed to Universal MediaCore: ${USER_MEDIACORE}/LiquidGlass/LiquidGlass.plugin"
    installed_count=$((installed_count + 1))

    # B. System-wide Universal MediaCore (if root / writable)
    SYS_MEDIACORE="/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore"
    if [ -w "${SYS_MEDIACORE}" ]; then
        mkdir -p "${SYS_MEDIACORE}/LiquidGlass" 2>/dev/null || true
        rm -rf "${SYS_MEDIACORE}/ToolsForMotion" 2>/dev/null || true
        rm -rf "${SYS_MEDIACORE}/LiquidGlass/LiquidGlass.plugin" 2>/dev/null || true
        cp -R "${SOURCE_PLUGIN}" "${SYS_MEDIACORE}/LiquidGlass/" 2>/dev/null || true
        xattr -dr com.apple.quarantine "${SYS_MEDIACORE}/LiquidGlass/LiquidGlass.plugin" 2>/dev/null || true
        echo "  [+] Installed to System MediaCore: ${SYS_MEDIACORE}/LiquidGlass/LiquidGlass.plugin"
        installed_count=$((installed_count + 1))
    fi

    # C. Individual After Effects Applications Plug-ins (Direct & Guaranteed)
    for ae_dir in /Applications/Adobe\ After\ Effects\ *; do
        if [ -d "${ae_dir}/Plug-ins" ]; then
            if [ -w "${ae_dir}/Plug-ins" ]; then
                mkdir -p "${ae_dir}/Plug-ins/LiquidGlass" 2>/dev/null || true
                cp -R "${SOURCE_PLUGIN}" "${ae_dir}/Plug-ins/LiquidGlass/" 2>/dev/null || true
                xattr -dr com.apple.quarantine "${ae_dir}/Plug-ins/LiquidGlass/LiquidGlass.plugin" 2>/dev/null || true
                echo "  [+] Installed directly into After Effects: ${ae_dir}/Plug-ins/LiquidGlass/LiquidGlass.plugin"
                installed_count=$((installed_count + 1))
            else
                echo "  [i] Requesting admin permission to install directly into: ${ae_dir}/Plug-ins..."
                osascript -e "do shell script \"mkdir -p '${ae_dir}/Plug-ins/LiquidGlass' && cp -R '${SOURCE_PLUGIN}' '${ae_dir}/Plug-ins/LiquidGlass/' && xattr -dr com.apple.quarantine '${ae_dir}/Plug-ins/LiquidGlass/LiquidGlass.plugin'\" with administrator privileges" 2>/dev/null || true
                if [ -d "${ae_dir}/Plug-ins/LiquidGlass/LiquidGlass.plugin" ]; then
                    echo "  [+] Installed directly into After Effects: ${ae_dir}/Plug-ins/LiquidGlass/LiquidGlass.plugin"
                    installed_count=$((installed_count + 1))
                fi
            fi
        fi
    done

    echo "  [✓] Liquid Glass native plugin installed successfully (${installed_count} location)!"

    # 5. Flush After Effects PluginCache registry so AE re-indexes the new plugin immediately
    echo ""
    echo "[+] Refreshing After Effects plugin registry cache..."
    IFS=$'\n'
    for d in $(defaults domains 2>/dev/null | tr ',' '\n' | grep -i 'After Effects'); do
        d="$(echo "$d" | xargs)"
        [ -n "$d" ] && defaults delete "$d" PluginCache 2>/dev/null || true
    done
    unset IFS
fi

echo ""
echo "========================================================================="
echo "                        INSTALLATION COMPLETED!                          "
echo "========================================================================="
echo ""
echo "MotionByDk AE Workflow v3.9.0 installed cleanly."
echo "Old duplicate versions have been completely removed."
echo "Liquid Glass native plugin installed successfully into MediaCore."
echo ""
echo "IMPORTANT NEXT STEPS:"
echo "  1. Restart Adobe After Effects."
echo "  2. Go to: After Effects > Settings/Preferences > Scripting & Expressions"
echo "  3. CHECK: [✔] 'Allow Scripts to Write Files and Access Network'"
echo "  4. Open: Window > Extensions > MotionByDk AEworkflow"
echo ""
echo "For any help: motionbydk@gmail.com"
echo "========================================================================="
echo ""
