@echo off
setlocal enabledelayedexpansion

title MotionByDk AEworkflow v3.9.0 - Windows Installer
color 06

:: Self-elevation to Administrator so Liquid Glass copies cleanly to Program Files / MediaCore
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [i] Requesting Administrator privileges to install AE Plug-ins...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo =========================================================================
echo             MOTIONBYDK AEWORKFLOW v3.9.0 INSTALLER (WINDOWS)
echo =========================================================================
echo.

:: 1. Enable PlayerDebugMode across Adobe CSXS versions
echo [1/4] Enabling PlayerDebugMode in Windows Registry...
for %%v in (9 10 11 12 13 14 15 16 17) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    reg add "HKLM\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    echo   [+] Enabled CSXS.%%v PlayerDebugMode
)
echo.

:: 2. Target Directory Setup and Legacy Purge
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionbydk.aeworkflow"
set "LEGACY_DIR=%APPDATA%\Adobe\CEP\extensions\MotionByDk AE Workflow"

echo [2/4] Removing previous / duplicate extension versions...
if exist "%LEGACY_DIR%" (
    rmdir /S /Q "%LEGACY_DIR%" 2>nul
    echo   [+] Purged legacy directory: "%LEGACY_DIR%"
)
if exist "%TARGET_DIR%" (
    rmdir /S /Q "%TARGET_DIR%" 2>nul
    echo   [+] Cleaned target directory: "%TARGET_DIR%"
)
if exist "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\MotionByDk AE Workflow" (
    rmdir /S /Q "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\MotionByDk AE Workflow" 2>nul
)
if exist "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" (
    rmdir /S /Q "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" 2>nul
)
if exist "%CommonProgramFiles%\Adobe\CEP\extensions\MotionByDk AE Workflow" (
    rmdir /S /Q "%CommonProgramFiles%\Adobe\CEP\extensions\MotionByDk AE Workflow" 2>nul
)
if exist "%CommonProgramFiles%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" (
    rmdir /S /Q "%CommonProgramFiles%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" 2>nul
)

mkdir "%TARGET_DIR%" 2>nul

:: 3. Copy Core Extension Files
echo.
echo [3/4] Installing core extension files (CSXS, client, host, bin, extra_plugins)...
set "SOURCE_DIR=%~dp0"

:: Copy CSXS folder
mkdir "%TARGET_DIR%\CSXS" 2>nul
xcopy "%SOURCE_DIR%CSXS" "%TARGET_DIR%\CSXS\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied CSXS directory

:: Copy client folder
mkdir "%TARGET_DIR%\client" 2>nul
xcopy "%SOURCE_DIR%client" "%TARGET_DIR%\client\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied client directory

:: Copy host folder
mkdir "%TARGET_DIR%\host" 2>nul
xcopy "%SOURCE_DIR%host" "%TARGET_DIR%\host\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied host directory

:: Copy bin folder
if exist "%SOURCE_DIR%bin" (
    mkdir "%TARGET_DIR%\bin" 2>nul
    xcopy "%SOURCE_DIR%bin" "%TARGET_DIR%\bin\" /E /I /Y /Q >nul 2>&1
    echo   [+] Copied bin directory
)

:: Copy extra_plugins folder
if exist "%SOURCE_DIR%extra_plugins" (
    mkdir "%TARGET_DIR%\extra_plugins" 2>nul
    xcopy "%SOURCE_DIR%extra_plugins" "%TARGET_DIR%\extra_plugins\" /E /I /Y /Q >nul 2>&1
    echo   [+] Staged extra_plugins directory
)

:: 4. Automatically Install Liquid Glass Plugin
set "SOURCE_AEX="
if exist "%SOURCE_DIR%extra_plugins\Windows\LiquidGlass\LiquidGlass.aex" (
    set "SOURCE_AEX=%SOURCE_DIR%extra_plugins\Windows\LiquidGlass\LiquidGlass.aex"
) else if exist "%SOURCE_DIR%extra_plugins\Windows\ToolsForMotion\LiquidGlass.aex" (
    set "SOURCE_AEX=%SOURCE_DIR%extra_plugins\Windows\ToolsForMotion\LiquidGlass.aex"
)

if defined SOURCE_AEX (
    echo.
    echo [4/4] Installing Liquid Glass native plugin to After Effects ^& MediaCore...
    set "INSTALLED_COUNT=0"

    :: Universal MediaCore 64-bit
    set "MEDIACORE_DIR=%CommonProgramFiles%\Adobe\Common\Plug-ins\7.0\MediaCore\LiquidGlass"
    if exist "%CommonProgramFiles%\Adobe\Common\Plug-ins\7.0\MediaCore\ToolsForMotion" (
        rmdir /S /Q "%CommonProgramFiles%\Adobe\Common\Plug-ins\7.0\MediaCore\ToolsForMotion" 2>nul
    )
    if not exist "!MEDIACORE_DIR!" mkdir "!MEDIACORE_DIR!" 2>nul
    copy /Y "!SOURCE_AEX!" "!MEDIACORE_DIR!\LiquidGlass.aex" >nul 2>&1
    if exist "!MEDIACORE_DIR!\LiquidGlass.aex" (
        echo   [+] Installed to Universal MediaCore: "!MEDIACORE_DIR!"
        set /a INSTALLED_COUNT+=1
    )

    :: Individual After Effects application installations
    for /d %%D in ("%ProgramFiles%\Adobe\Adobe After Effects *") do (
        if exist "%%D\Support Files\Plug-ins" (
            if exist "%%D\Support Files\Plug-ins\ToolsForMotion" (
                rmdir /S /Q "%%D\Support Files\Plug-ins\ToolsForMotion" 2>nul
            )
            if not exist "%%D\Support Files\Plug-ins\LiquidGlass" mkdir "%%D\Support Files\Plug-ins\LiquidGlass" 2>nul
            copy /Y "!SOURCE_AEX!" "%%D\Support Files\Plug-ins\LiquidGlass\LiquidGlass.aex" >nul 2>&1
            if exist "%%D\Support Files\Plug-ins\LiquidGlass\LiquidGlass.aex" (
                echo   [+] Installed to: "%%D\Support Files\Plug-ins\LiquidGlass"
                set /a INSTALLED_COUNT+=1
            )
        )
    )

    if !INSTALLED_COUNT! gtr 0 (
        echo   [OK] Liquid Glass native plugin installed successfully into !INSTALLED_COUNT! location(s)!
    )

    :: Refresh After Effects PluginCache in Windows Registry
    for /f "tokens=*" %%K in ('reg query "HKCU\Software\Adobe\After Effects" 2^>nul ^| findstr /i "After Effects"') do (
        reg delete "%%K\PluginCache" /f >nul 2>&1
    )
)

echo.
echo =========================================================================
echo                        INSTALLATION COMPLETED!
echo =========================================================================
echo.
echo MotionByDk AE Workflow v3.9.0 installed cleanly into Adobe CEP extensions.
echo Old duplicate versions have been completely removed.
echo Liquid Glass native plugin has been placed into After Effects Plug-ins.
echo.
echo IMPORTANT NEXT STEPS:
echo   1. Open Adobe After Effects.
echo   2. Go to: Edit ^> Preferences ^> Scripting ^& Expressions
echo   3. CHECK: [X] "Allow Scripts to Write Files and Access Network"
echo   4. Go to: Window ^> Extensions ^> MotionByDk AEworkflow
echo.
echo For any help or queries: motionbydk@gmail.com
echo Enjoy your motion design workflow!
echo =========================================================================
echo.
pause
