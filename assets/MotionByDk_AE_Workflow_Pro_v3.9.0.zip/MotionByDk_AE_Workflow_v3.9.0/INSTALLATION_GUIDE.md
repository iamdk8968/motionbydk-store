# 🛠️ MotionByDk AEworkflow Pro v3.9.0 - Complete Installation Guide
### *Compatible with Windows 10/11 & macOS (Intel & Apple Silicon M1/M2/M3/M4)*
### *Supports Adobe After Effects CC 2019, 2020, 2021, 2022, 2023, 2024, 2025 & 2026+*

---

## 📌 Table of Contents
1. [📦 Method 1: Install via .ZXP File (Recommended & Easiest)](#-method-1-install-via-zxp-file-recommended--easiest)
2. [⚡ Method 2: Automated 1-Click Script Setup (Alternative)](#-quick-start-automated-1-click-setup)
3. [🌊 Liquid Glass Native C++ Plugin (1-Click Universal Install)](#-liquid-glass-native-plugin-1-click-universal-install)
4. [🪟 Windows Manual Installation](#-windows-manual-installation)
5. [🍎 macOS Manual Installation](#-macos-manual-installation)
6. [⚙️ Mandatory After Effects Preference Setting](#️-mandatory-after-effects-preference-setting)
7. [🚀 How to Launch the Extension in After Effects](#-how-to-launch-the-extension-in-after-effects)
8. [❓ Troubleshooting & FAQ](#-troubleshooting--faq)

---

## 📦 Method 1: Install via .ZXP File (Recommended & Easiest)

New users ke liye sabse aasaan tarika `.zxp` file se install karna hai:

1. **Free ZXP Installer Download Karein** (agar pehle se installed nahi hai):
   - **aescripts + aeplugins ZXP Installer:** [https://aescripts.com/learn/zxp-installer/](https://aescripts.com/learn/zxp-installer/)
   - *(Ya Anastasiy's Extension Manager: [https://install.anastasiy.com/](https://install.anastasiy.com/))*
2. **`.zxp` File Drag & Drop Karein:**
   - Is folder ke andar maujood **`MotionByDk_AE_Workflow_v3.9.0.zxp`** file ko ZXP Installer window me drag-and-drop karein (ya `File > Open` se select karein).
   - Agar self-signed certificate ka prompt aaye, to **Continue / Install** click karein.
   - Jab **`MotionByDk AE Workflow`** installed show ho jaye, ZXP Installer close kar dein.
3. **Liquid Glass Native Effect (1-Click Auto Install):**
   - Panel open karne par About section me ya `LIQUID GLASS` button par click karne par plugin 1-click me bina kisi manual copy-paste ke Adobe MediaCore me install ho jayega.
4. Niche **[Mandatory After Effects Preference Setting](#️-mandatory-after-effects-preference-setting)** enable karein aur After Effects restart karke `Window > Extensions > MotionByDk AEworkflow` open karein!

---

## ⚡ Quick Start (Automated 1-Click Setup)

Agar aap ZXP installer ke bina direct 1-click install karna chahte hain, to is folder me automated setup scripts di gayi hain jo extension ke sath-sath **Liquid Glass Native Plugin** ko bhi directly Adobe MediaCore me install kar deti hain:

### 🪟 Windows User (1-Click Setup):
1. **`install_windows.bat`** file par right-click karke **"Run as administrator"** select karein (ya double-click karein, script automatically UAC elevation maang legi).
2. Script automatically:
   - `PlayerDebugMode` registry keys enable karegi.
   - Extension ko `%APPDATA%\Adobe\CEP\extensions\` me cleanly stage karegi.
   - **Liquid Glass native plugin (`LiquidGlass.aex`)** ko Universal Adobe MediaCore aur AE Plug-ins me 1-click me install kar degi.
3. After Effects restart karein aur enjoy karein!

### 🍎 macOS User (1-Click Setup):
1. **Terminal** open karein aur is folder me script run karein:
   ```bash
   chmod +x install_mac.sh
   ./install_mac.sh
   ```
2. Script automatically:
   - `PlayerDebugMode` enable kar degi (CSXS.9 se CSXS.17 tak).
   - Extension ko `~/Library/Application Support/Adobe/CEP/extensions/` me install karegi.
   - **Liquid Glass native plugin (`LiquidGlass.plugin`)** ko Universal User MediaCore me install karke macOS quarantine flag remove kar degi (zero password prompt!).
3. After Effects restart karein aur enjoy karein!

---

## 🌊 Liquid Glass Native Plugin (1-Click Universal Install)

Liquid Glass ek C++ native effect hai jo high-end organic water refraction, chromatic dispersion aur prism glass simulation provide karta hai.

**v3.9.0 me 3 foolproof install methods hain:**
1. **In-Panel 1-Click Install:** After Effects me panel open karke **MotionByDk (About)** tab me jayein, waha **"⚡ 1-Click Install Liquid Glass"** button par click karein. Plugin turant install ho jayega!
2. **Setup Script:** `install_mac.sh` (Mac) ya `install_windows.bat` (Win) chalayein.
3. **Manual Copy:**
   - **Mac:** `extra_plugins/Mac/LiquidGlass/LiquidGlass.plugin` ko copy karein `~/Library/Application Support/Adobe/Common/Plug-ins/7.0/MediaCore/LiquidGlass/` me.
   - **Windows:** `extra_plugins/Windows/LiquidGlass/LiquidGlass.aex` ko copy karein `C:\Program Files\Common Files\Adobe\Common\Plug-ins\7.0\MediaCore\LiquidGlass\` me.

---

## 🪟 Windows Manual Installation

Agar aap manually install karna chahte hain, to in 3 simple steps ko follow karein:

### Step 1: Copy Core Plugin Files to Adobe CEP Directory
1. Apne keyboard par **`Win + R`** dabayein (Run dialog box open hoga).
2. Niche diye gaye path ko paste karein aur **Enter** dabayein:
   ```text
   %APPDATA%\Adobe\CEP\extensions
   ```
   *(Full Path: `C:\Users\<YourUsername>\AppData\Roaming\Adobe\CEP\extensions\`)*
   > **Note:** Agar `CEP` ya `extensions` folder nahi bana hai, to waha naya folder bana kar uska naam `CEP` aur uske andar `extensions` rakh dein.
3. Is `extensions` folder ke andar ek naya folder banayein: **`MotionByDk AE Workflow`**.
4. Uske andar sirf yeh **4 zaroori items** copy karein:
   - 📁 **`CSXS`** (folder)
   - 📁 **`client`** (folder)
   - 📁 **`host`** (folder)
   - 📄 **`.debug`** (file)
   > 💡 **Tip:** Agar aap `install_windows.bat` run karte hain to yeh files automatically bina kisi extra doc/script file ke cleanly copy ho jati hain!

---

### Step 2: Enable PlayerDebugMode (Registry Setup)
Third-party / custom CEP panels ko After Effects me run karne ke liye `PlayerDebugMode` enable karna zaroori hota hai:

#### Option A: Quick Command Prompt (Fastest)
1. Windows Start Menu me **CMD** type karein, right-click karein aur **"Run as Administrator"** select karein.
2. Niche di gayi lines ko copy karke paste karein aur Enter dabayein:
   ```cmd
   reg add "HKCU\Software\Adobe\CSXS.9" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.13" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.14" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.15" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.16" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\Software\Adobe\CSXS.17" /v PlayerDebugMode /t REG_SZ /d 1 /f
   ```

#### Option B: Via Registry Editor (Manual)
1. **`Win + R`** dabayein, `regedit` type karein aur **OK** karein.
2. Is path par jayein: `HKEY_CURRENT_USER\Software\Adobe\`
3. Har `CSXS.9`, `CSXS.10`, `CSXS.11`, `CSXS.12`, `CSXS.13`, `CSXS.14`, `CSXS.15`, `CSXS.16`, `CSXS.17` folder ke andar:
   - Right-click karein -> **New > String Value**.
   - Name dein: `PlayerDebugMode`
   - Double-click karein aur Value me `1` likh kar Save karein.

---

## 🍎 macOS Manual Installation

macOS par install karne ke liye in steps ko follow karein:

### Step 1: Copy Core Plugin Files to Adobe CEP Directory
1. **Finder** open karein.
2. Top menu se **Go > Go to Folder...** par click karein (ya keyboard shortcut **`Cmd + Shift + G`** dabayein).
3. Yeh path paste karein aur **Enter** karein:
   ```text
   ~/Library/Application Support/Adobe/CEP/extensions/
   ```
   > **Note:** Agar `CEP` ya `extensions` folder nahi hai, to manually `CEP` folder aur uske andar `extensions` folder create kar lein.
4. Is `extensions` folder ke andar ek naya folder banayein: **`MotionByDk AE Workflow`**.
5. Uske andar sirf yeh **4 zaroori items** copy karein:
   - 📁 **`CSXS`** (folder)
   - 📁 **`client`** (folder)
   - 📁 **`host`** (folder)
   - 📄 **`.debug`** (file)
   > 💡 **Tip:** Terminal me `./install_mac.sh` run karne par yeh files automatically bina kisi extra file ke link/copy ho jati hain!

---

### Step 2: Enable PlayerDebugMode (Terminal Command)
1. Mac par **Terminal** application open karein (Spotlight Search: `Cmd + Space` -> type `Terminal`).
2. Niche di gayi commands ko copy karke Terminal me paste karein aur **Enter** dabayein:
   ```bash
   defaults write com.adobe.CSXS.9 PlayerDebugMode 1
   defaults write com.adobe.CSXS.10 PlayerDebugMode 1
   defaults write com.adobe.CSXS.11 PlayerDebugMode 1
   defaults write com.adobe.CSXS.12 PlayerDebugMode 1
   defaults write com.adobe.CSXS.13 PlayerDebugMode 1
   defaults write com.adobe.CSXS.14 PlayerDebugMode 1
   defaults write com.adobe.CSXS.15 PlayerDebugMode 1
   defaults write com.adobe.CSXS.16 PlayerDebugMode 1
   defaults write com.adobe.CSXS.17 PlayerDebugMode 1
   ```

---

## ⚙️ Mandatory After Effects Preference Setting
**Is setting ko enable karna zaroori hai**, warna After Effects scripts ko timeline aur layers modify karne ki permission nahi deta:

1. **Adobe After Effects** open karein.
2. Preferences open karein:
   - **Windows:** `Edit` > `Preferences` > `Scripting & Expressions...`
   - **macOS:** `After Effects` > `Settings` (ya `Preferences`) > `Scripting & Expressions...`
3. Is checkbox ko tick (check) karein:
   - **`[✔] Allow Scripts to Write Files and Access Network`**
4. **OK** par click karein.

---

## 🚀 How to Launch the Extension in After Effects

1. Agar After Effects pehle se open tha, to usse **band karke dubara restart karein**.
2. Top Menu bar me jayein:
   ```text
   Window > Extensions > MotionByDk AEworkflow
   ```
3. Extension ka sleek orange & black panel screen par open ho jayega.
4. Panel ko drag karke apne After Effects workspace me kahi bhi **dock** kar sakte hain (jaise right-side inspector ya timeline ke paas).

---

## ❓ Troubleshooting & FAQ

### Q1: `Window > Extensions` me "MotionByDk AEworkflow" show nahi ho raha hai?
- **Check 1:** Ensure karein ki aapne folder sahi directory me dala hai:
  - Windows: `%APPDATA%\Adobe\CEP\extensions\`
  - Mac: `~/Library/Application Support/Adobe/CEP/extensions/`
- **Check 2:** Check karein ki folder structure direct hai, yaani `MotionByDk AE Workflow` ke andar seedha `CSXS`, `client`, `host` folders hone chahiye (kisi extra subfolder ke andar nahi hona chahiye).
- **Check 3:** After Effects ko close karke completely restart karein.

### Q2: Click karne par panel open to hota hai par blank/black screen dikhti hai?
- Ensure karein ki `PlayerDebugMode` step sahi se run hua hai:
  - Windows par registry value `PlayerDebugMode = 1` set honi chahiye.
  - Mac par Terminal me `defaults write com.adobe.CSXS.<version> PlayerDebugMode 1` execute hona chahiye.

### Q3: Button click karne par error aata hai "Script is not allowed to write files"?
- After Effects ki Preferences me jayein: `Preferences > Scripting & Expressions` -> Check **"Allow Scripts to Write Files and Access Network"** -> Click OK.

### Q4: Kya internet connection required hai is extension ke liye?
- **Nahi!** MotionByDk AEworkflow 100% offline aur standalone bundle hai. Isme sare icons, scripts aur generators locally offline work karte hain.

---

## 📬 Need Help or Support?
Agar installation ya plugin use karne me koi bhi issue aaye, to contact karein:
- **Email:** [motionbydk@gmail.com](mailto:motionbydk@gmail.com)
- **Developer:** Motion by DK

---

*MotionByDk Studio &bull; Designed for Professional Motion Designers*
