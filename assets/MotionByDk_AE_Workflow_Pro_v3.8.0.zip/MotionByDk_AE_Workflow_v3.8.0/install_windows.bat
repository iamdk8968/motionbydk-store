@echo off
setlocal enabledelayedexpansion

title MotionByDk AEworkflow v3.8.0 - Windows Installer
color 06

echo =========================================================================
echo             MOTIONBYDK AEWORKFLOW v3.8.0 INSTALLER (WINDOWS)
echo =========================================================================
echo.

:: 1. Enable PlayerDebugMode across Adobe CSXS versions
echo [1/4] Enabling PlayerDebugMode in Windows Registry...
for %%v in (9 10 11 12 13 14 15 16 17) do (
    reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
    if !errorlevel! equ 0 (
        echo   [+] Enabled CSXS.%%v PlayerDebugMode
    )
)
echo.

:: 2. Target Directory Setup and Legacy Purge
set "TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\com.motionbydk.aeworkflow"
set "LEGACY_DIR=%APPDATA%\Adobe\CEP\extensions\MotionByDk AE Workflow"

echo [2/4] Removing previous / duplicate extension versions...
if exist "%LEGACY_DIR%" (
    rmdir /S /Q "%LEGACY_DIR%" 2>nul
    echo   [+] Purged legacy directory: "%LEGACY_DIR%"
)
if exist "%TARGET_DIR%" (
    rmdir /S /Q "%TARGET_DIR%" 2>nul
    echo   [+] Cleaned target directory: "%TARGET_DIR%"
)
if exist "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\MotionByDk AE Workflow" (
    rmdir /S /Q "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\MotionByDk AE Workflow" 2>nul
)
if exist "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" (
    rmdir /S /Q "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\com.motionbydk.aeworkflow" 2>nul
)

mkdir "%TARGET_DIR%" 2>nul

:: 3. Copy Core Extension Files
echo.
echo [3/4] Installing core extension files (CSXS, client, host, bin)...
set "SOURCE_DIR=%~dp0"

:: Copy CSXS folder
mkdir "%TARGET_DIR%\CSXS" 2>nul
xcopy "%SOURCE_DIR%CSXS" "%TARGET_DIR%\CSXS\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied CSXS directory

:: Copy client folder
mkdir "%TARGET_DIR%\client" 2>nul
xcopy "%SOURCE_DIR%client" "%TARGET_DIR%\client\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied client directory

:: Copy host folder
mkdir "%TARGET_DIR%\host" 2>nul
xcopy "%SOURCE_DIR%host" "%TARGET_DIR%\host\" /E /I /Y /Q >nul 2>&1
echo   [+] Copied host directory

:: Copy bin folder
if exist "%SOURCE_DIR%bin" (
    mkdir "%TARGET_DIR%\bin" 2>nul
    xcopy "%SOURCE_DIR%bin" "%TARGET_DIR%\bin\" /E /I /Y /Q >nul 2>&1
    echo   [+] Copied bin directory
)

:: 4. Automatically Install Liquid Glass Plugin
if exist "%SOURCE_DIR%extra_plugins\Windows\ToolsForMotion\LiquidGlass.aex" (
    echo.
    echo [4/4] Installing Liquid Glass native plugin to After Effects...
    for /d %%D in ("%ProgramFiles%\Adobe\Adobe After Effects *") do (
        if exist "%%D\Support Files\Plug-ins" (
            echo   [+] Installing Liquid Glass to: "%%D\Support Files\Plug-ins\ToolsForMotion"
            if not exist "%%D\Support Files\Plug-ins\ToolsForMotion" mkdir "%%D\Support Files\Plug-ins\ToolsForMotion" 2>nul
            copy /Y "%SOURCE_DIR%extra_plugins\Windows\ToolsForMotion\LiquidGlass.aex" "%%D\Support Files\Plug-ins\ToolsForMotion\LiquidGlass.aex" >nul 2>&1
        )
    )
)

echo.
echo =========================================================================
echo                        INSTALLATION COMPLETED!
echo =========================================================================
echo.
echo MotionByDk AE Workflow v3.8.0 installed cleanly into Adobe CEP extensions.
echo Old duplicate versions have been completely removed.
echo Liquid Glass native plugin has been placed into After Effects Plug-ins.
echo.
echo IMPORTANT NEXT STEPS:
echo   1. Open Adobe After Effects.
echo   2. Go to: Edit ^> Preferences ^> Scripting ^& Expressions
echo   3. CHECK: [X] "Allow Scripts to Write Files and Access Network"
echo   4. Go to: Window ^> Extensions ^> MotionByDk AEworkflow
echo.
echo For any help or queries: motionbydk@gmail.com
echo Enjoy your motion design workflow!
echo =========================================================================
echo.
pause
