/**
 * MotionByDk Pro Features - ExtendScript Engine
 * Author: MotionByDk (Dhananjay K.)
 * Features:
 *   - Keyframe Temporal Ease Capture & Paste (EaseCopy)
 *   - Keyframe Timing Inversion (Reverse Animation)
 *   - Active Layer/Comp Diagnostics
 */

(function() {
    var _mdkPro = (typeof $._MDK_PRO !== "undefined" && $._MDK_PRO) ? $._MDK_PRO : {};
    var _clipboardEase = null;

    function _getActiveComp() {
        if (!app.project) return null;
        var comp = app.project.activeItem;
        if (comp && comp instanceof CompItem) return comp;
        try {
            if (app.activeViewer && typeof app.activeViewer.setActive === "function") {
                app.activeViewer.setActive();
            }
        } catch(e) {}
        comp = app.project.activeItem;
        if (comp && comp instanceof CompItem) return comp;
        for (var i = 1; i <= app.project.numItems; i++) {
            var item = app.project.item(i);
            if (item instanceof CompItem) return item;
        }
        return null;
    }

    function _getSelectedKeyProperties(comp) {
        var out = [];
        if (!comp) return out;
        var selLayers = comp.selectedLayers;
        for (var i = 0; i < selLayers.length; i++) {
            var layer = selLayers[i];
            _walkProps(layer, function(p) {
                try {
                    if (p.numKeys > 0 && p.selectedKeys && p.selectedKeys.length > 0) {
                        out.push(p);
                    }
                } catch(e) {}
            });
        }
        return out;
    }

    function _walkProps(container, callback) {
        try {
            var n = container.numProperties;
            for (var i = 1; i <= n; i++) {
                var prop = container.property(i);
                if (prop.propertyType === PropertyType.PROPERTY) {
                    callback(prop);
                } else if (prop.propertyType === PropertyType.INDEXED_GROUP || prop.propertyType === PropertyType.NAMED_GROUP) {
                    _walkProps(prop, callback);
                }
            }
        } catch(e) {}
    }

    // 1. CAPTURE EASE FROM FIRST SELECTED KEYFRAME
    _mdkPro.copyEase = function() {
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            
            var props = _getSelectedKeyProperties(comp);
            if (!props.length) return JSON.stringify({ ok: false, error: "Please select at least one keyframe in the timeline." });

            var prop = props[0];
            var keys = prop.selectedKeys;
            if (!keys || !keys.length) return JSON.stringify({ ok: false, error: "No keyframe selected." });

            var keyIndex = keys[0];
            var inEase = prop.keyInTemporalEase(keyIndex);
            var outEase = prop.keyOutTemporalEase(keyIndex);
            var inInterp = prop.keyInInterpolationType(keyIndex);
            var outInterp = prop.keyOutInterpolationType(keyIndex);

            var packedIn = [];
            for (var i = 0; i < inEase.length; i++) {
                packedIn.push({ speed: inEase[i].speed, influence: inEase[i].influence });
            }

            var packedOut = [];
            for (var j = 0; j < outEase.length; j++) {
                packedOut.push({ speed: outEase[j].speed, influence: outEase[j].influence });
            }

            _clipboardEase = {
                propName: prop.name,
                inEase: packedIn,
                outEase: packedOut,
                inInterp: inInterp,
                outInterp: outInterp
            };

            var avgInInf = packedIn.length ? packedIn[0].influence : 33;
            var avgOutInf = packedOut.length ? packedOut[0].influence : 33;

            return JSON.stringify({
                ok: true,
                count: 1,
                prop: prop.name,
                inInfluence: Math.round(avgInInf),
                outInfluence: Math.round(avgOutInf),
                msg: "Ease copied from keyframe (" + prop.name + ")"
            });
        } catch(err) {
            return JSON.stringify({ ok: false, error: "Copy Ease Error: " + err.toString() });
        }
    };

    // 2. PASTE EASE TO ALL CURRENTLY SELECTED KEYFRAMES
    _mdkPro.pasteEase = function(continuous) {
        try {
            if (!_clipboardEase) {
                return JSON.stringify({ ok: false, error: "Clipboard empty. Please copy an ease first!" });
            }

            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });

            var props = _getSelectedKeyProperties(comp);
            if (!props.length) return JSON.stringify({ ok: false, error: "Please select target keyframes to paste ease onto." });

            var changed = 0;
            app.beginUndoGroup("MotionByDk Paste Ease");

            for (var p = 0; p < props.length; p++) {
                var prop = props[p];
                var keys = prop.selectedKeys;
                if (!keys || !keys.length) continue;

                var isSpatial = false;
                try { isSpatial = !!prop.isSpatial; } catch(e0) {}

                for (var k = 0; k < keys.length; k++) {
                    var keyIndex = keys[k];
                    try {
                        var curIn = prop.keyInTemporalEase(keyIndex);
                        var curOut = prop.keyOutTemporalEase(keyIndex);
                        var dim = curIn ? curIn.length : 1;

                        var newIn = [];
                        for (var d1 = 0; d1 < dim; d1++) {
                            var srcIn = _clipboardEase.inEase[Math.min(d1, _clipboardEase.inEase.length - 1)];
                            newIn.push(new KeyframeEase(srcIn.speed, srcIn.influence));
                        }

                        var newOut = [];
                        for (var d2 = 0; d2 < dim; d2++) {
                            var srcOut = _clipboardEase.outEase[Math.min(d2, _clipboardEase.outEase.length - 1)];
                            newOut.push(new KeyframeEase(srcOut.speed, srcOut.influence));
                        }

                        if (_clipboardEase.inInterp !== null && _clipboardEase.outInterp !== null) {
                            try { prop.setInterpolationTypeAtKey(keyIndex, _clipboardEase.inInterp, _clipboardEase.outInterp); } catch(e1) {}
                        }

                        prop.setTemporalAutoBezierAtKey(keyIndex, false);
                        prop.setTemporalContinuousAtKey(keyIndex, false);
                        prop.setTemporalEaseAtKey(keyIndex, newIn, newOut);

                        if (continuous && keyIndex > 1 && keyIndex < prop.numKeys) {
                            try { prop.setTemporalContinuousAtKey(keyIndex, true); } catch(e2) {}
                        }

                        changed++;
                    } catch(itemErr) {}
                }
            }

            app.endUndoGroup();

            if (changed === 0) {
                return JSON.stringify({ ok: false, error: "Could not apply ease to selected properties." });
            }

            return JSON.stringify({
                ok: true,
                count: changed,
                msg: "Applied ease to " + changed + " keyframe" + (changed > 1 ? "s" : "") + "!"
            });
        } catch(err) {
            try { app.endUndoGroup(); } catch(e) {}
            return JSON.stringify({ ok: false, error: "Paste Ease Error: " + err.toString() });
        }
    };

    // 3. INVERT TIMING OF SELECTED KEYFRAMES (REVERSE ANIMATION)
    _mdkPro.invertKeyframes = function() {
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });

            var props = _getSelectedKeyProperties(comp);
            if (!props.length) return JSON.stringify({ ok: false, error: "Please select keyframes to invert." });

            app.beginUndoGroup("MotionByDk Invert Keyframes");

            var totalCount = 0;
            for (var p = 0; p < props.length; p++) {
                var prop = props[p];
                var keys = prop.selectedKeys;
                if (!keys || keys.length < 2) continue;

                var keyData = [];
                for (var i = 0; i < keys.length; i++) {
                    var idx = keys[i];
                    keyData.push({
                        time: prop.keyTime(idx),
                        val: prop.keyValue(idx),
                        inEase: prop.keyInTemporalEase(idx),
                        outEase: prop.keyOutTemporalEase(idx),
                        inInterp: prop.keyInInterpolationType(idx),
                        outInterp: prop.keyOutInterpolationType(idx)
                    });
                }

                // Invert times relative to span
                var minTime = keyData[0].time;
                var maxTime = keyData[keyData.length - 1].time;
                var span = maxTime - minTime;

                // Remove old keyframes from highest index to lowest
                for (var d = keys.length - 1; d >= 0; d--) {
                    prop.removeKey(keys[d]);
                }

                // Add inverted keyframes
                for (var j = 0; j < keyData.length; j++) {
                    var orig = keyData[j];
                    var newTime = minTime + (maxTime - orig.time);
                    var newIdx = prop.addKey(newTime);
                    prop.setValueAtKey(newIdx, orig.val);
                    // Invert In and Out ease
                    try {
                        prop.setInterpolationTypeAtKey(newIdx, orig.outInterp, orig.inInterp);
                        prop.setTemporalEaseAtKey(newIdx, orig.outEase, orig.inEase);
                    } catch(e) {}
                    totalCount++;
                }
            }

            app.endUndoGroup();

            return JSON.stringify({
                ok: true,
                count: totalCount,
                msg: "Inverted " + totalCount + " keyframes successfully!"
            });
        } catch(err) {
            try { app.endUndoGroup(); } catch(e) {}
            return JSON.stringify({ ok: false, error: "Invert Error: " + err.toString() });
        }
    };

    // 3. PERSISTENT TRIAL DISK STORAGE (Protects against browser cache/reinstall resets)
    _mdkPro.saveTrialDisk = function(dataStr) {
        try {
            var fld = new Folder(Folder.userData.fsName + "/MotionByDk");
            if (!fld.exists) fld.create();
            var f = new File(fld.fsName + "/.mdk_trial.dat");
            f.open("w");
            f.write(dataStr);
            f.close();
            return JSON.stringify({ ok: true });
        } catch(e) {
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    _mdkPro.readTrialDisk = function() {
        try {
            var f = new File(Folder.userData.fsName + "/MotionByDk/.mdk_trial.dat");
            if (f.exists) {
                f.open("r");
                var str = f.read();
                f.close();
                return JSON.stringify({ ok: true, data: str });
            }
            return JSON.stringify({ ok: false, error: "not_found" });
        } catch(e) {
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    // 4. INSTANT LIQUID GLASS EFFECT
    _mdkPro.applyLiquidGlass = function() {
        try {
            var comp = app.project ? app.project.activeItem : null;
            if (!comp || !(comp instanceof CompItem)) {
                return JSON.stringify({ ok: false, error: "Please open an active composition." });
            }

            app.beginUndoGroup("Apply Liquid Glass");

            var selLayers = comp.selectedLayers;
            var targetLayer = null;

            if (selLayers && selLayers.length > 0) {
                targetLayer = selLayers[0];
            } else {
                targetLayer = comp.layers.addSolid([0, 0, 0], "Liquid Glass FX", comp.width, comp.height, comp.pixelAspect, comp.duration);
                targetLayer.adjustmentLayer = true;
                targetLayer.startTime = comp.time;
            }

            var fxGroup = targetLayer.property("ADBE Effect Parade");
            if (!fxGroup) {
                app.endUndoGroup();
                return JSON.stringify({ ok: false, error: "Selected layer does not support effects." });
            }

            var fx = null;
            var namesToTry = ["Liquid Glass", "ToolsForMotion Liquid Glass", "com.toolsformotion.liquidglass", "LiquidGlass"];
            for (var i = 0; i < namesToTry.length; i++) {
                try {
                    fx = fxGroup.addProperty(namesToTry[i]);
                    if (fx) break;
                } catch(e) {}
            }

            if (!fx) {
                app.endUndoGroup();
                return JSON.stringify({
                    ok: false,
                    error: "plugin_missing",
                    msg: "Liquid Glass plugin is not installed in After Effects Plug-ins folder."
                });
            }

            app.endUndoGroup();
            return JSON.stringify({ ok: true, msg: "Liquid Glass applied successfully!" });
        } catch(err) {
            try { app.endUndoGroup(); } catch(e) {}
            return JSON.stringify({ ok: false, error: err.toString() });
        }
    };

    // =========================================================================
    // 5. SMART MEDIA CLIPBOARD ENGINE (COPY PASTA PRO COMPANION)
    // =========================================================================
    _mdkPro.importAndInsertMedia = function(filePath, createNewCompIfNone) {
        try {
            if (!filePath) return JSON.stringify({ ok: false, error: "No file path provided." });
            var f = new File(filePath);
            if (!f.exists) return JSON.stringify({ ok: false, error: "File does not exist: " + filePath });

            app.beginUndoGroup("MotionByDk Paste Media");

            var comp = _getActiveComp();
            var proj = app.project;
            if (!proj) {
                app.endUndoGroup();
                return JSON.stringify({ ok: false, error: "No active project open." });
            }

            // 1. Get or create target project bin folder
            var targetFolderName = "MotionByDk Assets";
            var targetFolder = null;
            for (var i = 1; i <= proj.numItems; i++) {
                if (proj.item(i) instanceof FolderItem && proj.item(i).name === targetFolderName) {
                    targetFolder = proj.item(i);
                    break;
                }
            }
            if (!targetFolder) {
                targetFolder = proj.items.addFolder(targetFolderName);
            }

            // 2. Import footage
            var io = new ImportOptions(f);
            if (io.canImportAs(ImportAsType.FOOTAGE)) {
                io.importAs = ImportAsType.FOOTAGE;
            }
            var importedItem = proj.importFile(io);
            if (targetFolder) importedItem.parentFolder = targetFolder;

            // 3. Create or use active comp
            if (!comp) {
                if (createNewCompIfNone) {
                    var compW = (importedItem.width && importedItem.width > 0) ? importedItem.width : 1920;
                    var compH = (importedItem.height && importedItem.height > 0) ? importedItem.height : 1080;
                    comp = proj.items.addComp(importedItem.name + "_Comp", compW, compH, 1.0, 10.0, 30.0);
                    comp.openInViewer();
                } else {
                    app.endUndoGroup();
                    return JSON.stringify({ ok: false, error: "Please open an active composition." });
                }
            }

            // 4. Add layer to active comp
            var layer = comp.layers.add(importedItem);
            if (layer.property("Position")) {
                layer.property("Position").setValue([comp.width / 2, comp.height / 2]);
            }
            // Align in-point to playhead (CTI)
            layer.startTime = comp.time;

            app.endUndoGroup();
            return JSON.stringify({
                ok: true,
                msg: "Pasted " + importedItem.name + " to timeline!",
                itemName: importedItem.name,
                compName: comp.name
            });
        } catch(err) {
            try { app.endUndoGroup(); } catch(e) {}
            return JSON.stringify({ ok: false, error: err.toString() });
        }
    };

    _mdkPro.exportActiveCompFrameToPNG = function(destPath) {
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            if (!destPath) return JSON.stringify({ ok: false, error: "No destination path specified." });

            var outFile = new File(destPath);
            if (outFile.parent && !outFile.parent.exists) {
                try { outFile.parent.create(); } catch(mkE) {}
            }
            if (outFile.exists) {
                try { outFile.remove(); } catch(e) {}
            }

            // Clamp time strictly inside comp range [0, duration - frameDuration*0.1]
            var maxT = Math.max(0, (comp.duration || 0) - (comp.frameDuration || 0.033) * 0.1);
            var renderT = Math.max(0, Math.min(maxT, comp.time));

            // NOTE: In AE 2024-2026, saveFrameToPng flushes asynchronously after evalScript returns,
            // so do NOT reject immediately if outFile.exists is still false synchronously.
            comp.saveFrameToPng(renderT, outFile);

            return JSON.stringify({
                ok: true,
                ready: !!(outFile.exists && outFile.length > 0),
                path: outFile.fsName,
                msg: "Comp frame export scheduled."
            });
        } catch(err) {
            return JSON.stringify({ ok: false, error: err.toString() });
        }
    };

    _mdkPro.exportActiveCompFrameViaRQ = function(destPrefixPath) {
        var item = null;
        var prevQueued = [];
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            if (!destPrefixPath) return JSON.stringify({ ok: false, error: "No destination path specified." });

            var rq = app.project.renderQueue;
            for (var i = 1; i <= rq.numItems; i++) {
                var rqi = rq.item(i);
                if (rqi && rqi.status === RQItemStatus.QUEUED) {
                    prevQueued.push(rqi);
                    rqi.render = false;
                }
            }

            var frameDur = comp.frameDuration || (1 / (comp.frameRate || 30));
            var maxT = Math.max(0, (comp.duration || 0) - frameDur);
            var renderT = Math.max(0, Math.min(maxT, comp.time));
            var startFrame = Math.round(renderT / frameDur);

            item = rq.items.add(comp);
            item.timeSpanStart = startFrame * frameDur;
            item.timeSpanDuration = frameDur;
            var om = item.outputModule(1);
            om.applyTemplate("TIFF Sequence with Alpha");
            om.file = new File(destPrefixPath + "_[#####].tif");

            rq.render();

            var expected = null;
            var folder = new File(destPrefixPath + "_00000.tif").parent;
            var baseName = new File(destPrefixPath).name;
            if (folder && folder.exists) {
                var matches = folder.getFiles(baseName + "_*.tif");
                if (matches && matches.length > 0) {
                    expected = matches[0];
                }
            }
            if (!expected || !expected.exists || expected.length <= 0) {
                return JSON.stringify({ ok: false, error: "RenderQueue failed to render frame." });
            }
            return JSON.stringify({ ok: true, tifPath: expected.fsName });
        } catch(err) {
            return JSON.stringify({ ok: false, error: err.toString() });
        } finally {
            try { if (item) item.remove(); } catch(re) {}
            for (var j = 0; j < prevQueued.length; j++) {
                try { prevQueued[j].render = true; } catch(pe) {}
            }
        }
    };

    // =========================================================================
    // 6. SUPER MORPHING PRO SUITE (KINETIC + VECTOR + TRAILS + SLICER)
    // Implements authentic Super Morphings kinetic transitions (Pre/Main/Post
    // arc, stretch, midpoint swap, elastic settle, vector Trim Path trails, &
    // masked Slicer) PLUS true Bezier vector path & color morphing. 100% native
    // keyframes (zero Classic 3D Artisan expression crashes).
    // =========================================================================

    function _getPropSafe(layer, groupName, propName) {
        try {
            var grp = layer.property(groupName);
            if (grp && grp.property(propName)) return grp.property(propName);
        } catch(e) {}
        try { return layer.property(propName); } catch(e2) { return null; }
    }

    function _setArrValueAtTime(prop, t, x, y, extra) {
        if (!prop) return;
        var cur = prop.value;
        if (cur instanceof Array && cur.length >= 3) {
            prop.setValueAtTime(t, [x, y, (typeof extra === "number" ? extra : cur[2])]);
        } else {
            prop.setValueAtTime(t, [x, y]);
        }
    }

    function _centerAnchorToVisualBounds(layer, t) {
        if (!layer) return;
        try {
            if (!(layer instanceof ShapeLayer) && !(layer instanceof TextLayer)) return;
            if (layer.parent) return;
            var anchProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Anchor Point") || _getPropSafe(layer, "Transform", "Anchor Point");
            var posProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layer, "Transform", "Position");
            var scaleProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(layer, "Transform", "Scale");
            var rotProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Rotate Z") || _getPropSafe(layer, "Transform", "Rotation");
            if (!anchProp || !posProp || anchProp.numKeys > 0 || posProp.numKeys > 0 || posProp.dimensionsSeparated) return;

            var rect = layer.sourceRectAtTime(t, false);
            if (!rect || rect.width <= 0 || rect.height <= 0) return;

            var cx = rect.left + rect.width / 2;
            var cy = rect.top + rect.height / 2;
            var oldA = anchProp.value;
            var oldP = posProp.value;
            var dx = cx - oldA[0];
            var dy = cy - oldA[1];
            if (Math.abs(dx) < 0.25 && Math.abs(dy) < 0.25) return;

            var sc = scaleProp ? scaleProp.value : [100, 100];
            var rot = rotProp ? rotProp.value : 0;
            var sx = (sc[0] || 100) / 100.0;
            var sy = (sc[1] || 100) / 100.0;
            var rad = rot * Math.PI / 180.0;
            var cosR = Math.cos(rad), sinR = Math.sin(rad);
            var sdx = dx * sx, sdy = dy * sy;
            var wdx = sdx * cosR - sdy * sinR;
            var wdy = sdx * sinR + sdy * cosR;

            anchProp.setValue(oldA.length >= 3 ? [cx, cy, oldA[2]] : [cx, cy]);
            posProp.setValue(oldP.length >= 3 ? [oldP[0] + wdx, oldP[1] + wdy, oldP[2]] : [oldP[0] + wdx, oldP[1] + wdy]);
        } catch(e) {}
    }

    function _getVisualBounds(layer, t) {
        try {
            var scaleProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(layer, "Transform", "Scale");
            var sc = scaleProp ? scaleProp.value : [100, 100];
            var sx = Math.abs(sc[0] || 100) / 100.0;
            var sy = Math.abs(sc[1] || 100) / 100.0;
            if (typeof layer.sourceRectAtTime === "function") {
                var r = layer.sourceRectAtTime(t, false);
                if (r && r.width > 0 && r.height > 0) {
                    return { left: r.left, top: r.top, width: r.width * sx, height: r.height * sy, rawW: r.width, rawH: r.height };
                }
            }
            var w = layer.width || 100;
            var h = layer.height || 100;
            return { left: 0, top: 0, width: w * sx, height: h * sy, rawW: w, rawH: h };
        } catch(e) {}
        return { left: -50, top: -50, width: 100, height: 100, rawW: 100, rawH: 100 };
    }

    function _splitBezierEdge(p0, o0, p3, i3, t) {
        if (typeof t !== "number") t = 0.5;
        p0 = (p0 && typeof p0[0] === "number") ? p0 : [0, 0];
        o0 = (o0 && typeof o0[0] === "number") ? o0 : [0, 0];
        p3 = (p3 && typeof p3[0] === "number") ? p3 : [0, 0];
        i3 = (i3 && typeof i3[0] === "number") ? i3 : [0, 0];

        var c1 = [p0[0] + o0[0], p0[1] + o0[1]];
        var c2 = [p3[0] + i3[0], p3[1] + i3[1]];

        var q0 = [p0[0] + (c1[0] - p0[0]) * t, p0[1] + (c1[1] - p0[1]) * t];
        var q1 = [c1[0] + (c2[0] - c1[0]) * t, c1[1] + (c2[1] - c1[1]) * t];
        var q2 = [c2[0] + (p3[0] - c2[0]) * t, c2[1] + (p3[1] - c2[1]) * t];

        var r0 = [q0[0] + (q1[0] - q0[0]) * t, q0[1] + (q1[1] - q0[1]) * t];
        var r1 = [q1[0] + (q2[0] - q1[0]) * t, q1[1] + (q2[1] - q1[1]) * t];

        var s = [r0[0] + (r1[0] - r0[0]) * t, r0[1] + (r1[1] - r0[1]) * t];

        return {
            newOut0: [q0[0] - p0[0], q0[1] - p0[1]],
            midVertex: s,
            newInMid: [r0[0] - s[0], r0[1] - s[1]],
            newOutMid: [r1[0] - s[0], r1[1] - s[1]],
            newIn3: [q2[0] - p3[0], q2[1] - p3[1]]
        };
    }

    function _subdivideShape(shapeObj, targetVertexCount) {
        if (!shapeObj || !shapeObj.vertices || shapeObj.vertices.length >= targetVertexCount) {
            return shapeObj;
        }

        var verts = shapeObj.vertices.slice(0);
        var inT = (shapeObj.inTangents && shapeObj.inTangents.length) ? shapeObj.inTangents.slice(0) : [];
        var outT = (shapeObj.outTangents && shapeObj.outTangents.length) ? shapeObj.outTangents.slice(0) : [];
        var isClosed = (typeof shapeObj.closed !== "undefined") ? shapeObj.closed : true;

        while (inT.length < verts.length) inT.push([0, 0]);
        while (outT.length < verts.length) outT.push([0, 0]);

        var guard = 0;
        while (verts.length < targetVertexCount && guard < 600) {
            guard++;
            var maxDistSq = -1;
            var bestIdx = 0;
            var numEdges = isClosed ? verts.length : (verts.length - 1);

            for (var i = 0; i < numEdges; i++) {
                var nextI = (i + 1) % verts.length;
                var dx = verts[nextI][0] - verts[i][0];
                var dy = verts[nextI][1] - verts[i][1];
                var dSq = dx * dx + dy * dy;
                if (dSq > maxDistSq) {
                    maxDistSq = dSq;
                    bestIdx = i;
                }
            }

            var p0 = verts[bestIdx];
            var o0 = outT[bestIdx];
            var nextIdx = (bestIdx + 1) % verts.length;
            var p3 = verts[nextIdx];
            var i3 = inT[nextIdx];

            var split = _splitBezierEdge(p0, o0, p3, i3, 0.5);

            outT[bestIdx] = split.newOut0;
            inT[nextIdx] = split.newIn3;

            verts.splice(bestIdx + 1, 0, split.midVertex);
            inT.splice(bestIdx + 1, 0, split.newInMid);
            outT.splice(bestIdx + 1, 0, split.newOutMid);
        }

        var newShape = new Shape();
        newShape.vertices = verts;
        newShape.inTangents = inT;
        newShape.outTangents = outT;
        newShape.closed = isClosed;
        return newShape;
    }

    function _getShapeCentroid(shapeObj) {
        if (!shapeObj || !shapeObj.vertices || !shapeObj.vertices.length) return [0, 0];
        var minX = 1e9, maxX = -1e9, minY = 1e9, maxY = -1e9;
        for (var i = 0; i < shapeObj.vertices.length; i++) {
            var v = shapeObj.vertices[i];
            if (v[0] < minX) minX = v[0];
            if (v[0] > maxX) maxX = v[0];
            if (v[1] < minY) minY = v[1];
            if (v[1] > maxY) maxY = v[1];
        }
        return [(minX + maxX) / 2, (minY + maxY) / 2];
    }

    function _translateShapeToCentroid(shapeObj, targetCenter) {
        if (!shapeObj || !shapeObj.vertices || !targetCenter) return shapeObj;
        var cur = _getShapeCentroid(shapeObj);
        var ox = targetCenter[0] - cur[0];
        var oy = targetCenter[1] - cur[1];
        if (Math.abs(ox) < 0.1 && Math.abs(oy) < 0.1) return shapeObj;

        var verts = [];
        for (var i = 0; i < shapeObj.vertices.length; i++) {
            verts.push([shapeObj.vertices[i][0] + ox, shapeObj.vertices[i][1] + oy]);
        }
        var res = new Shape();
        res.vertices = verts;
        res.inTangents = shapeObj.inTangents || [];
        res.outTangents = shapeObj.outTangents || [];
        res.closed = (typeof shapeObj.closed !== "undefined") ? shapeObj.closed : true;
        return res;
    }

    function _alignShapeVertices(shapeA, shapeB) {
        if (!shapeA || !shapeB || !shapeA.vertices || !shapeB.vertices) return shapeB;
        var n = shapeA.vertices.length;
        if (n !== shapeB.vertices.length || n <= 1) return shapeB;

        var vA = shapeA.vertices;
        var vB = shapeB.vertices;
        var inB = shapeB.inTangents || [];
        var outB = shapeB.outTangents || [];

        var bestShift = 0;
        var bestReversed = false;
        var minTotalDist = -1;

        for (var s = 0; s < n; s++) {
            var totalDist = 0;
            for (var i = 0; i < n; i++) {
                var j = (i + s) % n;
                var dx = vA[i][0] - vB[j][0];
                var dy = vA[i][1] - vB[j][1];
                totalDist += Math.sqrt(dx * dx + dy * dy);
            }
            if (minTotalDist < 0 || totalDist < minTotalDist) {
                minTotalDist = totalDist;
                bestShift = s;
                bestReversed = false;
            }
        }

        for (var s2 = 0; s2 < n; s2++) {
            var totalDist2 = 0;
            for (var i2 = 0; i2 < n; i2++) {
                var j2 = (n - 1 - i2 + s2) % n;
                var dx2 = vA[i2][0] - vB[j2][0];
                var dy2 = vA[i2][1] - vB[j2][1];
                totalDist2 += Math.sqrt(dx2 * dx2 + dy2 * dy2);
            }
            if (totalDist2 < minTotalDist) {
                minTotalDist = totalDist2;
                bestShift = s2;
                bestReversed = true;
            }
        }

        var alignedVB = [];
        var alignedInB = [];
        var alignedOutB = [];

        if (!bestReversed) {
            for (var k = 0; k < n; k++) {
                var idx = (k + bestShift) % n;
                alignedVB.push(vB[idx]);
                alignedInB.push(inB[idx] || [0, 0]);
                alignedOutB.push(outB[idx] || [0, 0]);
            }
        } else {
            for (var k2 = 0; k2 < n; k2++) {
                var idx2 = (n - 1 - k2 + bestShift) % n;
                alignedVB.push(vB[idx2]);
                var oldOut = outB[idx2] || [0, 0];
                var oldIn = inB[idx2] || [0, 0];
                alignedInB.push([-oldOut[0], -oldOut[1]]);
                alignedOutB.push([-oldIn[0], -oldIn[1]]);
            }
        }

        var resShape = new Shape();
        resShape.vertices = alignedVB;
        resShape.inTangents = alignedInB;
        resShape.outTangents = alignedOutB;
        resShape.closed = shapeB.closed;
        return resShape;
    }

    function _findShapePropRecursive(container) {
        if (!container) return null;
        try {
            var n = container.numProperties;
            for (var i = 1; i <= n; i++) {
                var p = container.property(i);
                if (!p) continue;
                if (p.propertyType === PropertyType.PROPERTY) {
                    if (p.propertyValueType === PropertyValueType.SHAPE) {
                        try {
                            if (p.value && p.value.vertices) return p;
                        } catch(ve) {}
                    }
                } else if (p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) {
                    var found = _findShapePropRecursive(p);
                    if (found) return found;
                }
            }
        } catch(e) {}
        return null;
    }

    function _extractShapeFromLayer(layer) {
        if (!layer) return null;

        try {
            var selProps = layer.selectedProperties;
            if (selProps && selProps.length > 0) {
                for (var sp = 0; sp < selProps.length; sp++) {
                    var selP = selProps[sp];
                    if (selP && selP.propertyType === PropertyType.PROPERTY && selP.propertyValueType === PropertyValueType.SHAPE) {
                        if (selP.value && selP.value.vertices) {
                            return { prop: selP, shape: selP.value, isMask: (selP.matchName === "ADBE Mask Shape"), container: selP.parentProperty, parametric: null };
                        }
                    }
                }
            }
        } catch(selErr) {}

        try {
            var rootVectors = layer.property("ADBE Root Vectors Group") || layer.property("Contents");
            if (rootVectors) {
                var shapeProp = _findShapePropRecursive(rootVectors);
                if (shapeProp && shapeProp.value && shapeProp.value.vertices) {
                    return { prop: shapeProp, shape: shapeProp.value, isMask: false, container: shapeProp.parentProperty, parametric: null };
                }
            }
        } catch(srchErr) {}

        try {
            var contents = layer.property("ADBE Root Vectors Group") || layer.property("Contents");
            if (contents && contents.numProperties > 0) {
                for (var i = 1; i <= contents.numProperties; i++) {
                    var item = contents.property(i);
                    var searchGroup = item;
                    var itemContents = item.property("ADBE Vectors Group") || item.property("Contents");
                    if (itemContents) searchGroup = itemContents;

                    for (var j = 1; j <= searchGroup.numProperties; j++) {
                        var p = searchGroup.property(j);
                        if (!p) continue;

                        if (p.matchName === "ADBE Vector Shape - Rect") {
                            var s = p.property("ADBE Vector Rect Size") ? p.property("ADBE Vector Rect Size").value : [100, 100];
                            var pos = p.property("ADBE Vector Rect Position") ? p.property("ADBE Vector Rect Position").value : [0, 0];
                            var hw = s[0] / 2, hh = s[1] / 2;
                            var rectShape = new Shape();
                            rectShape.vertices = [
                                [pos[0] - hw, pos[1] - hh],
                                [pos[0] + hw, pos[1] - hh],
                                [pos[0] + hw, pos[1] + hh],
                                [pos[0] - hw, pos[1] + hh]
                            ];
                            rectShape.inTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
                            rectShape.outTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
                            rectShape.closed = true;
                            return { prop: null, shape: rectShape, isMask: false, parametric: p, container: searchGroup };
                        }

                        if (p.matchName === "ADBE Vector Shape - Ellipse") {
                            var es = p.property("ADBE Vector Ellipse Size") ? p.property("ADBE Vector Ellipse Size").value : [100, 100];
                            var ep = p.property("ADBE Vector Ellipse Position") ? p.property("ADBE Vector Ellipse Position").value : [0, 0];
                            var rx = es[0] / 2, ry = es[1] / 2;
                            var k = 0.5522847498307935;
                            var ellShape = new Shape();
                            ellShape.vertices = [
                                [ep[0], ep[1] - ry],
                                [ep[0] + rx, ep[1]],
                                [ep[0], ep[1] + ry],
                                [ep[0] - rx, ep[1]]
                            ];
                            ellShape.inTangents = [[-rx * k, 0], [0, -ry * k], [rx * k, 0], [0, ry * k]];
                            ellShape.outTangents = [[rx * k, 0], [0, ry * k], [-rx * k, 0], [0, -ry * k]];
                            ellShape.closed = true;
                            return { prop: null, shape: ellShape, isMask: false, parametric: p, container: searchGroup };
                        }

                        if (p.matchName === "ADBE Vector Shape - Star") {
                            var pts = p.property("ADBE Vector Star Points") ? p.property("ADBE Vector Star Points").value : 5;
                            var or = p.property("ADBE Vector Star Outer Radius") ? p.property("ADBE Vector Star Outer Radius").value : 100;
                            var ir = p.property("ADBE Vector Star Inner Radius") ? p.property("ADBE Vector Star Inner Radius").value : 50;
                            var stPos = p.property("ADBE Vector Star Position") ? p.property("ADBE Vector Star Position").value : [0, 0];
                            var starVerts = [];
                            var totalPts = pts * 2;
                            var step = (Math.PI * 2) / totalPts;
                            for (var sp = 0; sp < totalPts; sp++) {
                                var angle = sp * step - Math.PI / 2;
                                var r = (sp % 2 === 0) ? or : ir;
                                starVerts.push([stPos[0] + Math.cos(angle) * r, stPos[1] + Math.sin(angle) * r]);
                            }
                            var starShape = new Shape();
                            starShape.vertices = starVerts;
                            var sIn = [], sOut = [];
                            for (var spi = 0; spi < totalPts; spi++) { sIn.push([0, 0]); sOut.push([0, 0]); }
                            starShape.inTangents = sIn;
                            starShape.outTangents = sOut;
                            starShape.closed = true;
                            return { prop: null, shape: starShape, isMask: false, parametric: p, container: searchGroup };
                        }
                    }
                }
            }
        } catch(paramErr) {}

        try {
            var maskParade = layer.property("ADBE Mask Parade");
            if (maskParade && maskParade.numProperties > 0) {
                for (var m = 1; m <= maskParade.numProperties; m++) {
                    var mask = maskParade.property(m);
                    var maskShape = mask.property("ADBE Mask Shape");
                    if (maskShape && maskShape.value && maskShape.value.vertices) {
                        return { prop: maskShape, shape: maskShape.value, isMask: true, container: mask, parametric: null };
                    }
                }
            }
        } catch(maskErr) {}

        return null;
    }

    function _findVectorFill(container) {
        if (!container) return null;
        try {
            var n = container.numProperties;
            for (var i = 1; i <= n; i++) {
                var p = container.property(i);
                if (!p) continue;
                if (p.matchName === "ADBE Vector Graphic - Fill") {
                    var col = p.property("ADBE Vector Fill Color") || p.property(1);
                    if (col) return col;
                }
                if (p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) {
                    var found = _findVectorFill(p);
                    if (found) return found;
                }
            }
        } catch(e) {}
        return null;
    }

    function _findVectorStroke(container) {
        if (!container) return null;
        try {
            var n = container.numProperties;
            for (var i = 1; i <= n; i++) {
                var p = container.property(i);
                if (!p) continue;
                if (p.matchName === "ADBE Vector Graphic - Stroke") {
                    return {
                        color: p.property("ADBE Vector Stroke Color"),
                        width: p.property("ADBE Vector Stroke Width")
                    };
                }
                if (p.propertyType === PropertyType.INDEXED_GROUP || p.propertyType === PropertyType.NAMED_GROUP) {
                    var found = _findVectorStroke(p);
                    if (found) return found;
                }
            }
        } catch(e) {}
        return null;
    }

    function _convertParametricToPath(layer, info) {
        if (!info || !info.parametric) return (info ? info.prop : null);
        try {
            var container = info.container;
            var targetIdx = info.parametric.propertyIndex || 1;
            var matchName = info.parametric.matchName;

            var pGrp = container.addProperty("ADBE Vector Shape - Group");
            var preMoveProp = pGrp.property("ADBE Vector Shape") || pGrp.property(1);
            if (preMoveProp && info.shape) {
                preMoveProp.setValue(info.shape);
            }

            // CRITICAL: Move Path BEFORE Fill & Stroke so shape remains visible!
            // Note: moveTo/remove invalidates JS Property wrappers in AE, so re-fetch after.
            try { pGrp.moveTo(targetIdx); } catch(mvErr) { try { pGrp.moveTo(1); targetIdx = 1; } catch(e2) {} }

            // Safely remove old static parametric property
            for (var r = container.numProperties; r >= 1; r--) {
                var p = container.property(r);
                if (p && p.matchName === matchName) {
                    p.remove();
                    break;
                }
            }

            // Re-acquire fresh PropertyGroup & Path reference after hierarchy mutation
            var freshGrp = null;
            if (targetIdx >= 1 && targetIdx <= container.numProperties &&
                container.property(targetIdx).matchName === "ADBE Vector Shape - Group") {
                freshGrp = container.property(targetIdx);
            } else {
                for (var fi = 1; fi <= container.numProperties; fi++) {
                    if (container.property(fi).matchName === "ADBE Vector Shape - Group") {
                        freshGrp = container.property(fi);
                        break;
                    }
                }
            }

            var targetPathProp = freshGrp ? (freshGrp.property("ADBE Vector Shape") || freshGrp.property(1)) : null;
            if (targetPathProp && info.shape) {
                targetPathProp.setValue(info.shape);
            }
            info.prop = targetPathProp;
            info.parametric = null;
            return targetPathProp;
        } catch(e) {
            return null;
        }
    }

    function _applyPropertyEase(prop, tStart, tEnd, inVal, outVal) {
        try {
            var k1 = prop.nearestKeyIndex(tStart);
            var k2 = prop.nearestKeyIndex(tEnd);
            prop.setInterpolationTypeAtKey(k1, KeyframeInterpolationType.BEZIER);
            prop.setInterpolationTypeAtKey(k2, KeyframeInterpolationType.BEZIER);
            var sampleVal = prop.valueAtTime(tStart, false);
            var dim = (sampleVal instanceof Array && sampleVal.length) ? sampleVal.length : 1;
            var inArr = [], outArr = [];
            for (var d = 0; d < dim; d++) {
                inArr.push(new KeyframeEase(0, inVal));
                outArr.push(new KeyframeEase(0, outVal));
            }
            prop.setTemporalEaseAtKey(k1, inArr, outArr);
            prop.setTemporalEaseAtKey(k2, inArr, outArr);
        } catch(e) {}
    }

    function _applyKeyframeEaseToRange(prop, tStart, tEnd, inVal, outVal) {
        try {
            for (var k = 1; k <= prop.numKeys; k++) {
                var kt = prop.keyTime(k);
                if (kt >= tStart - 0.005 && kt <= tEnd + 0.005) {
                    prop.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER);
                    var sampleVal = prop.keyValue(k);
                    var dim = (sampleVal instanceof Array && sampleVal.length) ? sampleVal.length : 1;
                    var inArr = [], outArr = [];
                    for (var d = 0; d < dim; d++) {
                        inArr.push(new KeyframeEase(0, inVal));
                        outArr.push(new KeyframeEase(0, outVal));
                    }
                    prop.setTemporalEaseAtKey(k, inArr, outArr);
                }
            }
        } catch(e) {}
    }

    function _setHoldKey(prop, t, val) {
        prop.setValueAtTime(t, val);
        var idx = prop.nearestKeyIndex(t);
        prop.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.HOLD);
    }

    function _sampleLayerColor(layer) {
        try {
            var root = layer.property("ADBE Root Vectors Group") || layer.property("Contents");
            if (root) {
                var fill = _findVectorFill(root);
                if (fill && fill.value) return fill.value;
                var st = _findVectorStroke(root);
                if (st && st.color && st.color.value) return st.color.value;
            }
        } catch(e) {}
        return [1.0, 0.48, 0.0, 1.0]; // Signature MotionByDk Orange fallback
    }

    function _buildArcPoints(pA, pB, useArc, arcDir) {
        var dx = pB[0] - pA[0];
        var dy = pB[1] - pA[1];
        var dist = Math.sqrt(dx * dx + dy * dy);
        if (!useArc || dist < 10) {
            return {
                mid: [(pA[0] + pB[0]) * 0.5, (pA[1] + pB[1]) * 0.5],
                dist: dist,
                dirX: dist > 0 ? dx / dist : 1,
                dirY: dist > 0 ? dy / dist : 0,
                arcOffset: [0, 0]
            };
        }
        // Perpendicular arc offset (~22% of travel distance)
        var nx = -dy / dist;
        var ny = dx / dist;
        if (arcDir < 0) { nx = -nx; ny = -ny; }
        var arcAmp = Math.min(dist * 0.24, 220);
        return {
            mid: [(pA[0] + pB[0]) * 0.5 + nx * arcAmp, (pA[1] + pB[1]) * 0.5 + ny * arcAmp],
            dist: dist,
            dirX: dx / dist,
            dirY: dy / dist,
            arcOffset: [nx * arcAmp, ny * arcAmp]
        };
    }

    /**
     * Exact Super Morphings 3-Stage Kinetic Morph:
     * Pre (Anticipation Pull-back) -> Main (Whip Arc + Stretch + Midpoint Opacity Swap) -> Post (Elastic Settle).
     */
    // =========================================================================
    // AUTHENTIC SUPER MORPHINGS ENGINE (Arc + Roving Key + Geometry2 Bounds/Tilt
    // + Landing Handoff + Target Overshoot Follow-Through + Echo + Trails)
    // =========================================================================

    function _smHypot(dx, dy) {
        return Math.sqrt(dx * dx + dy * dy);
    }

    function _smRoundP(num, factor) {
        return Math.round(num * factor) / factor;
    }

    function _smEscapeExprStr(s) {
        return String(s || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    }

    function _smSafePosArr(prop, xy) {
        try {
            if (prop && prop.value && prop.value.length === 3) {
                var z = (xy.length >= 3 && typeof xy[2] === "number") ? xy[2] : (prop.value[2] || 0);
                return [_smRoundP(xy[0], 1000), _smRoundP(xy[1], 1000), _smRoundP(z, 1000)];
            }
        } catch(e) {}
        return [_smRoundP(xy[0], 1000), _smRoundP(xy[1], 1000)];
    }

    function _smGetRealScale(layer, t) {
        var curT = (typeof t === "number") ? t : layer.containingComp.time;
        var scProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(layer, "Transform", "Scale");
        var scVal = scProp ? scProp.valueAtTime(curT, false) : [100, 100];
        var sx = (scVal[0] || 100) / 100.0;
        var sy = (scVal[1] || 100) / 100.0;
        var p = layer.parent;
        while (p) {
            var pScProp = _getPropSafe(p, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(p, "Transform", "Scale");
            var pSc = pScProp ? pScProp.valueAtTime(curT, false) : [100, 100];
            sx *= (pSc[0] || 100) / 100.0;
            sy *= (pSc[1] || 100) / 100.0;
            p = p.parent;
        }
        if (Math.abs(sx) < 0.01) sx = (sx < 0 ? -0.01 : 0.01);
        if (Math.abs(sy) < 0.01) sy = (sy < 0 ? -0.01 : 0.01);
        return [sx, sy];
    }

    function _smGetRealRotation(layer, onlyParent, t) {
        var curT = (typeof t === "number") ? t : layer.containingComp.time;
        var rot = 0;
        var origParent = layer.parent;
        if (onlyParent) {
            var p = origParent;
            while (p) {
                var rp = _getPropSafe(p, "ADBE Transform Group", "ADBE Rotate Z") || _getPropSafe(p, "Transform", "Rotation");
                if (rp) rot += rp.valueAtTime(curT, false);
                p = p.parent;
            }
        } else {
            try {
                layer.parent = null;
                var lr = _getPropSafe(layer, "ADBE Transform Group", "ADBE Rotate Z") || _getPropSafe(layer, "Transform", "Rotation");
                if (lr) rot = lr.valueAtTime(curT, false);
                layer.parent = origParent;
            } catch(e) {
                try { layer.parent = origParent; } catch(e2) {}
            }
        }
        return rot % 360;
    }

    function _smGetRealPosition(layer, onlyParent, t) {
        var curT = (typeof t === "number") ? t : layer.containingComp.time;
        var pos = [0, 0];
        var origParent = layer.parent;
        if (onlyParent) {
            var p = origParent;
            while (p) {
                var pp = _getPropSafe(p, "ADBE Transform Group", "ADBE Position") || _getPropSafe(p, "Transform", "Position");
                var pVal = pp ? pp.valueAtTime(curT, false) : [0, 0];
                if ((p instanceof ShapeLayer) || (p instanceof TextLayer)) {
                    var ap = _getPropSafe(layer, "ADBE Transform Group", "ADBE Anchor Point") || _getPropSafe(layer, "Transform", "Anchor Point");
                    var apVal = ap ? ap.valueAtTime(curT, false) : [0, 0];
                    pos[0] -= apVal[0];
                    pos[1] -= apVal[1];
                }
                pos[0] += pVal[0];
                pos[1] += pVal[1];
                p = p.parent;
            }
        } else {
            try {
                layer.parent = null;
                var lp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layer, "Transform", "Position");
                var lVal = lp ? lp.valueAtTime(curT, false) : [0, 0];
                pos = (lVal.length >= 3) ? [lVal[0], lVal[1], lVal[2]] : [lVal[0], lVal[1]];
                layer.parent = origParent;
            } catch(e) {
                try { layer.parent = origParent; } catch(e2) {}
            }
        }
        return pos;
    }

    function _smGetRealBounds(layer, curTime) {
        var t = (typeof curTime === "number") ? curTime : layer.containingComp.time;
        var xl = null, xh = null, yl = null, yh = null;
        try {
            var masks = layer.property("ADBE Mask Parade");
            if (masks && masks.numProperties > 0) {
                var xB = [], yB = [];
                for (var f = 1; f <= masks.numProperties; f++) {
                    var m = masks.property(f);
                    if (!m || m.maskMode === MaskMode.NONE) continue;
                    var ms = m.property("ADBE Mask Shape");
                    if (!ms) continue;
                    var verts = ms.valueAtTime(t, false).vertices;
                    for (var j = 0; j < verts.length; j++) {
                        xB.push(verts[j][0]);
                        yB.push(verts[j][1]);
                    }
                }
                if (xB.length > 0) {
                    xB.sort(function(a, b) { return a - b; });
                    xl = xB[0];
                    xh = xB[xB.length - 1];
                }
                if (yB.length > 0) {
                    yB.sort(function(a, b) { return a - b; });
                    yl = yB[0];
                    yh = yB[yB.length - 1];
                }
            }
        } catch(me) {}

        var xl2 = 0, yl2 = 0, w2 = 100, h2 = 100;
        try {
            if (typeof layer.sourceRectAtTime === "function") {
                var sr = layer.sourceRectAtTime(t, false);
                xl2 = sr.left;
                yl2 = sr.top;
                w2 = sr.width;
                h2 = sr.height;
            } else {
                w2 = layer.width || 100;
                h2 = layer.height || 100;
            }
        } catch(se) {
            w2 = layer.width || 100;
            h2 = layer.height || 100;
        }
        var xh2 = xl2 + w2;
        var yh2 = yl2 + h2;

        if (xl === null || xl < xl2) xl = xl2;
        if (xh === null || xh > xh2) xh = xh2;
        if (yl === null || yl < yl2) yl = yl2;
        if (yh === null || yh > yh2) yh = yh2;

        return {
            left: xl,
            top: yl,
            width: Math.max(1, xh - xl),
            height: Math.max(1, yh - yl)
        };
    }

    function _smMoveAnchorToCenter(layer, curTime) {
        if (!layer) return;
        try {
            var curComp = layer.containingComp;
            var t = (typeof curTime === "number") ? curTime : curComp.time;
            var masks = layer.property("ADBE Mask Parade");
            var noMasks = true;
            if (masks && masks.numProperties > 0) {
                for (var i = 1; i <= masks.numProperties; i++) {
                    if (masks.property(i).maskMode !== MaskMode.NONE) {
                        noMasks = false;
                        break;
                    }
                }
            }

            var x, y;
            if (noMasks) {
                if ((layer instanceof TextLayer) || (layer instanceof ShapeLayer)) {
                    var sr = layer.sourceRectAtTime(t, false);
                    x = sr.left + sr.width / 2;
                    y = sr.top + sr.height / 2;
                } else {
                    x = (layer.width || 100) / 2;
                    y = (layer.height || 100) / 2;
                }
            } else {
                var obj = _smGetRealBounds(layer, t);
                x = obj.left + obj.width / 2;
                y = obj.top + obj.height / 2;
            }

            var anchProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Anchor Point") || _getPropSafe(layer, "Transform", "Anchor Point");
            var posProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layer, "Transform", "Position");
            var scaleProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(layer, "Transform", "Scale");
            var rotProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Rotate Z") || _getPropSafe(layer, "Transform", "Rotation");
            if (!anchProp || !posProp) return;

            var curAnchor = anchProp.isTimeVarying ? anchProp.valueAtTime(t, true) : anchProp.value;
            var dx = x - curAnchor[0];
            var dy = y - curAnchor[1];
            if (Math.abs(dx) < 0.25 && Math.abs(dy) < 0.25) return;

            var sc = scaleProp ? scaleProp.valueAtTime(t, false) : [100, 100];
            var rot = rotProp ? rotProp.valueAtTime(t, false) : 0;
            var sx = (sc[0] || 100) / 100.0;
            var sy = (sc[1] || 100) / 100.0;
            var rad = rot * Math.PI / 180.0;
            var cosR = Math.cos(rad), sinR = Math.sin(rad);
            var sdx = dx * sx, sdy = dy * sy;
            var wdx = sdx * cosR - sdy * sinR;
            var wdy = sdx * sinR + sdy * cosR;

            if (anchProp.isTimeVarying) {
                anchProp.setValueAtTime(t, curAnchor.length >= 3 ? [x, y, curAnchor[2]] : [x, y]);
            } else {
                anchProp.setValue(curAnchor.length >= 3 ? [x, y, curAnchor[2]] : [x, y]);
            }

            if (posProp.isTimeVarying && posProp.numKeys > 0) {
                var rovs = [];
                for (var k = 1; k <= posProp.numKeys; k++) {
                    if (posProp.keyRoving(k)) {
                        posProp.setRovingAtKey(k, false);
                        rovs.push(k);
                    }
                    var kv = posProp.keyValue(k);
                    posProp.setValueAtKey(k, kv.length >= 3 ? [kv[0] + wdx, kv[1] + wdy, kv[2]] : [kv[0] + wdx, kv[1] + wdy]);
                }
                for (var r = 0; r < rovs.length; r++) posProp.setRovingAtKey(rovs[r], true);
            } else if (!posProp.dimensionsSeparated) {
                var pv = posProp.value;
                posProp.setValue(pv.length >= 3 ? [pv[0] + wdx, pv[1] + wdy, pv[2]] : [pv[0] + wdx, pv[1] + wdy]);
            }
        } catch(e) {}
    }

    function _smApplyTemporalEase(prop, keys, easings) {
        if (!prop || !prop.canVaryOverTime) return;
        for (var i = 0; i < keys.length; i++) {
            var keyIndex = keys[i];
            if (keyIndex < 1 || keyIndex > prop.numKeys) continue;
            var inInf = Math.max(0.1, Math.min(100, easings[i][0]));
            var outInf = Math.max(0.1, Math.min(100, easings[i][1]));
            try {
                var inEase = prop.keyInTemporalEase(keyIndex);
                var outEase = prop.keyOutTemporalEase(keyIndex);
                var newIn = [];
                var newOut = [];
                for (var y = 0; y < inEase.length; y++) {
                    newIn.push(inInf > 1 ? new KeyframeEase(0, inInf) : inEase[y]);
                }
                for (var z = 0; z < outEase.length; z++) {
                    newOut.push(outInf > 1 ? new KeyframeEase(0, outInf) : outEase[z]);
                }
                prop.setTemporalEaseAtKey(keyIndex, newIn, newOut);
            } catch(e) {}
        }
    }

    function _smApplyMakeArc(posProp, k1, k2) {
        try {
            var heightPercentage = 0.35;
            var startVal = posProp.keyValue(k1);
            var nextVal = posProp.keyValue(k2);
            var vx = nextVal[0] - startVal[0];
            var vy = nextVal[1] - startVal[1];
            var dist = _smHypot(vx, vy);
            if (dist < 1) return;

            var nx = vx / dist;
            var ny = vy / dist;
            var perpX = -ny;
            var perpY = nx;
            var arcLen = dist * heightPercentage;

            // Exact Super Morphings quadrant arc sign convention
            var dir;
            if (vx !== 0 && vy !== 0) {
                if (vx < 0 && vy < 0) dir = -1;
                else if (vx > 0 && vy < 0) dir = 1;
                else if (vx > 0 && vy > 0) dir = 1;
                else dir = -1;
            } else {
                dir = -1;
            }

            var tangX = dir * perpX * arcLen;
            var tangY = dir * perpY * arcLen;
            var addX = (-1 * nx * arcLen) / 2.0;
            var addY = (-1 * ny * arcLen) / 2.0;

            var is3D = (posProp.value.length === 3);
            var inNext = is3D ? [tangX + addX, tangY + addY, 0] : [tangX + addX, tangY + addY];
            var outStart = is3D ? [tangX - addX, tangY - addY, 0] : [tangX - addX, tangY - addY];
            var zero = is3D ? [0, 0, 0] : [0, 0];

            posProp.setSpatialTangentsAtKey(k1, zero, outStart);
            posProp.setSpatialTangentsAtKey(k2, inNext, zero);
        } catch(e) {}
    }

    function _smCalculatePathLength(posProp, k1, k2, frameDur) {
        var t1 = posProp.keyTime(k1);
        var t2 = posProp.keyTime(k2);
        var frames = Math.max(1, (t2 - t1) / frameDur);
        var pathLen = 0;
        var prev = posProp.valueAtTime(t1, false);
        for (var i = 1; i <= Math.ceil(frames); i++) {
            var sampleT = Math.min(t2, t1 + i * frameDur);
            var cur = posProp.valueAtTime(sampleT, false);
            pathLen += _smHypot(cur[0] - prev[0], cur[1] - prev[1]);
            prev = cur;
        }
        return pathLen;
    }

    function _smWorkWithPosition(posProp, posTimes, posValues, t0, preOffset, frameDur, curPosVal, backwards, useArc) {
        for (var y = 0; y < posTimes.length; y++) {
            posProp.setValueAtTime(posTimes[y], _smSafePosArr(posProp, posValues[y]));
        }

        if (useArc) {
            if (backwards) _smApplyMakeArc(posProp, 2, 3);
            else _smApplyMakeArc(posProp, 1, 2);
        } else {
            try {
                for (var ka = 1; ka <= posProp.numKeys; ka++) posProp.setSpatialAutoBezierAtKey(ka, false);
            } catch(le) {}
        }

        if (backwards) {
            var pos2 = posProp.valueAtTime(posProp.keyTime(2) + (frameDur / 5.0), false);
            var vx = pos2[0] - curPosVal[0];
            var vy = pos2[1] - curPosVal[1];
            var vLen = _smHypot(vx, vy);
            if (vLen > 0.001) {
                var pathLen = _smCalculatePathLength(posProp, 2, 3, frameDur);
                var valBack = [
                    curPosVal[0] - (vx / vLen) * (pathLen / 10.0),
                    curPosVal[1] - (vy / vLen) * (pathLen / 10.0)
                ];
                posProp.setValueAtTime(t0 + preOffset, _smSafePosArr(posProp, valBack));
            } else {
                posProp.setValueAtTime(t0 + preOffset, _smSafePosArr(posProp, curPosVal));
            }
            try { posProp.setRovingAtKey(3, true); } catch(re) {}
        }
    }

    function _smEnsureMorphControllers(layerOrNull, ampVal, freqVal, decayVal) {
        var effParade = layerOrNull.property("ADBE Effect Parade");
        var ampEff = effParade.addProperty("ADBE Slider Control");
        ampEff.name = "SM Amplitude";
        ampEff.property(1).setValue(ampVal);

        var freqEff = effParade.addProperty("ADBE Slider Control");
        freqEff.name = "SM Frequency";
        freqEff.property(1).setValue(freqVal);

        var decEff = effParade.addProperty("ADBE Slider Control");
        decEff.name = "SM Decay (sec)";
        decEff.property(1).setValue(decayVal);
    }

    function _smBuildElasticExpression(ctrlLayerName, divider, clampPositiveMin1) {
        var prefix = ctrlLayerName
            ? ('thisComp.layer("' + _smEscapeExprStr(ctrlLayerName) + '").effect(')
            : 'effect(';
        var clampBlock = clampPositiveMin1
            ? '        out = [Math.max(1, out[0]), Math.max(1, out[1])];\n'
            : '';
        var clampElse = clampPositiveMin1
            ? '        [Math.max(1, value[0]), Math.max(1, value[1])];\n'
            : '        value;\n';
        return 'try {\n' +
            '    amp = ' + prefix + '"SM Amplitude")(1) / ' + divider + ';\n' +
            '    freq = ' + prefix + '"SM Frequency")(1);\n' +
            '    decay = 5 / Math.max(0.05, ' + prefix + '"SM Decay (sec)")(1));\n' +
            '    n = 0;\n' +
            '    if (numKeys > 0) {\n' +
            '        n = nearestKey(time).index;\n' +
            '        if (key(n).time > time) n--;\n' +
            '    }\n' +
            '    t = (n == 0) ? 0 : (time - key(n).time);\n' +
            '    if (n > 0) {\n' +
            '        v = velocityAtTime(key(n).time - thisComp.frameDuration / 10);\n' +
            '        out = value + v * amp * Math.sin(freq * t * 2 * Math.PI) / Math.exp(decay * t);\n' +
            clampBlock +
            '        out;\n' +
            '    } else {\n' +
            clampElse +
            '    }\n' +
            '} catch(e) { value; }';
    }

    function _smBuildTargetOvershootExpression(sourceNames, keyIndex, defValStr, isTransformRot, clampScaleMin1) {
        var quoted = [];
        for (var i = 0; i < sourceNames.length; i++) {
            quoted.push('    thisComp.layer("' + _smEscapeExprStr(sourceNames[i]) + '")');
        }
        var propAccess = isTransformRot ? '.effect("SM Transform").rotation' : '.transform(thisProperty.name)';
        var clampOut = clampScaleMin1
            ? 'res = value + off;\n[Math.max(1, res[0]), Math.max(1, res[1])];\n'
            : 'value + off;\n';
        return 'try {\n' +
            'function getDelta(prop, ind, defV, divider) {\n' +
            '    if (time > prop.key(ind).time) return (prop.value - prop.key(ind).value) / divider;\n' +
            '    return defV;\n' +
            '}\n' +
            'layers = [\n' + quoted.join(",\n") + '\n];\n' +
            'off = 0;\n' +
            'for (var i = 0; i < layers.length; i++) {\n' +
            '    p = layers[i]' + propAccess + ';\n' +
            '    off += getDelta(p, ' + keyIndex + ', ' + defValStr + ', layers.length);\n' +
            '}\n' +
            clampOut +
            '} catch(e) { value; }';
    }

    function _smAddStretchEcho(layer) {
        try {
            var echo = layer.property("ADBE Effect Parade").addProperty("ADBE Echo");
            if (echo) {
                echo.property(1).setValue(-0.001); // Echo Time
                echo.property(2).setValue(21);     // Number Of Echoes
                echo.property(3).setValue(1);      // Starting Intensity
                echo.property(4).setValue(3.27);   // Decay
                echo.property(5).setValue(2);      // Echo Operator: Maximum/Composite
            }
        } catch(e) {}
    }

    function _performSuperMorphingBatch(comp, ordered, opts) {
        if (!ordered || ordered.length < 2) {
            return { ok: false, error: "Select at least 2 layers to Morph." };
        }
        var t0 = opts.startTime;
        var frameDur = comp.frameDuration || (1.0 / (comp.frameRate || 30));
        var durScale = Math.max(4, opts.durationFrames || 16) / 16.0;
        var backwards = (opts.straight !== true);
        var useArc = (opts.arc !== false);
        var useStretch = (opts.stretch !== false);
        var staggerStep = frameDur; // 1f stagger when multiple source layers morph to target
        var ROT_VAL = 25;
        var SCALE_VAL = 0.8;

        var posInfluenceBackwards = [[0.1, 33], [100, 100]];
        var posInfluence = [[100, 100]];
        var rotInfluence = [[0.1, 33], [33, 33]];
        var scaleInfluence = [[0.1, 33], [33, 33]];

        var timeOffsets = {
            pre: frameDur * 4 * durScale,
            main: frameDur * 8 * durScale,
            post: frameDur * 16 * durScale
        };
        var scaleTimeOffset = frameDur * 2 * durScale;
        var rotTimeOffset = frameDur * 4 * durScale;

        var targetLayer = ordered[ordered.length - 1];
        var sources = ordered.slice(0, ordered.length - 1);

        // Guard against pre-existing multi-keyframe animation on source layers
        for (var c = 0; c < sources.length; c++) {
            var sl = sources[c];
            var pCheck = _getPropSafe(sl, "ADBE Transform Group", "ADBE Position");
            var sCheck = _getPropSafe(sl, "ADBE Transform Group", "ADBE Scale");
            var rCheck = _getPropSafe(sl, "ADBE Transform Group", "ADBE Rotate Z");
            if (pCheck && pCheck.numKeys === 1) { try { pCheck.removeKey(1); } catch(e) {} }
            if (sCheck && sCheck.numKeys === 1) { try { sCheck.removeKey(1); } catch(e) {} }
            if (rCheck && rCheck.numKeys === 1) { try { rCheck.removeKey(1); } catch(e) {} }
            var busy = [];
            if (pCheck && pCheck.numKeys > 1) busy.push("Position");
            if (sCheck && sCheck.numKeys > 1) busy.push("Scale");
            if (rCheck && rCheck.numKeys > 1) busy.push("Rotation");
            if (busy.length > 0) {
                return { ok: false, error: "'" + sl.name + "' already has keyframes on " + busy.join(", ") + ". Remove them or Undo first." };
            }
        }

        _smMoveAnchorToCenter(targetLayer, t0);
        var targetPosProp = _getPropSafe(targetLayer, "ADBE Transform Group", "ADBE Position");
        var targetRotProp = _getPropSafe(targetLayer, "ADBE Transform Group", "ADBE Rotate Z");
        var targetOpProp = _getPropSafe(targetLayer, "ADBE Transform Group", "ADBE Opacity");
        if (targetPosProp && targetPosProp.dimensionsSeparated) {
            try { targetPosProp.dimensionsSeparated = false; } catch(de) {}
        }

        var realTargetScale = _smGetRealScale(targetLayer, t0);
        var realTargetRotVal = _smGetRealRotation(targetLayer, false, t0);
        var targetBounds = _smGetRealBounds(targetLayer, t0);
        var realTargetPosVal = _smGetRealPosition(targetLayer, false, t0);

        // If 2 layers share the exact same spot, delegate cleanly to Vector Shape Morph
        if (sources.length === 1) {
            var singleSrcPos = _smGetRealPosition(sources[0], false, t0);
            if (_smHypot(realTargetPosVal[0] - singleSrcPos[0], realTargetPosVal[1] - singleSrcPos[1]) < 4) {
                var infA = _extractShapeFromLayer(sources[0]);
                var infB = _extractShapeFromLayer(targetLayer);
                if (infA && infA.shape && infB && infB.shape) {
                    return _performVectorMorphPair(comp, sources[0], targetLayer, opts, false);
                }
            }
        }

        var swayStart1 = backwards ? 4 : 2;
        var swayStart2 = 3;
        var opacityKeyStart = backwards ? 4 : 2;

        // Shared Controller Null when morphing multiple sources (e.g. sliced pieces -> target)
        var ctrlLayerName = null;
        if (sources.length > 1) {
            var ctrlLayer = comp.layers.addNull();
            ctrlLayer.name = "SM Morph Controller";
            ctrlLayer.label = 11;
            try { ctrlLayer.moveBefore(ordered[0]); } catch(ce) {}
            _smEnsureMorphControllers(ctrlLayer, 100, 1.5, 1.0);
            ctrlLayerName = ctrlLayer.name;
        }

        var morphedSourceLayers = [];
        var morphedNames = [];
        var curTime = t0;
        var highestLayer = targetLayer;

        for (var i = 0; i < sources.length; i++) {
            var layer = sources[i];
            if (layer.outPoint < curTime) continue;

            // Parented layer pre-split exactly like Super Morphings
            if (layer.parent) {
                if (layer.inPoint < curTime) {
                    var oldLayer = layer;
                    layer = oldLayer.duplicate();
                    oldLayer.outPoint = curTime;
                }
                layer.inPoint = curTime;
                layer.parent = null;
            }

            _smMoveAnchorToCenter(layer, curTime);
            layer.enabled = true;
            if (layer.index < highestLayer.index) highestLayer = layer;

            var pos = _getPropSafe(layer, "ADBE Transform Group", "ADBE Position");
            var scale = _getPropSafe(layer, "ADBE Transform Group", "ADBE Scale");
            var rot = _getPropSafe(layer, "ADBE Transform Group", "ADBE Rotate Z");
            var op = _getPropSafe(layer, "ADBE Transform Group", "ADBE Opacity");
            if (pos && pos.dimensionsSeparated) {
                try { pos.dimensionsSeparated = false; } catch(pe) {}
            }

            var realScale = _smGetRealScale(layer, curTime);
            var bounds = _smGetRealBounds(layer, curTime);
            var curPosVal = pos.value;
            var realPosVal = _smGetRealPosition(layer, false, curTime);
            var offsetVal = _smGetRealPosition(layer, true, curTime);
            var newTargetVal = [realTargetPosVal[0] - offsetVal[0], realTargetPosVal[1] - offsetVal[1]];
            var mainVec = [realTargetPosVal[0] - realPosVal[0], realTargetPosVal[1] - realPosVal[1]];

            // Fallback nudge if overlapping exact target center so division never produces NaN
            if (Math.abs(mainVec[0]) < 1 && Math.abs(mainVec[1]) < 1) {
                mainVec = [1, 0];
            }
            var mainDir = (Math.abs(mainVec[0]) > 0.001) ? (mainVec[0] > 0 ? 1 : -1) : (mainVec[1] >= 0 ? 1 : -1);

            var posTimes = backwards
                ? [curTime, curTime + timeOffsets.main, (curTime + timeOffsets.post) - (i * staggerStep)]
                : [curTime, ((curTime + timeOffsets.post) - (i * staggerStep)) - timeOffsets.pre];
            var posValues = backwards ? [curPosVal, curPosVal, newTargetVal] : [curPosVal, newTargetVal];

            _smWorkWithPosition(pos, posTimes, posValues, curTime, timeOffsets.pre, frameDur, curPosVal, backwards, useArc);
            if (backwards) {
                _smApplyTemporalEase(pos, [1, 2], posInfluenceBackwards);
            } else {
                _smApplyTemporalEase(pos, [1], posInfluence);
            }

            var scaleTimes = backwards
                ? [scaleTimeOffset + curTime, scaleTimeOffset + curTime + (timeOffsets.post / 2), (scaleTimeOffset + curTime + timeOffsets.post) - (i * staggerStep)]
                : [curTime, ((curTime + (timeOffsets.post / 2)) - timeOffsets.pre) + (scaleTimeOffset / 2), ((curTime + timeOffsets.post) - timeOffsets.pre) + scaleTimeOffset];
            var rotTimes = backwards
                ? [rotTimeOffset + curTime, rotTimeOffset + curTime + (timeOffsets.post / 2), (rotTimeOffset + curTime + timeOffsets.post) - (i * staggerStep)]
                : [curTime, ((curTime + (timeOffsets.post / 2)) - timeOffsets.pre) + (rotTimeOffset / 2), ((curTime + timeOffsets.post) - timeOffsets.pre) + rotTimeOffset];

            var curScaleVal = scale.value;
            var denomW = Math.max(1, Math.abs(realScale[0] * bounds.width));
            var denomH = Math.max(1, Math.abs(realScale[1] * bounds.height));
            var newScaleVal = [
                Math.min(5000, Math.max(1, (100 * Math.abs(realTargetScale[0]) * targetBounds.width) / denomW)),
                Math.min(5000, Math.max(1, (100 * Math.abs(realTargetScale[1]) * targetBounds.height) / denomH))
            ];
            var squashVal = [curScaleVal[0] * SCALE_VAL, curScaleVal[1] * SCALE_VAL];
            if (curScaleVal.length >= 3) squashVal.push(curScaleVal[2]);

            var curRotVal = rot.value % 360;
            var realRotVal = _smGetRealRotation(layer, false, curTime);
            var rotOff = realRotVal - curRotVal;
            var newRotVal = realTargetRotVal - rotOff;
            if (newRotVal > 180) newRotVal -= 360;
            else if (newRotVal < -180) newRotVal += 360;

            scale.setValuesAtTimes(scaleTimes, [curScaleVal, squashVal, curScaleVal]);
            _smApplyTemporalEase(scale, [1, 2], scaleInfluence);

            if (!ctrlLayerName) {
                _smEnsureMorphControllers(layer, 100, 1.5, 1.0);
            }

            if (op) {
                op.expression = "try {\n" +
                    "p = transform.position;\n" +
                    "if (time < p.key(" + opacityKeyStart + ").time) 100;\n" +
                    "else 0;\n" +
                    "} catch(e) { value; }";
            }

            pos.expression = _smBuildElasticExpression(ctrlLayerName, 2000, false);
            scale.expression = _smBuildElasticExpression(ctrlLayerName, 200, true);

            // Transform Effect (ADBE Geometry2) scales Source into exact Target bounds + playful tilt
            var trEff = layer.property("ADBE Effect Parade").addProperty("ADBE Geometry2");
            trEff.name = "SM Transform";
            trEff.property("ADBE Geometry2-0011").setValue(false); // Uniform Scale OFF
            var sKeyIdx = backwards ? [0, 2] : [0, 1];
            trEff.property("ADBE Geometry2-0004").setValuesAtTimes([posTimes[sKeyIdx[0]], posTimes[sKeyIdx[1]]], [100, newScaleVal[0]]);
            trEff.property("ADBE Geometry2-0003").setValuesAtTimes([posTimes[sKeyIdx[0]], posTimes[sKeyIdx[1]]], [100, newScaleVal[1]]);
            _smApplyTemporalEase(trEff.property("ADBE Geometry2-0004"), [1], [[0.1, 99]]);
            _smApplyTemporalEase(trEff.property("ADBE Geometry2-0003"), [1], [[0.1, 99]]);

            rot.setValuesAtTimes([posTimes[sKeyIdx[0]], posTimes[sKeyIdx[1]]], [curRotVal, newRotVal]);
            _smApplyTemporalEase(rot, [1], [[0.1, 100]]);

            var effRot = trEff.property("ADBE Geometry2-0007");
            effRot.setValuesAtTimes(rotTimes, [0, mainDir * ROT_VAL, 0]);
            _smApplyTemporalEase(effRot, [1, 2], rotInfluence);
            effRot.expression = _smBuildElasticExpression(ctrlLayerName, 300, false);

            var appendix = ((layer instanceof ShapeLayer) || (layer instanceof TextLayer)) ? "transform.position" : "transform.anchorPoint";
            var geomPinExpr = "try {\n" +
                "if (hasParent) { parent.toComp(" + appendix + "); }\n" +
                "else { " + appendix + "; }\n" +
                "} catch(e) { value; }";
            trEff.property("ADBE Geometry2-0002").expression = geomPinExpr;
            trEff.property("ADBE Geometry2-0001").expression = geomPinExpr;

            if (useStretch) _smAddStretchEcho(layer);

            morphedSourceLayers.push(layer);
            morphedNames.push(layer.name);
            curTime += staggerStep;
        }

        if (morphedSourceLayers.length === 0) {
            return { ok: false, error: "No source layers were active at current timeline frame." };
        }

        targetLayer.enabled = true;
        if (targetOpProp) {
            targetOpProp.expression = 'try {\n100 - thisComp.layer("' + _smEscapeExprStr(morphedNames[0]) + '").transform.opacity;\n} catch(e) { value; }';
        }
        if (targetPosProp) {
            targetPosProp.expression = _smBuildTargetOvershootExpression(morphedNames, swayStart1, "[0, 0]", false, false);
        }
        var targetScProp = _getPropSafe(targetLayer, "ADBE Transform Group", "ADBE Scale");
        if (targetScProp) {
            targetScProp.expression = _smBuildTargetOvershootExpression(morphedNames, swayStart2, "[0, 0]", false, true);
        }
        if (targetRotProp) {
            targetRotProp.expression = _smBuildTargetOvershootExpression(morphedNames, swayStart2, "0", true, false);
        }

        return {
            ok: true,
            mode: "kinetic",
            sourceLayers: morphedSourceLayers,
            posLayer: morphedSourceLayers[0],
            targetLayer: targetLayer
        };
    }

    /**
     * Vector Shape Melt Morph (Square Bezier Path -> Circle Bezier Path + Fill/Stroke + Optional Kinetic Flight).
     */
    function _performVectorMorphPair(comp, layerA, layerB, opts, withKineticArc) {
        var t0 = opts.startTime;
        var fps = comp.frameRate || 30;
        var durationFrames = opts.durationFrames;
        var easeType = opts.easeType || "snappy";
        var style = opts.style || "direct";
        var useArc = (opts.arc !== false);
        var morphColor = (opts.morphColor !== false);
        var morphPosition = (opts.morphPosition !== false);
        var hideEndLayer = (opts.hideEndLayer !== false);

        _centerAnchorToVisualBounds(layerA, t0);
        _centerAnchorToVisualBounds(layerB, t0);

        var infoA = _extractShapeFromLayer(layerA);
        var infoB = _extractShapeFromLayer(layerB);
        if (!infoA || !infoA.shape || !infoB || !infoB.shape) {
            return { ok: false, error: "Vector Path Morph requires vector shape or mask layers (or switch Mode to Kinetic Morph)." };
        }

        var targetPathProp = _convertParametricToPath(layerA, infoA);
        if (!targetPathProp) {
            targetPathProp = infoA.prop;
        }
        if (!targetPathProp) {
            return { ok: false, error: "Could not convert start layer '" + layerA.name + "' to Bezier path." };
        }

        // Align target centroid onto source path centroid so Position handles comp placement cleanly
        var shapeA = infoA.shape;
        var shapeB = _translateShapeToCentroid(infoB.shape, _getShapeCentroid(shapeA));

        var targetVerts = Math.max(shapeA.vertices.length, shapeB.vertices.length, 24);
        var normShapeA = _subdivideShape(shapeA, targetVerts);
        var normShapeB = _subdivideShape(shapeB, targetVerts);
        normShapeB = _alignShapeVertices(normShapeA, normShapeB);

        var t1 = t0 + (durationFrames / fps);
        targetPathProp.setValueAtTime(t0, normShapeA);
        targetPathProp.setValueAtTime(t1, normShapeB);

        var easeInVal = 85, easeOutVal = 85;
        if (easeType === "smooth") { easeInVal = 50; easeOutVal = 50; }
        else if (easeType === "linear") { easeInVal = 0.1; easeOutVal = 0.1; }

        try {
            var kIdx1 = targetPathProp.nearestKeyIndex(t0);
            var kIdx2 = targetPathProp.nearestKeyIndex(t1);
            targetPathProp.setInterpolationTypeAtKey(kIdx1, KeyframeInterpolationType.BEZIER);
            targetPathProp.setInterpolationTypeAtKey(kIdx2, KeyframeInterpolationType.BEZIER);
        } catch(easeErr) {}

        // Morph Fill & Stroke colors
        if (morphColor) {
            try {
                var rootA = layerA.property("ADBE Root Vectors Group") || layerA.property("Contents");
                var rootB = layerB.property("ADBE Root Vectors Group") || layerB.property("Contents");
                var fillA = _findVectorFill(rootA);
                var fillB = _findVectorFill(rootB);
                if (fillA && fillB && fillA.canVaryOverTime) {
                    fillA.setValueAtTime(t0, fillA.value);
                    fillA.setValueAtTime(t1, fillB.value);
                    _applyPropertyEase(fillA, t0, t1, easeInVal, easeOutVal);
                }
                var strokeA = _findVectorStroke(rootA);
                var strokeB = _findVectorStroke(rootB);
                if (strokeA && strokeB) {
                    if (strokeA.color && strokeB.color && strokeA.color.canVaryOverTime) {
                        strokeA.color.setValueAtTime(t0, strokeA.color.value);
                        strokeA.color.setValueAtTime(t1, strokeB.color.value);
                        _applyPropertyEase(strokeA.color, t0, t1, easeInVal, easeOutVal);
                    }
                    if (strokeA.width && strokeB.width && strokeA.width.canVaryOverTime) {
                        strokeA.width.setValueAtTime(t0, strokeA.width.value);
                        strokeA.width.setValueAtTime(t1, strokeB.width.value);
                        _applyPropertyEase(strokeA.width, t0, t1, easeInVal, easeOutVal);
                    }
                }
            } catch(colErr) {}
        }

        // Trajectory Position (straight or kinetic arc + anticipation)
        var posProp = _getPropSafe(layerA, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layerA, "Transform", "Position");
        var posPropB = _getPropSafe(layerB, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layerB, "Transform", "Position");
        if (morphPosition && posProp && posPropB && posProp.canVaryOverTime && !posProp.dimensionsSeparated) {
            var posA = posProp.value;
            var posB = posPropB.value;
            var geom = _buildArcPoints(posA, posB, useArc, 1);
            if (geom.dist > 3) {
                if (withKineticArc) {
                    var dt = t1 - t0;
                    var tPre = t0 + dt * 0.18;
                    var tMid = t0 + dt * 0.50;
                    var pull = Math.min(geom.dist * 0.12, 60);
                    _setArrValueAtTime(posProp, t0, posA[0], posA[1]);
                    _setArrValueAtTime(posProp, tPre, posA[0] - geom.dirX * pull, posA[1] - geom.dirY * pull);
                    _setArrValueAtTime(posProp, tMid, geom.mid[0], geom.mid[1]);
                    _setArrValueAtTime(posProp, t1, posB[0], posB[1]);
                    try {
                        if (useArc) {
                            posProp.setSpatialAutoBezierAtKey(posProp.nearestKeyIndex(tPre), true);
                            posProp.setSpatialAutoBezierAtKey(posProp.nearestKeyIndex(tMid), true);
                        }
                    } catch(eSp) {}
                    _applyKeyframeEaseToRange(posProp, t0, t1, easeInVal, easeOutVal);
                } else {
                    _setArrValueAtTime(posProp, t0, posA[0], posA[1]);
                    _setArrValueAtTime(posProp, t1, posB[0], posB[1]);
                    _applyPropertyEase(posProp, t0, t1, easeInVal, easeOutVal);
                }
            }
        }

        // Scale Dynamics (Pure Native Keyframes)
        var scaleProp = _getPropSafe(layerA, "ADBE Transform Group", "ADBE Scale") || _getPropSafe(layerA, "Transform", "Scale");
        if (scaleProp && scaleProp.canVaryOverTime) {
            var curScale = scaleProp.value;
            var sx = curScale[0], sy = curScale[1];
            var dtS = t1 - t0;
            if (style === "liquid" || withKineticArc) {
                _setArrValueAtTime(scaleProp, t0, sx, sy);
                _setArrValueAtTime(scaleProp, t0 + dtS * 0.20, sx * 1.10, sy * 0.90);
                _setArrValueAtTime(scaleProp, t0 + dtS * 0.55, sx * 0.90, sy * 1.12);
                _setArrValueAtTime(scaleProp, t1, sx * 1.05, sy * 0.96);
                _setArrValueAtTime(scaleProp, t1 + 4 / fps, sx * 0.98, sy * 1.02);
                _setArrValueAtTime(scaleProp, t1 + 8 / fps, sx, sy);
                _applyKeyframeEaseToRange(scaleProp, t0, t1 + 8 / fps, 68, 68);
            } else if (style === "pop") {
                _setArrValueAtTime(scaleProp, t0, sx, sy);
                _setArrValueAtTime(scaleProp, t0 + dtS * 0.40, sx * 1.18, sy * 1.18);
                _setArrValueAtTime(scaleProp, t0 + dtS * 0.75, sx * 0.95, sy * 0.95);
                _setArrValueAtTime(scaleProp, t1, sx, sy);
                _applyKeyframeEaseToRange(scaleProp, t0, t1, 75, 75);
            }
        }

        if (hideEndLayer) {
            try { layerB.enabled = false; } catch(eHide) {}
        }

        return { ok: true, mode: "vector", tStart: t0, tEnd: t1, posLayer: layerA };
    }

    /**
     * Generates animated kinetic Bezier Trim Path Trails (matching Super Morphings Trails).
     */
    function _smCreateTrailControls(targetLayer, col, baseWidth) {
        var eff = targetLayer.property("ADBE Effect Parade");
        function addS(name, val) {
            var p = eff.addProperty("ADBE Slider Control");
            p.name = name;
            p.property(1).setValue(val);
            return p;
        }
        var cCtrl = eff.addProperty("ADBE Color Control");
        cCtrl.name = "SM Trail Color";
        cCtrl.property(1).setValue(col);

        addS("SM Trail Width", baseWidth);
        addS("SM Dash 1", 30);
        addS("SM Gap 1", 20);
        addS("SM Dash 2", 15);
        addS("SM Gap 2", 10);
        addS("SM Dash Offset", 0);
        addS("SM Random Seed", 1);
        addS("SM Random Dash", 15);
        addS("SM Random Gap", 15);
        addS("SM Random Offset", 50);
    }

    function _smTrailExpr(propName, randomName, allowNeg) {
        var minExpr = allowNeg ? "-rv" : "0";
        return 'try {\n' +
            'val = effect("' + propName + '")(1);\n' +
            'seed = effect("SM Random Seed")(1);\n' +
            'seedRandom(seed + thisProperty.propertyGroup(2).propertyIndex, true);\n' +
            'rv = effect("' + randomName + '")(1);\n' +
            'val + random(' + minExpr + ', rv);\n' +
            '} catch(e) { value; }';
    }

    function _smAddTrailsForLayers(comp, layers, trailOpts) {
        if (!comp || !layers || layers.length === 0) return 0;
        var count = Math.max(1, Math.min(12, parseInt(trailOpts.count, 10) || 4));
        var useDashes = (trailOpts.dashed !== false);
        var baseWidth = parseFloat(trailOpts.width) || 5;
        var frameDur = comp.frameDuration || (1.0 / (comp.frameRate || 30));
        var compW = comp.width, compH = comp.height;
        var tNow = comp.time;

        var ctrlLayerName = null;
        if (layers.length > 2) {
            var masterCtrl = comp.layers.addNull();
            masterCtrl.name = "SM Trails Controller";
            masterCtrl.label = 11;
            _smCreateTrailControls(masterCtrl, [1, 1, 1, 1], baseWidth);
            ctrlLayerName = masterCtrl.name;
        }

        var createdLayers = 0;
        for (var i = 0; i < layers.length; i++) {
            var layer = layers[i];
            if (!layer) continue;
            var pos = _getPropSafe(layer, "ADBE Transform Group", "ADBE Position") || _getPropSafe(layer, "Transform", "Position");
            if (!pos || pos.numKeys < 2) continue;

            var startKeyIndex = 1;
            try {
                if (pos.numKeys === 4 && pos.keyRoving(3)) startKeyIndex = 2;
            } catch(re) {}

            var bounds = _smGetRealBounds(layer, tNow);
            var scale = _smGetRealScale(layer, tNow);
            var anchProp = _getPropSafe(layer, "ADBE Transform Group", "ADBE Anchor Point") || _getPropSafe(layer, "Transform", "Anchor Point");
            var anchP = anchProp ? anchProp.valueAtTime(tNow, false) : [0, 0];
            var offX = ((bounds.left + bounds.width / 2) - anchP[0]) * scale[0];
            var offY = ((bounds.top + bounds.height / 2) - anchP[1]) * scale[1];

            var trailsLayer = comp.layers.addShape();
            trailsLayer.name = layer.name + " Trails";
            trailsLayer.label = 13;
            try { trailsLayer.moveAfter(layer); } catch(mvE) {}

            // Trails default to pure crisp white [1, 1, 1, 1];
            // only tinted when the user explicitly selects a color in the Trail Color box.
            var trailCol = [1, 1, 1, 1];
            if (trailOpts.color && trailOpts.color.length >= 3) {
                trailCol = [
                    Math.max(0, Math.min(1, parseFloat(trailOpts.color[0]) || 0)),
                    Math.max(0, Math.min(1, parseFloat(trailOpts.color[1]) || 0)),
                    Math.max(0, Math.min(1, parseFloat(trailOpts.color[2]) || 0)),
                    1
                ];
            }
            _smCreateTrailControls(trailsLayer, trailCol, baseWidth);

            if (ctrlLayerName) {
                var effG = trailsLayer.property("ADBE Effect Parade");
                for (var h = 1; h <= effG.numProperties; h++) {
                    var eSlider = effG.property(h).property(1);
                    if (eSlider && eSlider.canSetExpression) {
                        eSlider.expression = 'thisComp.layer("' + _smEscapeExprStr(ctrlLayerName) + '").effect(' + h + ')(1);';
                    }
                }
            }

            var rootVec = trailsLayer.property("ADBE Root Vectors Group");
            var validGroups = 0;

            for (var y = 0; y < count; y++) {
                var startOutEase = 33, endInEase = 33;
                var pts = [], inT = [], outT = [];
                var mainOffX = (Math.random() - 0.5) * bounds.width * Math.abs(scale[0]);
                var mainOffY = (Math.random() - 0.5) * bounds.height * Math.abs(scale[1]);

                for (var k = startKeyIndex; k <= pos.numKeys; k++) {
                    if (k === startKeyIndex) {
                        try { startOutEase = Math.max(0.1, Math.min(100, pos.keyOutTemporalEase(k)[0].influence)); } catch(e1) {}
                    }
                    if (k === pos.numKeys) {
                        try { endInEase = Math.max(0.1, Math.min(100, pos.keyInTemporalEase(k)[0].influence)); } catch(e2) {}
                    }
                    var kv = pos.keyValue(k);
                    var inTang = [0, 0], outTang = [0, 0];
                    try {
                        inTang = pos.keyInSpatialTangent(k);
                        outTang = pos.keyOutSpatialTangent(k);
                    } catch(te) {}
                    pts.push([kv[0] + offX + mainOffX - compW / 2, kv[1] + offY + mainOffY - compH / 2]);
                    inT.push([inTang[0], inTang[1]]);
                    outT.push([outTang[0], outTang[1]]);
                }
                if (pts.length < 2) continue;

                var grp = rootVec.addProperty("ADBE Vector Group");
                grp.name = "Trail " + (y + 1);
                var grpContents = grp.property("ADBE Vectors Group");

                var pathGrp = grpContents.addProperty("ADBE Vector Shape - Group");
                var trailShape = new Shape();
                trailShape.closed = false;
                trailShape.vertices = pts;
                trailShape.inTangents = inT;
                trailShape.outTangents = outT;
                (pathGrp.property("ADBE Vector Shape") || pathGrp.property(1)).setValue(trailShape);

                var stroke = grpContents.addProperty("ADBE Vector Graphic - Stroke");
                stroke.property("ADBE Vector Stroke Color").expression = 'effect("SM Trail Color")(1)';
                stroke.property("ADBE Vector Stroke Width").expression = 'effect("SM Trail Width")(1)';
                try { stroke.property("ADBE Vector Stroke Line Cap").setValue(2); } catch(lcE) {}

                if (useDashes) {
                    try {
                        var dashes = stroke.property("ADBE Vector Stroke Dashes");
                        var d1 = dashes.addProperty("ADBE Vector Stroke Dash 1");
                        d1.expression = _smTrailExpr("SM Dash 1", "SM Random Dash", false);
                        var g1 = dashes.addProperty("ADBE Vector Stroke Gap 1");
                        g1.expression = _smTrailExpr("SM Gap 1", "SM Random Gap", false);
                        var d2 = dashes.addProperty("ADBE Vector Stroke Dash 2");
                        d2.expression = _smTrailExpr("SM Dash 2", "SM Random Dash", false);
                        var g2 = dashes.addProperty("ADBE Vector Stroke Gap 2");
                        g2.expression = _smTrailExpr("SM Gap 2", "SM Random Gap", false);
                        var offP = dashes.property("ADBE Vector Stroke Offset");
                        if (offP) offP.expression = _smTrailExpr("SM Dash Offset", "SM Random Offset", true);
                    } catch(dashErr) {}
                }

                var trim = grpContents.addProperty("ADBE Vector Filter - Trim");
                var tStartTime = pos.keyTime(startKeyIndex);
                var tEndTime = pos.keyTime(pos.numKeys);
                if (tEndTime > tStartTime) {
                    var tStartProp = trim.property("ADBE Vector Trim Start");
                    var tEndProp = trim.property("ADBE Vector Trim End");
                    tStartProp.setValuesAtTimes([tStartTime, tEndTime], [0, 100]);
                    _smApplyTemporalEase(tStartProp, [1, 2], [[0.1, startOutEase], [endInEase, 0.1]]);

                    tEndProp.setValuesAtTimes([tStartTime + 3 * frameDur, tEndTime + 3 * frameDur], [0, 100]);
                    _smApplyTemporalEase(tEndProp, [1, 2], [[0.1, startOutEase], [endInEase, 0.1]]);
                }
                validGroups++;
            }

            if (validGroups > 0) {
                createdLayers++;
            } else {
                try { trailsLayer.remove(); } catch(rmE) {}
            }
        }
        return createdLayers;
    }

    _mdkPro.createSuperMorph = function(optionsStr) {
        var undoOpen = false;
        try {
            var options = {};
            if (optionsStr) {
                try { options = JSON.parse(optionsStr); } catch(e) { options = {}; }
            }

            var durationFrames = parseInt(options.durationFrames, 10) || 16;
            var mode = options.mode || "kinetic"; // "kinetic", "hybrid", or "vector"
            var arc = (options.arc !== false);
            var straight = (options.straight === true);
            var stretch = (options.stretch !== false);
            var easeType = options.easeType || "snappy";
            var style = options.style || "liquid";
            var order = options.order || "selection"; // "selection" | "bottom_to_top" | "top_to_bottom"
            var morphColor = (options.morphColor !== false);
            var morphPosition = (options.morphPosition !== false);
            var addTrails = (options.addTrails === true);
            var trailCount = parseInt(options.trailCount, 10) || 4;
            var hideEndLayer = (options.hideEndLayer !== false);

            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });

            var selLayers = comp.selectedLayers;
            if (!selLayers || selLayers.length < 2) {
                return JSON.stringify({ ok: false, error: "Select at least 2 layers (Source Layer 1st ➔ Target Layer Last)." });
            }

            // Build ordered sequence: default "selection" matches exact click selection order like Super Morphings!
            var ordered = [];
            for (var i = 0; i < selLayers.length; i++) ordered.push(selLayers[i]);
            if (order === "bottom_to_top") {
                ordered.sort(function(a, b) { return b.index - a.index; });
            } else if (order === "top_to_bottom") {
                ordered.sort(function(a, b) { return a.index - b.index; });
            }

            app.beginUndoGroup("MotionByDk Super Morph");
            undoOpen = true;

            var fps = comp.frameRate || 30;
            var totalTrailLayers = 0;

            if (mode === "kinetic") {
                var kineticRes = _performSuperMorphingBatch(comp, ordered, {
                    startTime: comp.time,
                    durationFrames: durationFrames,
                    arc: arc,
                    straight: straight,
                    stretch: stretch,
                    easeType: easeType,
                    style: style,
                    morphColor: morphColor,
                    morphPosition: morphPosition,
                    hideEndLayer: hideEndLayer
                });
                if (!kineticRes || !kineticRes.ok) {
                    throw new Error((kineticRes && kineticRes.error) ? kineticRes.error : "Kinetic morph failed.");
                }

                if (addTrails) {
                    var trailTargets = kineticRes.sourceLayers || (kineticRes.posLayer ? [kineticRes.posLayer] : []);
                    totalTrailLayers += _smAddTrailsForLayers(comp, trailTargets, {
                        count: trailCount,
                        dashed: true,
                        width: 5,
                        color: options.trailColor || null
                    });
                }
            } else {
                // Vector or Hybrid Sequential Chain
                var pairCount = ordered.length - 1;
                var trailSourceLayers = [];
                for (var p = 0; p < pairCount; p++) {
                    var lA = ordered[p];
                    var lB = ordered[p + 1];
                    var pairOpts = {
                        startTime: comp.time + (p * durationFrames * 0.65) / fps,
                        durationFrames: durationFrames,
                        arc: arc,
                        easeType: easeType,
                        style: style,
                        morphColor: morphColor,
                        morphPosition: morphPosition,
                        hideEndLayer: hideEndLayer
                    };
                    var vecRes = _performVectorMorphPair(comp, lA, lB, pairOpts, (mode === "hybrid"));
                    if (!vecRes || !vecRes.ok) {
                        throw new Error((vecRes && vecRes.error) ? vecRes.error : "Vector morph failed on pair " + (p + 1));
                    }
                    if (stretch && vecRes.posLayer) _smAddStretchEcho(vecRes.posLayer);
                    if (vecRes.posLayer) trailSourceLayers.push(vecRes.posLayer);
                }
                if (addTrails && trailSourceLayers.length > 0) {
                    totalTrailLayers += _smAddTrailsForLayers(comp, trailSourceLayers, {
                        count: trailCount,
                        dashed: true,
                        width: 5,
                        color: options.trailColor || null
                    });
                }
            }

            app.endUndoGroup();
            undoOpen = false;

            var trailSuffix = totalTrailLayers > 0 ? (" + Trails (" + totalTrailLayers + ")") : "";
            return JSON.stringify({
                ok: true,
                msg: "Super Morph (" + mode + "): '" + ordered[0].name + "' ➔ '" + ordered[ordered.length - 1].name + "'" + trailSuffix + "!",
                frames: durationFrames
            });
        } catch(err) {
            if (undoOpen) {
                try { app.endUndoGroup(); } catch(e) {}
            }
            return JSON.stringify({ ok: false, error: err.toString() + " (line " + (err.line || "?") + ")" });
        }
    };

    _mdkPro.addSuperTrails = function(optionsStr) {
        var undoOpen = false;
        try {
            var options = {};
            if (optionsStr) {
                try { options = JSON.parse(optionsStr); } catch(e) {}
            }
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            var sel = comp.selectedLayers;
            if (!sel || sel.length === 0) {
                return JSON.stringify({ ok: false, error: "Select a morphed/keyframed layer (with 2+ Position keyframes) to add Trails." });
            }

            app.beginUndoGroup("MotionByDk Super Morph Trails");
            undoOpen = true;
            var arr = [];
            for (var i = 0; i < sel.length; i++) arr.push(sel[i]);
            var total = _smAddTrailsForLayers(comp, arr, {
                count: options.count || 4,
                dashed: (options.dashed !== false),
                width: options.width || 5,
                color: options.color || null
            });
            app.endUndoGroup();
            undoOpen = false;

            if (total === 0) {
                return JSON.stringify({ ok: false, error: "Selected layer needs 2+ Position keyframes to generate Super Morph Trails." });
            }
            return JSON.stringify({ ok: true, msg: "Created Super Morph Trails on " + total + " layer(s)!" });
        } catch(err) {
            if (undoOpen) { try { app.endUndoGroup(); } catch(e) {} }
            return JSON.stringify({ ok: false, error: err.toString() });
        }
    };

    function _smGetSliceRows(num) {
        var count = Math.sqrt(num);
        var upDown = (count - Math.floor(count)) < 0.5 ? "up" : "down";
        count = Math.round(count);
        var arr = [];
        var residue = num % count;
        if (upDown === "down") residue = count - residue;
        while ((num / count) >= 1) {
            var add = 0;
            if (residue > 0 && upDown === "up") add = 1;
            else if (residue > 0 && upDown === "down") add = -1;
            if (residue > 0) residue--;
            var cur = Math.max(1, count + add);
            num -= cur;
            arr.push(cur);
        }
        if (num > 0) arr.push(num);
        return arr;
    }

    function _smBuildMosaicSliceObj(arrOfRows, diagonal) {
        var sliceObj = { rows: [] };
        for (var i = 0; i < arrOfRows.length; i++) {
            var cols = arrOfRows[i];
            var prevCols = i > 0 ? arrOfRows[i - 1] : null;
            var avgW = 100 / cols;
            var avgOff = avgW / 3.0;
            var topSpots = [];
            var bottomSpots = [];
            if (prevCols !== null && cols === prevCols) {
                topSpots = sliceObj.rows[i - 1].bottomSpots;
            }
            var sumT = 0, sumB = 0;
            for (var y = 0; y < cols - 1; y++) {
                var dir = (y % 2 === 0) ? 1 : -1;
                var w = Math.floor((avgW + dir * Math.random() * avgOff) * 1000) / 1000;
                if (cols !== prevCols) {
                    topSpots.push(w);
                    sumT += w;
                }
                if (!diagonal) {
                    bottomSpots.push(w);
                    sumB += w;
                } else {
                    var bw = Math.floor((avgW - dir * Math.random() * avgOff) * 1000) / 1000;
                    bottomSpots.push(bw);
                    sumB += bw;
                }
            }
            if (cols !== prevCols) topSpots.push(100 - sumT);
            bottomSpots.push(100 - sumB);
            sliceObj.rows.push({ topSpots: topSpots, bottomSpots: bottomSpots });
        }

        // Side spots (vertical row heights)
        var leftSpots = [], rightSpots = [];
        var len = arrOfRows.length;
        var avgH = 100 / len;
        var avgHOff = avgH / 3.0;
        var sumL = 0, sumR = 0;
        for (var j = 0; j < len - 1; j++) {
            var dir2 = (j % 2 === 0) ? 1 : -1;
            var lw = _smRoundP(avgH + dir2 * Math.random() * avgHOff, 1000);
            leftSpots.push(lw);
            sumL += lw;
            if (!diagonal) {
                rightSpots.push(lw);
                sumR += lw;
            } else {
                var rw = _smRoundP(avgH - dir2 * Math.random() * avgHOff, 1000);
                rightSpots.push(rw);
                sumR += rw;
            }
        }
        leftSpots.push(100 - sumL);
        rightSpots.push(100 - sumR);
        sliceObj.cols = { leftSpots: leftSpots, rightSpots: rightSpots };
        return sliceObj;
    }

    _mdkPro.sliceLayer = function(optionsStr) {
        var undoOpen = false;
        try {
            var options = {};
            if (optionsStr) {
                try { options = JSON.parse(optionsStr); } catch(e) {}
            }
            var count = Math.max(2, Math.min(25, parseInt(options.count, 10) || 4));
            var direction = options.direction || "diagonal"; // "diagonal" (Mosaic), "vertical", "horizontal"
            var staggerFrames = (typeof options.staggerFrames === "number") ? options.staggerFrames : 0;

            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            var sel = comp.selectedLayers;
            if (!sel || sel.length === 0) {
                return JSON.stringify({ ok: false, error: "Please select a layer to Slice." });
            }

            app.beginUndoGroup("MotionByDk Super Morph Slicer");
            undoOpen = true;
            var fps = comp.frameRate || 30;
            var slicedLayers = [];

            var layersToSlice = [];
            for (var s0 = 0; s0 < sel.length; s0++) layersToSlice.push(sel[s0]);

            for (var idx = 0; idx < layersToSlice.length; idx++) {
                var orig = layersToSlice[idx];
                var baseName = orig.name;
                var b = _smGetRealBounds(orig, comp.time);

                if (direction === "diagonal") {
                    // Authentic Super Morphings diagonal Voronoi-like grid slicing
                    var rows = _smGetSliceRows(count);
                    var sliceObj = _smBuildMosaicSliceObj(rows, true);
                    var cols = sliceObj.cols;
                    var w = b.width, h = b.height, top = b.top, left = b.left;
                    var curLY = 0, curRY = 0;
                    var pieceIdx = 1;

                    for (var bIdx = 0; bIdx < cols.leftSpots.length; bIdx++) {
                        var tlY = top + curLY * h;
                        var trY = top + curRY * h;
                        curLY += cols.leftSpots[bIdx] / 100.0;
                        curRY += cols.rightSpots[bIdx] / 100.0;
                        var blY = top + curLY * h;
                        var brY = top + curRY * h;

                        var topVec = [left + w - left, trY - tlY];
                        var topLen = _smHypot(topVec[0], topVec[1]) || 1;
                        var topNorm = [topVec[0] / topLen, topVec[1] / topLen];

                        var botVec = [left + w - left, brY - blY];
                        var botLen = _smHypot(botVec[0], botVec[1]) || 1;
                        var botNorm = [botVec[0] / botLen, botVec[1] / botLen];

                        var curTop = 0, curBot = 0;
                        var row = sliceObj.rows[bIdx];
                        for (var cIdx = 0; cIdx < row.topSpots.length; cIdx++) {
                            var tlPt = [left + topNorm[0] * curTop * topLen, tlY + topNorm[1] * curTop * topLen];
                            curTop += row.topSpots[cIdx] / 100.0;
                            var trPt = [left + topNorm[0] * curTop * topLen, tlY + topNorm[1] * curTop * topLen];

                            var blPt = [left + botNorm[0] * curBot * botLen, blY + botNorm[1] * curBot * botLen];
                            curBot += row.bottomSpots[cIdx] / 100.0;
                            var brPt = [left + botNorm[0] * curBot * botLen, blY + botNorm[1] * curBot * botLen];

                            var newL = orig.duplicate();
                            newL.name = baseName + " " + pieceIdx++;
                            try { newL.moveAfter(orig); } catch(mE) {}
                            if (staggerFrames > 0) newL.startTime += ((pieceIdx - 2) * staggerFrames) / fps;

                            var masks = newL.property("ADBE Mask Parade");
                            if (masks) {
                                var m = masks.addProperty("ADBE Mask Atom");
                                try { m.maskMode = MaskMode.ADD; } catch(mm) {}
                                var ms = new Shape();
                                ms.closed = true;
                                ms.vertices = [tlPt, trPt, brPt, blPt];
                                m.property("ADBE Mask Shape").setValue(ms);
                            }
                            _smMoveAnchorToCenter(newL, comp.time);
                            try { newL.blendingMode = BlendingMode.ALPHA_ADD; } catch(bm) {}
                            slicedLayers.push(newL);
                        }
                    }
                    try { orig.remove(); } catch(rmOrigE) {}
                } else {
                    // Clean Parallel Strips (Horizontal / Vertical)
                    var pad = 25;
                    var minX = b.left - pad;
                    var maxX = b.left + b.width + pad;
                    var minY = b.top - pad;
                    var maxY = b.top + b.height + pad;
                    var spanW = maxX - minX;
                    var spanH = maxY - minY;

                    for (var s = 0; s < count; s++) {
                        var sliceL = (s === 0) ? orig : orig.duplicate();
                        sliceL.name = baseName + " " + (s + 1);
                        if (s > 0) {
                            try { sliceL.moveAfter(slicedLayers[slicedLayers.length - 1]); } catch(mErr) {}
                        }
                        if (staggerFrames > 0) sliceL.startTime += (s * staggerFrames) / fps;

                        var masksS = sliceL.property("ADBE Mask Parade");
                        if (masksS) {
                            var msAtom = masksS.addProperty("ADBE Mask Atom");
                            try { msAtom.maskMode = MaskMode.ADD; } catch(mmErr) {}
                            var mShape = new Shape();
                            mShape.closed = true;
                            if (direction === "horizontal") {
                                var y0 = minY + (s / count) * spanH - 0.5;
                                var y1 = minY + ((s + 1) / count) * spanH + 0.5;
                                mShape.vertices = [[minX, y0], [maxX, y0], [maxX, y1], [minX, y1]];
                            } else {
                                var x0 = minX + (s / count) * spanW - 0.5;
                                var x1 = minX + ((s + 1) / count) * spanW + 0.5;
                                mShape.vertices = [[x0, minY], [x1, minY], [x1, maxY], [x0, maxY]];
                            }
                            msAtom.property("ADBE Mask Shape").setValue(mShape);
                        }
                        _smMoveAnchorToCenter(sliceL, comp.time);
                        try { sliceL.blendingMode = BlendingMode.ALPHA_ADD; } catch(bm2) {}
                        slicedLayers.push(sliceL);
                    }
                }
            }

            try {
                for (var c = 1; c <= comp.numLayers; c++) comp.layer(c).selected = false;
                for (var j = 0; j < slicedLayers.length; j++) slicedLayers[j].selected = true;
            } catch(selE) {}

            app.endUndoGroup();
            undoOpen = false;
            return JSON.stringify({ ok: true, msg: "Sliced into " + slicedLayers.length + " " + direction + " pieces (Shift-click target & hit Morph)!" });
        } catch(err) {
            if (undoOpen) { try { app.endUndoGroup(); } catch(e) {} }
            return JSON.stringify({ ok: false, error: err.toString() });
        }
    };

    // =========================================================================
    // 7. COMPOSITION & PROJECT MANAGER (RESIZE, NEW COMP, NEW FOLDER)
    // =========================================================================
    _mdkPro.resizeActiveComp = function(w, h) {
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            var newW = parseInt(w, 10);
            var newH = parseInt(h, 10);
            if (isNaN(newW) || newW <= 0 || isNaN(newH) || newH <= 0) {
                return JSON.stringify({ ok: false, error: "Invalid width or height: " + w + "x" + h });
            }
            app.beginUndoGroup("MotionByDk Resize Comp");
            comp.width = newW;
            comp.height = newH;
            app.endUndoGroup();
            return JSON.stringify({ ok: true, msg: "Comp resized to " + newW + " x " + newH + " px!", width: newW, height: newH });
        } catch(e) {
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    function _uniqueProjectItemName(baseName, parentFolder) {
        var existing = {};
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it && (!parentFolder || it.parentFolder === parentFolder)) {
                existing[it.name] = true;
            }
        }
        if (!existing[baseName]) return baseName;
        var idx = 2;
        while (existing[baseName + " " + idx]) idx++;
        return baseName + " " + idx;
    }

    function _nextAutoIndexedName(prefix, parentFolder) {
        var existing = {};
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it && (!parentFolder || it.parentFolder === parentFolder)) {
                existing[it.name] = true;
            }
        }
        var n = 1;
        while (existing[prefix + " " + n]) n++;
        return prefix + " " + n;
    }

    _mdkPro.createNewComp = function(optionsStr) {
        var undoOpen = false;
        try {
            var opts = {};
            if (optionsStr) { try { opts = JSON.parse(optionsStr); } catch(e) {} }
            var activeComp = _getActiveComp();
            var w = parseInt(opts.width, 10);
            var h = parseInt(opts.height, 10);
            if (isNaN(w) || w < 4) w = activeComp ? activeComp.width : 1920;
            if (isNaN(h) || h < 4) h = activeComp ? activeComp.height : 1080;
            var fps = parseFloat(opts.frameRate);
            if (isNaN(fps) || fps <= 0) fps = activeComp ? activeComp.frameRate : 30;
            var dur = parseFloat(opts.duration);
            if (isNaN(dur) || dur <= 0) dur = activeComp ? activeComp.duration : 10;

            var reqName = (opts.name && String(opts.name).replace(/^\s+|\s+$/g, "")) || "";
            var compName = reqName ? _uniqueProjectItemName(reqName, app.project.rootFolder) : _nextAutoIndexedName("Comp", app.project.rootFolder);

            app.beginUndoGroup("MotionByDk New Comp");
            undoOpen = true;
            var newComp = app.project.items.addComp(compName, w, h, 1, dur, fps);
            if (newComp) {
                try { newComp.openInViewer(); } catch(eV) {}
            }
            app.endUndoGroup();
            undoOpen = false;
            return JSON.stringify({
                ok: true,
                msg: "Created Comp '" + compName + "' (" + w + "x" + h + " @ " + fps + "fps)",
                name: compName,
                width: w,
                height: h
            });
        } catch(e) {
            if (undoOpen) { try { app.endUndoGroup(); } catch(eU) {} }
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    _mdkPro.createProjectFolder = function(optionsStr) {
        var undoOpen = false;
        try {
            var opts = {};
            if (optionsStr) { try { opts = JSON.parse(optionsStr); } catch(e) {} }

            // If user explicitly selected a single FolderItem in Project panel, create inside it
            var targetParent = app.project.rootFolder;
            try {
                if (app.project.selection && app.project.selection.length === 1 && (app.project.selection[0] instanceof FolderItem)) {
                    targetParent = app.project.selection[0];
                }
            } catch(selE) {}

            var reqName = (opts.name && String(opts.name).replace(/^\s+|\s+$/g, "")) || "";
            var fldName = reqName ? _uniqueProjectItemName(reqName, targetParent) : _nextAutoIndexedName("Folder", targetParent);

            app.beginUndoGroup("MotionByDk New Folder");
            undoOpen = true;
            var fld = app.project.items.addFolder(fldName);
            if (targetParent && targetParent !== app.project.rootFolder) {
                try { fld.parentFolder = targetParent; } catch(pfE) {}
            }
            try { fld.selected = true; } catch(sE) {}
            app.endUndoGroup();
            undoOpen = false;
            return JSON.stringify({
                ok: true,
                msg: "Created Folder '" + fldName + "'" + (targetParent !== app.project.rootFolder ? " inside '" + targetParent.name + "'" : ""),
                name: fldName
            });
        } catch(e) {
            if (undoOpen) { try { app.endUndoGroup(); } catch(eU) {} }
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    // =========================================================================
    // 8. SHAPE DASHES ENGINE (CLEAN INTEGER DEFAULTS & EXACT AE SYNC)
    // =========================================================================
    function _collectShapeStrokes(propGroup, outArr) {
        if (!propGroup || !propGroup.numProperties) return;
        for (var i = 1; i <= propGroup.numProperties; i++) {
            var p = propGroup.property(i);
            if (!p) continue;
            if (p.matchName === "ADBE Vector Graphic - Stroke") {
                outArr.push(p);
            } else if (p.numProperties && p.numProperties > 0) {
                _collectShapeStrokes(p, outArr);
            }
        }
    }

    function _getTargetShapeStrokes(comp) {
        var strokes = [];
        if (!comp) return strokes;
        var sel = comp.selectedLayers;
        if (!sel || sel.length === 0) return strokes;
        for (var i = 0; i < sel.length; i++) {
            var l = sel[i];
            if (!(l instanceof ShapeLayer)) continue;
            var contents = l.property("ADBE Root Vectors Group");
            if (contents) _collectShapeStrokes(contents, strokes);
        }
        return strokes;
    }

    function _ensureDashProp(dGroup, matchName) {
        var p = dGroup.property(matchName);
        if (!p || !p.canSetExpression) {
            try { dGroup.addProperty(matchName); } catch(e) {}
            p = dGroup.property(matchName);
        }
        return p;
    }

    _mdkPro.getShapeDashes = function() {
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, hasSelection: false, dash: 10, gap: 10, offset: 0 });
            var strokes = _getTargetShapeStrokes(comp);
            if (strokes.length === 0) {
                return JSON.stringify({ ok: true, hasSelection: false, dash: 10, gap: 10, offset: 0 });
            }
            var dGroup = strokes[0].property("ADBE Vector Stroke Dashes");
            if (!dGroup) {
                return JSON.stringify({ ok: true, hasSelection: true, enabled: false, dash: 10, gap: 10, offset: 0 });
            }

            var dashProp = dGroup.property("ADBE Vector Stroke Dash 1");
            var gapProp = dGroup.property("ADBE Vector Stroke Gap 1");
            var offProp = dGroup.property("ADBE Vector Stroke Offset");

            // In AE, hidden dash slots have canSetExpression === false until explicitly added via addProperty
            if (!dashProp || !dashProp.canSetExpression) {
                return JSON.stringify({ ok: true, hasSelection: true, enabled: false, dash: 10, gap: 10, offset: 0 });
            }

            var dashVal = (!isNaN(dashProp.value)) ? Math.round(dashProp.value) : 10;
            var gapVal = (gapProp && gapProp.canSetExpression && !isNaN(gapProp.value)) ? Math.round(gapProp.value) : dashVal;
            var offVal = (offProp && offProp.canSetExpression && !isNaN(offProp.value)) ? Math.round(offProp.value) : 0;

            return JSON.stringify({
                ok: true,
                hasSelection: true,
                enabled: true,
                dash: dashVal,
                gap: gapVal,
                offset: offVal
            });
        } catch(e) {
            return JSON.stringify({ ok: false, dash: 10, gap: 10, offset: 0, error: e.toString() });
        }
    };

    _mdkPro.setShapeDash = function(action, val) {
        var undoOpen = false;
        try {
            var comp = _getActiveComp();
            if (!comp) return JSON.stringify({ ok: false, error: "Please open an active composition." });
            var strokes = _getTargetShapeStrokes(comp);
            if (strokes.length === 0) {
                return JSON.stringify({ ok: false, error: "Please select a Shape Layer with a Stroke." });
            }

            var numVal = Math.round(parseFloat(val));
            if (isNaN(numVal)) numVal = (action === "offset") ? 0 : 10;
            if (action === "dash" || action === "gap") numVal = Math.max(0, numVal);

            app.beginUndoGroup("MotionByDk Shape Dashes");
            undoOpen = true;

            var updated = 0;
            var resDash = 10, resGap = 10, resOff = 0;

            for (var i = 0; i < strokes.length; i++) {
                var st = strokes[i];
                var dGroup = st.property("ADBE Vector Stroke Dashes");
                if (!dGroup) continue;

                try { st.enabled = true; } catch(se) {}

                if (action === "clear") {
                    for (var k = dGroup.numProperties; k >= 1; k--) {
                        var dp = dGroup.property(k);
                        if (dp && dp.canSetExpression && dp.matchName !== "ADBE Vector Stroke Offset") {
                            try { dp.remove(); } catch(remE) {}
                        }
                    }
                    updated++;
                    continue;
                }

                // Unhide Dash 1 if not active yet (preserving existing value if already active!)
                var dashProp = dGroup.property("ADBE Vector Stroke Dash 1");
                var wasDashHidden = !dashProp || !dashProp.canSetExpression;
                dashProp = _ensureDashProp(dGroup, "ADBE Vector Stroke Dash 1");
                if (wasDashHidden && dashProp && dashProp.canSetExpression) {
                    dashProp.setValue(action === "dash" ? numVal : 10);
                } else if (action === "dash" && dashProp && dashProp.canSetExpression) {
                    dashProp.setValue(numVal);
                }

                if (action === "gap") {
                    var gapProp = _ensureDashProp(dGroup, "ADBE Vector Stroke Gap 1");
                    if (gapProp && gapProp.canSetExpression) gapProp.setValue(numVal);
                } else if (action === "offset") {
                    var offProp = _ensureDashProp(dGroup, "ADBE Vector Stroke Offset");
                    if (offProp && offProp.canSetExpression) offProp.setValue(numVal);
                }

                var curD = dGroup.property("ADBE Vector Stroke Dash 1");
                var curG = dGroup.property("ADBE Vector Stroke Gap 1");
                var curO = dGroup.property("ADBE Vector Stroke Offset");
                resDash = (curD && curD.canSetExpression) ? Math.round(curD.value) : 10;
                resGap = (curG && curG.canSetExpression) ? Math.round(curG.value) : resDash;
                resOff = (curO && curO.canSetExpression) ? Math.round(curO.value) : 0;
                updated++;
            }

            app.endUndoGroup();
            undoOpen = false;
            return JSON.stringify({
                ok: true,
                updated: updated,
                dash: resDash,
                gap: resGap,
                offset: resOff
            });
        } catch(e) {
            if (undoOpen) { try { app.endUndoGroup(); } catch(eU) {} }
            return JSON.stringify({ ok: false, error: e.toString() });
        }
    };

    function _deleteFolderRecursive(folder) {
        if (!folder || !folder.exists) return;
        try {
            var files = folder.getFiles();
            for (var i = 0; i < files.length; i++) {
                if (files[i] instanceof Folder) {
                    _deleteFolderRecursive(files[i]);
                } else {
                    files[i].remove();
                }
            }
            folder.remove();
        } catch(e) {}
    }

    _mdkPro.cleanLegacyFolders = function() {
        try {
            var isWin = ($.os.indexOf("Windows") !== -1);
            var targets = [];
            if (isWin) {
                var appData = Folder.userData ? Folder.userData.fsName : "";
                var common = Folder.commonFiles ? Folder.commonFiles.fsName : "";
                if (appData) targets.push(appData + "\\Adobe\\CEP\\extensions\\MotionByDk AE Workflow");
                if (common) targets.push(common + "\\Adobe\\CEP\\extensions\\MotionByDk AE Workflow");
            } else {
                var userHome = Folder("~").fsName;
                targets.push(userHome + "/Library/Application Support/Adobe/CEP/extensions/MotionByDk AE Workflow");
                targets.push("/Library/Application Support/Adobe/CEP/extensions/MotionByDk AE Workflow");
            }

            var thisScript = new File($.fileName);
            var thisExtensionRoot = thisScript.parent.parent.fsName;

            for (var t = 0; t < targets.length; t++) {
                var oldF = new Folder(targets[t]);
                if (oldF.exists && oldF.fsName !== thisExtensionRoot) {
                    _deleteFolderRecursive(oldF);
                }
            }
            return "SUCCESS";
        } catch(err) {
            return "ERROR: " + err.toString();
        }
    };

    $._MDK_PRO = _mdkPro;
})();
