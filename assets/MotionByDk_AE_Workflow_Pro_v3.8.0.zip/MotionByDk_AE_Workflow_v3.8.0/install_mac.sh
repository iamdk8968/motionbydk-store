#!/usr/bin/env bash

# MotionByDk AEworkflow - macOS Installer (v3.8.0)
# Compatible with macOS Intel & Apple Silicon (M1/M2/M3/M4)

set -e

echo "========================================================================="
echo "             MOTIONBYDK AEWORKFLOW v3.8.0 INSTALLER (macOS)              "
echo "========================================================================="
echo ""

# 1. Enable PlayerDebugMode for all Adobe CSXS versions
echo "[1/4] Enabling PlayerDebugMode for Adobe CSXS versions..."
for v in 9 10 11 12 13 14 15 16 17; do
    defaults write "com.adobe.CSXS.${v}" PlayerDebugMode 1 2>/dev/null || true
    echo "  [+] Enabled com.adobe.CSXS.${v} PlayerDebugMode"
done
echo ""

# 2. Setup CEP extensions directory
CEP_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
TARGET_DIR="${CEP_DIR}/com.motionbydk.aeworkflow"
LEGACY_DIR="${CEP_DIR}/MotionByDk AE Workflow"

echo "[2/4] Cleaning previous / duplicate versions from CEP extensions..."
# Completely remove old version folders to prevent duplicates
rm -rf "${LEGACY_DIR}" 2>/dev/null || true
rm -rf "${TARGET_DIR}" 2>/dev/null || true
rm -rf "/Library/Application Support/Adobe/CEP/extensions/MotionByDk AE Workflow" 2>/dev/null || true
rm -rf "/Library/Application Support/Adobe/CEP/extensions/com.motionbydk.aeworkflow" 2>/dev/null || true
echo "  [+] Purged old extension directories"

mkdir -p "${TARGET_DIR}"

# 3. Clean and Copy Core Extension Files
echo ""
echo "[3/4] Installing core extension components (CSXS, client, host, bin)..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy main extension folders and files
cp -R "${SCRIPT_DIR}/CSXS" "${TARGET_DIR}/"
echo "  [+] Copied CSXS directory"

cp -R "${SCRIPT_DIR}/client" "${TARGET_DIR}/"
echo "  [+] Copied client directory"

cp -R "${SCRIPT_DIR}/host" "${TARGET_DIR}/"
echo "  [+] Copied host directory"

if [ -d "${SCRIPT_DIR}/bin" ]; then
    cp -R "${SCRIPT_DIR}/bin" "${TARGET_DIR}/"
    echo "  [+] Copied bin directory"
fi

if [ -f "${SCRIPT_DIR}/.debug" ]; then
    cp "${SCRIPT_DIR}/.debug" "${TARGET_DIR}/"
fi

# Clean any residual junk like .DS_Store from target
find "${TARGET_DIR}" -name ".DS_Store" -delete 2>/dev/null || true

# 4. Automatically Install Liquid Glass Plugin into all After Effects versions
if [ -d "${SCRIPT_DIR}/extra_plugins/Mac/ToolsForMotion" ]; then
    echo ""
    echo "[4/4] Installing Liquid Glass native plugin..."
    installed_count=0
    for ae_dir in /Applications/Adobe\ After\ Effects\ *; do
        if [ -d "${ae_dir}/Plug-ins" ]; then
            echo "  [+] Installing Liquid Glass to: ${ae_dir}/Plug-ins/ToolsForMotion"
            mkdir -p "${ae_dir}/Plug-ins/ToolsForMotion" 2>/dev/null || true
            cp -R "${SCRIPT_DIR}/extra_plugins/Mac/ToolsForMotion/LiquidGlass.plugin" "${ae_dir}/Plug-ins/ToolsForMotion/" 2>/dev/null || true
            xattr -dr com.apple.quarantine "${ae_dir}/Plug-ins/ToolsForMotion/LiquidGlass.plugin" 2>/dev/null || true
            installed_count=$((installed_count + 1))
        fi
    done
    if [ $installed_count -eq 0 ]; then
        echo "  [i] No default AE directory detected in /Applications, Liquid Glass staged."
    fi
fi

echo ""
echo "========================================================================="
echo "                        INSTALLATION COMPLETED!                          "
echo "========================================================================="
echo ""
echo "MotionByDk AE Workflow v3.8.0 installed cleanly."
echo "Old duplicate versions have been completely removed."
echo "Liquid Glass native plugin installed successfully."
echo ""
echo "IMPORTANT NEXT STEPS:"
echo "  1. Restart Adobe After Effects."
echo "  2. Go to: After Effects > Settings/Preferences > Scripting & Expressions"
echo "  3. CHECK: [✔] 'Allow Scripts to Write Files and Access Network'"
echo "  4. Open: Window > Extensions > MotionByDk AEworkflow"
echo ""
echo "For any help: motionbydk@gmail.com"
echo "========================================================================="
echo ""
