/**
 * MotionByDk Pro Engine v3.6.1
 * Extensions:
 *   1. Dynamic Theme Switcher (6 Curated Motion Designer Themes)
 *   2. Speed Graph vs Value Graph Dual-Overlay Engine with Real-Time Ghost Curve & Onion Skin
 *   3. Ultra-Fast Synchronous Bezier Updates & Invert Curve Engine (Zero Lag via rAF)
 *   4. Side-by-Side Dual View (Split Screen Workspace: Workflow on Left + Graph/Tools on Right)
 *   5. Detachable / Undockable Tab Palettes & 1-Click Reset Layout
 *   6. EaseCopy & Native AE Extension Pop-Out Engine
 * Author: Dhananjay K. (MotionByDk)
 */

(function (window, document) {
    "use strict";

    var cs = null;
    try {
        if (typeof CSInterface === "function") cs = new CSInterface();
    } catch (e) { cs = null; }

    // Ensure SystemPath constants exist
    if (typeof window.SystemPath === "undefined") {
        window.SystemPath = {
            USER_DATA: "userData",
            COMMON_FILES: "commonFiles",
            MY_DOCUMENTS: "myDocuments",
            APPLICATION: "application",
            EXTENSION: "extension",
            HOST_APPLICATION: "hostApplication"
        };
    }

    function getExtensionRoot() {
        // 1. CSInterface getSystemPath("extension")
        if (cs && typeof cs.getSystemPath === "function") {
            try {
                var p1 = cs.getSystemPath("extension");
                if (p1 && typeof p1 === "string" && p1.length > 2) return p1.replace(/\\/g, "/");
            } catch (e) { }
        }
        // 2. CEP Window API fallback
        try {
            if (typeof window !== "undefined" && window.__adobe_cep__ && typeof window.__adobe_cep__.getSystemPath === "function") {
                var p2 = window.__adobe_cep__.getSystemPath("extension");
                if (p2 && typeof p2 === "string" && p2.length > 2) return p2.replace(/\\/g, "/");
            }
        } catch (e) { }
        // 3. Node.js fallback via __dirname
        try {
            if (typeof require === "function") {
                var pathMod = require("path");
                var fsMod = require("fs");
                if (typeof __dirname !== "undefined" && __dirname) {
                    var c1 = pathMod.resolve(__dirname, "..");
                    if (fsMod.existsSync(pathMod.join(c1, "host"))) return c1.replace(/\\/g, "/");
                    var c2 = pathMod.resolve(__dirname, "../..");
                    if (fsMod.existsSync(pathMod.join(c2, "host"))) return c2.replace(/\\/g, "/");
                }
            }
        } catch (e) { }
        return "";
    }

    function getHostScriptPath() {
        var root = getExtensionRoot();
        if (root) {
            return (root + "/host/MotionByDk_ProFeatures.jsx").replace(/\\/g, "/");
        }
        return "";
    }

    // =========================================================================
    // 1. NON-BLOCKING TOAST NOTIFICATION SYSTEM
    // =========================================================================
    var MDK_Toast = {
        toastEl: null,
        timeout: null,
        init: function () {
            if (this.toastEl) return;
            var el = document.createElement("div");
            el.id = "mdk-toast";
            el.style.cssText = "position:fixed; bottom:14px; left:50%; transform:translateX(-50%); " +
                "background:rgba(18,18,18,0.96); color:#ffffff; padding:7px 16px; border-radius:20px; " +
                "font-size:11px; font-weight:700; border:1px solid var(--accent-orange, #ff7a00); " +
                "box-shadow:0 8px 30px rgba(0,0,0,0.8); z-index:99999; display:none; pointer-events:none; " +
                "transition:opacity 0.2s, transform 0.2s; white-space:nowrap;";
            document.body.appendChild(el);
            this.toastEl = el;
        },
        show: function (msg, type) {
            this.init();
            var el = this.toastEl;
            var icon = '<i class="fa-solid fa-circle-check" style="color:var(--accent-orange, #ff7a00); margin-right:6px;"></i>';
            if (type === "error") {
                icon = '<i class="fa-solid fa-triangle-exclamation" style="color:#ff4444; margin-right:6px;"></i>';
            } else if (type === "info") {
                icon = '<i class="fa-solid fa-circle-info" style="color:#38bdf8; margin-right:6px;"></i>';
            }
            el.innerHTML = icon + msg;
            el.style.display = "block";
            el.style.opacity = "1";
            el.style.transform = "translateX(-50%) translateY(0)";
            clearTimeout(this.timeout);
            this.timeout = setTimeout(function () {
                el.style.opacity = "0";
                el.style.transform = "translateX(-50%) translateY(8px)";
                setTimeout(function () { el.style.display = "none"; }, 200);
            }, 2600);
        }
    };

    // =========================================================================
    // 2. DYNAMIC THEME SWITCHER ENGINE
    // =========================================================================
    var MDK_ThemeEngine = {
        THEMES: [
            {
                id: "dk_orange",
                name: "DK Studio Orange",
                accent: "#ff7a00",
                hover: "#ff8e1a",
                dark: "#d66400",
                glow: "rgba(255, 122, 0, 0.45)",
                grad: "linear-gradient(135deg, #ff7a00 0%, #ff4500 100%)",
                bg: "#0a0a0a",
                border: "rgba(255, 122, 0, 0.45)",
                swatch: ["#ff7a00", "#ff4500", "#0a0a0a"]
            },
            {
                id: "cyber_cyan",
                name: "Cyber Cyan",
                accent: "#00f0ff",
                hover: "#33f3ff",
                dark: "#00b8c4",
                glow: "rgba(0, 240, 255, 0.45)",
                grad: "linear-gradient(135deg, #00f0ff 0%, #0077ff 100%)",
                bg: "#060b11",
                border: "rgba(0, 240, 255, 0.45)",
                swatch: ["#00f0ff", "#0077ff", "#060b11"]
            },
            {
                id: "neon_violet",
                name: "Neon Violet",
                accent: "#a855f7",
                hover: "#ba75ff",
                dark: "#7e22ce",
                glow: "rgba(168, 85, 247, 0.45)",
                grad: "linear-gradient(135deg, #a855f7 0%, #6366f1 100%)",
                bg: "#0b0713",
                border: "rgba(168, 85, 247, 0.45)",
                swatch: ["#a855f7", "#6366f1", "#0b0713"]
            },
            {
                id: "electric_emerald",
                name: "Electric Emerald",
                accent: "#10b981",
                hover: "#34d399",
                dark: "#059669",
                glow: "rgba(16, 185, 129, 0.45)",
                grad: "linear-gradient(135deg, #10b981 0%, #047857 100%)",
                bg: "#060f0a",
                border: "rgba(16, 185, 129, 0.45)",
                swatch: ["#10b981", "#047857", "#060f0a"]
            },
            {
                id: "sunset_rose",
                name: "Sunset Rose",
                accent: "#f43f5e",
                hover: "#fb7185",
                dark: "#be123c",
                glow: "rgba(244, 63, 94, 0.45)",
                grad: "linear-gradient(135deg, #f43f5e 0%, #e11d48 100%)",
                bg: "#110609",
                border: "rgba(244, 63, 94, 0.45)",
                swatch: ["#f43f5e", "#e11d48", "#110609"]
            },
            {
                id: "titanium_silver",
                name: "Titanium Silver",
                accent: "#e2e8f0",
                hover: "#ffffff",
                dark: "#94a3b8",
                glow: "rgba(226, 232, 240, 0.35)",
                grad: "linear-gradient(135deg, #ffffff 0%, #64748b 100%)",
                bg: "#0c0c0c",
                border: "rgba(226, 232, 240, 0.45)",
                swatch: ["#ffffff", "#64748b", "#0c0c0c"]
            }
        ],

        activeTheme: "dk_orange",
        strokeStyle: "default",

        init: function () {
            var saved = null;
            try { saved = localStorage.getItem("motionbydk_theme"); } catch (e) {}
            if (saved && this.getTheme(saved)) {
                this.setTheme(saved, false);
            } else {
                this.setTheme("dk_orange", false);
            }

            var savedStroke = null;
            try { savedStroke = localStorage.getItem("motionbydk_stroke_style"); } catch (e) {}
            if (savedStroke) {
                this.setStrokeStyle(savedStroke, false);
            } else {
                this.setStrokeStyle("default", false);
            }
        },

        setStrokeStyle: function (style, showToast) {
            this.strokeStyle = style || "default";
            try { localStorage.setItem("motionbydk_stroke_style", this.strokeStyle); } catch (e) {}

            var styleEl = document.getElementById("mdk-stroke-dynamic-styles");
            if (!styleEl) {
                styleEl = document.createElement("style");
                styleEl.id = "mdk-stroke-dynamic-styles";
                document.head.appendChild(styleEl);
            }

            if (this.strokeStyle === "solid") {
                styleEl.innerHTML =
                    ".section-box, .section-box-elevated { " +
                    "  border: 1.5px solid var(--accent-orange) !important; " +
                    "  box-shadow: 0 0 10px var(--accent-orange-glow) !important; " +
                    "}";
            } else {
                this.strokeStyle = "default";
                styleEl.innerHTML =
                    ".section-box { " +
                    "  border: 1px solid #282828 !important; " +
                    "  box-shadow: none !important; " +
                    "}";
            }

            var btns = ["default", "solid"];
            for (var b = 0; b < btns.length; b++) {
                var el = document.getElementById("mdk-stroke-btn-" + btns[b]);
                if (el) {
                    if (btns[b] === this.strokeStyle) {
                        el.style.borderColor = "var(--accent-orange)";
                        el.style.color = "var(--accent-orange)";
                        el.style.background = "rgba(255, 122, 0, 0.16)";
                        el.style.fontWeight = "800";
                    } else {
                        el.style.borderColor = "#333";
                        el.style.color = "#888";
                        el.style.background = "#181818";
                        el.style.fontWeight = "600";
                    }
                }
            }

            if (showToast) {
                var label = (this.strokeStyle === "solid") ? "Solid Color Stroke" : "Default Border";
                MDK_Toast.show("Section stroke set to <strong>" + label + "</strong>");
            }
        },

        getTheme: function (id) {
            for (var i = 0; i < this.THEMES.length; i++) {
                if (this.THEMES[i].id === id) return this.THEMES[i];
            }
            return this.THEMES[0];
        },

        setTheme: function (id, showToast) {
            var theme = this.getTheme(id);
            this.activeTheme = theme.id;
            try { localStorage.setItem("motionbydk_theme", theme.id); } catch (e) {}

            var r = document.documentElement;
            r.style.setProperty("--accent-orange", theme.accent);
            r.style.setProperty("--accent-orange-hover", theme.hover);
            r.style.setProperty("--accent-orange-dark", theme.dark);
            r.style.setProperty("--accent-orange-glow", theme.glow);
            r.style.setProperty("--accent-purple", theme.accent);
            r.style.setProperty("--accent-purple-glow", theme.glow);
            r.style.setProperty("--grad-primary", theme.grad);
            r.style.setProperty("--border-accent", theme.border);
            r.style.setProperty("--bg-body", theme.bg);

            // Re-apply stroke styles so colors match the new theme accent/gradient
            if (this.strokeStyle) {
                this.setStrokeStyle(this.strokeStyle, false);
            }

            // Update SVG Graph handle and tangent line colors
            try {
                var h1 = document.getElementById("hLine1");
                var h2 = document.getElementById("hLine2");
                var handle1 = document.getElementById("handle1");
                var handle2 = document.getElementById("handle2");
                if (h1) h1.setAttribute("stroke", theme.accent);
                if (h2) h2.setAttribute("stroke", theme.accent);
                if (handle1) handle1.style.background = theme.accent;
                if (handle2) handle2.style.background = theme.accent;
            } catch (eSvg) {}

            // Update theme modal card active classes if open
            var cards = document.querySelectorAll(".mdk-theme-card");
            for (var c = 0; c < cards.length; c++) {
                cards[c].classList.toggle("active", cards[c].dataset.theme === theme.id);
            }

            if (showToast) {
                MDK_Toast.show("Theme switched to <strong>" + theme.name + "</strong>");
            }
        },

        openThemeModal: function () {
            var modal = document.getElementById("mdk-theme-modal");
            if (!modal) {
                modal = document.createElement("div");
                modal.id = "mdk-theme-modal";
                modal.className = "modal-overlay";
                modal.style.display = "flex";
                modal.innerHTML =
                    '<div class="section-box" style="width:320px; max-width:90vw; background:#121212; border:1px solid var(--accent-orange); border-radius:8px; padding:18px; box-shadow:0 12px 50px rgba(0,0,0,0.9); text-align:center;">' +
                    '  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
                    '    <h3 style="margin:0; font-size:14px; font-weight:800; color:#fff; display:flex; align-items:center; gap:8px;">' +
                    '      <i class="fa-solid fa-palette" style="color:var(--accent-orange);"></i> UI Theme Switcher' +
                    '    </h3>' +
                    '    <button onclick="MDK_ThemeEngine.closeThemeModal()" style="background:none; border:none; color:#888; cursor:pointer; font-size:14px;"><i class="fa-solid fa-xmark"></i></button>' +
                    '  </div>' +
                    '  <div style="font-size:10px; color:#888; margin-bottom:14px; text-align:left;">Choose your preferred aesthetic style for MotionByDk:</div>' +
                    '  <div id="mdk-theme-grid" style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:14px;"></div>' +
                    '  <div style="margin-top:10px; text-align:left; border-top:1px solid rgba(255,255,255,0.08); padding-top:12px;">' +
                    '    <div style="font-size:11px; font-weight:700; color:#eee; margin-bottom:7px; display:flex; align-items:center; gap:6px;">' +
                    '      <i class="fa-solid fa-border-all" style="color:var(--accent-orange);"></i> Section Card Stroke Style:' +
                    '    </div>' +
                    '    <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:14px;">' +
                    '      <button id="mdk-stroke-btn-default" onclick="MDK_ThemeEngine.setStrokeStyle(\'default\', true)" class="btn-layer" style="padding:7px 2px; font-size:10px; text-align:center;">Default</button>' +
                    '      <button id="mdk-stroke-btn-solid" onclick="MDK_ThemeEngine.setStrokeStyle(\'solid\', true)" class="btn-layer" style="padding:7px 2px; font-size:10px; text-align:center;">Solid Color</button>' +
                    '    </div>' +
                    '  </div>' +
                    '  <button onclick="MDK_ThemeEngine.closeThemeModal()" class="btn-orange" style="width:100%; padding:8px; font-weight:bold; font-size:11px;">Done</button>' +
                    '</div>';
                document.body.appendChild(modal);
            } else {
                modal.style.display = "flex";
            }

            var grid = document.getElementById("mdk-theme-grid");
            if (grid) {
                grid.innerHTML = "";
                for (var i = 0; i < this.THEMES.length; i++) {
                    var th = this.THEMES[i];
                    var isActive = th.id === this.activeTheme;
                    var card = document.createElement("div");
                    card.className = "mdk-theme-card" + (isActive ? " active" : "");
                    card.dataset.theme = th.id;
                    card.style.cssText = "background:#181818; border:1px solid " + (isActive ? th.accent : "#282828") + "; " +
                        "border-radius:6px; padding:8px 10px; cursor:pointer; text-align:left; transition:all 0.15s; position:relative;";
                    card.innerHTML =
                        '<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:6px;">' +
                        '  <span style="font-size:11px; font-weight:700; color:' + (isActive ? th.accent : "#ddd") + ';">' + th.name + '</span>' +
                        '  <div style="width:8px; height:8px; border-radius:50%; background:' + th.accent + ';"></div>' +
                        '</div>' +
                        '<div style="display:flex; height:6px; border-radius:3px; overflow:hidden;">' +
                        '  <div style="flex:1; background:' + th.swatch[0] + ';"></div>' +
                        '  <div style="flex:1; background:' + th.swatch[1] + ';"></div>' +
                        '  <div style="flex:1; background:' + th.swatch[2] + ';"></div>' +
                        '</div>';
                    (function (themeId) {
                        card.onclick = function () {
                            MDK_ThemeEngine.setTheme(themeId, true);
                        };
                    })(th.id);
                    grid.appendChild(card);
                }
            }

            // Sync active stroke button state
            this.setStrokeStyle(this.strokeStyle, false);
        },

        closeThemeModal: function () {
            var modal = document.getElementById("mdk-theme-modal");
            if (modal) modal.style.display = "none";
        }
    };

    // =========================================================================
    // 3. ZERO-LAG SPEED GRAPH / VALUE GRAPH DUAL-OVERLAY & BEZIER ENGINE
    // =========================================================================
    var MDK_GraphEngine = {
        mode: "value", // "value" | "speed"
        showGhost: true,
        ghostOpacity: 0.38,
        onionEnabled: true,
        lastAppliedCurve: null,
        _raf: null,

        init: function () {
            var self = this;

            // Load saved preferences
            try {
                var savedMode = localStorage.getItem("mdk_graph_mode");
                if (savedMode) self.mode = savedMode;
                var savedGhost = localStorage.getItem("mdk_graph_ghost");
                if (savedGhost !== null) self.showGhost = savedGhost === "1";
                var savedOp = localStorage.getItem("mdk_graph_ghost_op");
                if (savedOp) self.ghostOpacity = parseFloat(savedOp);
                var savedOnion = localStorage.getItem("mdk_graph_onion");
                if (savedOnion) self.lastAppliedCurve = JSON.parse(savedOnion);
            } catch (e) {}

            // Hook window.updateGraphUI smoothly via requestAnimationFrame (Eliminates lag completely)
            if (typeof window.updateGraphUI === "function" && !window._mdkUpdateGraphUIHooked) {
                var origUpdate = window.updateGraphUI;
                window.updateGraphUI = function () {
                    var r = origUpdate.apply(this, arguments);
                    self.scheduleOverlayRender();
                    return r;
                };
                window._mdkUpdateGraphUIHooked = true;
            }

            // Hook window.applyGraphEasing to capture onion skin history
            if (typeof window.applyGraphEasing === "function" && !window._mdkApplyGraphHooked) {
                var origApply = window.applyGraphEasing;
                window.applyGraphEasing = function () {
                    var pts = self.getCurrentBezierPts();
                    if (pts) {
                        self.lastAppliedCurve = pts.slice();
                        try { localStorage.setItem("mdk_graph_onion", JSON.stringify(pts)); } catch (e) {}
                    }
                    var r = origApply.apply(this, arguments);
                    self.scheduleOverlayRender();
                    MDK_Toast.show("Applied Easing: <strong>" + (pts ? pts.map(function(n){return n.toFixed(2);}).join(", ") : "") + "</strong>");
                    return r;
                };
                window._mdkApplyGraphHooked = true;
            }

            // Hook window.readGraphEasing so reading keyframes immediately refreshes overlay/handles
            if (typeof window.readGraphEasing === "function" && !window._mdkReadGraphHooked) {
                var origReadGraph = window.readGraphEasing;
                window.readGraphEasing = function () {
                    var r = origReadGraph.apply(this, arguments);
                    setTimeout(function () { self.scheduleOverlayRender(); }, 60);
                    return r;
                };
                window._mdkReadGraphHooked = true;
            }

            // Hook #bezier-values input/change for smooth live Bezier handle & ghost updates
            var bvInput = document.getElementById("bezier-values");
            if (bvInput && !bvInput._mdkHooked) {
                bvInput.addEventListener("input", function () { self.scheduleOverlayRender(); });
                bvInput.addEventListener("change", function () { self.scheduleOverlayRender(); });
                bvInput._mdkHooked = true;
            }

            // Hook handle mouseup to ensure final state is drawn
            var h1 = document.getElementById("handle1");
            var h2 = document.getElementById("handle2");
            if (h1) h1.addEventListener("mouseup", function() { self.scheduleOverlayRender(); });
            if (h2) h2.addEventListener("mouseup", function() { self.scheduleOverlayRender(); });

            // Initial render
            setTimeout(function () { self.renderDualOverlay(); }, 150);
        },

        scheduleOverlayRender: function () {
            var self = this;
            if (self._raf) return;
            self._raf = (window.requestAnimationFrame || setTimeout)(function () {
                self._raf = null;
                self.renderDualOverlay();
            });
        },

        getCurrentBezierPts: function () {
            // Check bezierPts object properties (.x1, .y1, .x2, .y2)
            if (typeof window.bezierPts === "object" && window.bezierPts !== null) {
                if (typeof window.bezierPts.x1 === "number" && !isNaN(window.bezierPts.x1)) {
                    return [
                        window.bezierPts.x1,
                        window.bezierPts.y1,
                        window.bezierPts.x2,
                        window.bezierPts.y2
                    ];
                }
                if (typeof window.bezierPts[0] === "number" && !isNaN(window.bezierPts[0])) {
                    return [
                        window.bezierPts[0],
                        window.bezierPts[1],
                        window.bezierPts[2],
                        window.bezierPts[3]
                    ];
                }
            }
            // Fallback to reading #bezier-values input
            var valInput = document.getElementById("bezier-values");
            if (valInput && valInput.value) {
                var parts = valInput.value.split(",").map(function (v) { return parseFloat(v.trim()); });
                if (parts.length === 4 && !isNaN(parts[0])) return parts;
            }
            return [0.25, 0.1, 0.25, 1.0];
        },

        // DIRECT, SYNCHRONOUS UPDATE OF HANDLES, LINES, PATH AND INPUT (NO DELAY)
        applyBezierToUI: function (x1, y1, x2, y2) {
            x1 = Math.max(0, Math.min(1, parseFloat(x1) || 0));
            y1 = parseFloat(y1) || 0;
            x2 = Math.max(0, Math.min(1, parseFloat(x2) || 1));
            y2 = parseFloat(y2) || 1;

            // Sync global bezierPts object in both named properties and index properties
            if (typeof window.bezierPts === "object" && window.bezierPts !== null) {
                window.bezierPts.x1 = x1;
                window.bezierPts.y1 = y1;
                window.bezierPts.x2 = x2;
                window.bezierPts.y2 = y2;
                window.bezierPts[0] = x1;
                window.bezierPts[1] = y1;
                window.bezierPts[2] = x2;
                window.bezierPts[3] = y2;
            } else {
                window.bezierPts = { x1: x1, y1: y1, x2: x2, y2: y2, 0: x1, 1: y1, 2: x2, 3: y2 };
            }
            if (typeof vmF_ef6e81 !== "undefined" && vmF_ef6e81.bezierPts) {
                vmF_ef6e81.bezierPts.x1 = x1;
                vmF_ef6e81.bezierPts.y1 = y1;
                vmF_ef6e81.bezierPts.x2 = x2;
                vmF_ef6e81.bezierPts.y2 = y2;
                vmF_ef6e81.bezierPts[0] = x1;
                vmF_ef6e81.bezierPts[1] = y1;
                vmF_ef6e81.bezierPts[2] = x2;
                vmF_ef6e81.bezierPts[3] = y2;
            }

            // Immediately update DOM elements directly (handles, lines, SVG curve path)
            var h1 = document.getElementById("handle1");
            var h2 = document.getElementById("handle2");
            var hl1 = document.getElementById("hLine1");
            var hl2 = document.getElementById("hLine2");
            var path = document.getElementById("bezier-path");
            var valInput = document.getElementById("bezier-values");

            var h1x = (x1 * 100).toFixed(1);
            var h1y = ((1 - y1) * 100).toFixed(1);
            var h2x = (x2 * 100).toFixed(1);
            var h2y = ((1 - y2) * 100).toFixed(1);

            if (h1) {
                h1.style.left = h1x + "%";
                h1.style.top = h1y + "%";
            }
            if (h2) {
                h2.style.left = h2x + "%";
                h2.style.top = h2y + "%";
            }
            if (hl1) {
                hl1.setAttribute("x1", "0");
                hl1.setAttribute("y1", "100");
                hl1.setAttribute("x2", h1x);
                hl1.setAttribute("y2", h1y);
            }
            if (hl2) {
                hl2.setAttribute("x1", "100");
                hl2.setAttribute("y1", "0");
                hl2.setAttribute("x2", h2x);
                hl2.setAttribute("y2", h2y);
            }
            if (path) {
                var d = "M 0,100 C " + h1x + "," + h1y + " " + h2x + "," + h2y + " 100,0";
                path.setAttribute("d", d);
            }
            if (valInput) {
                valInput.value = x1.toFixed(2) + ", " + y1.toFixed(2) + ", " + x2.toFixed(2) + ", " + y2.toFixed(2);
            }

            // Notify main.js if needed
            if (typeof window.updateGraphUI === "function") {
                try { window.updateGraphUI(); } catch (e) {}
            }

            // Schedule dual-overlay render
            this.scheduleOverlayRender();
        },

        // ⇄ INVERT CURVE (INSTANTLY INVERTS HANDLES AND CURVE WITHOUT LAG)
        invertCurve: function () {
            var pts = this.getCurrentBezierPts();
            var x1 = pts[0], y1 = pts[1], x2 = pts[2], y2 = pts[3];
            var newX1 = parseFloat((1 - x2).toFixed(2));
            var newY1 = parseFloat((1 - y2).toFixed(2));
            var newX2 = parseFloat((1 - x1).toFixed(2));
            var newY2 = parseFloat((1 - y1).toFixed(2));

            this.applyBezierToUI(newX1, newY1, newX2, newY2);
            MDK_Toast.show("Curve inverted ⇄ (" + newX1 + ", " + newY1 + ", " + newX2 + ", " + newY2 + ")");
        },

        setMode: function (mode) {
            this.mode = mode === "speed" ? "speed" : "value";
            try { localStorage.setItem("mdk_graph_mode", this.mode); } catch (e) {}

            var btnVal = document.getElementById("btn-graph-mode-value");
            var btnSpd = document.getElementById("btn-graph-mode-speed");
            if (btnVal) btnVal.classList.toggle("active", this.mode === "value");
            if (btnSpd) btnSpd.classList.toggle("active", this.mode === "speed");

            this.scheduleOverlayRender();
            MDK_Toast.show("Switched to <strong>" + (this.mode === "value" ? "Value Graph" : "Speed Graph") + "</strong> mode");
        },

        toggleGhost: function (enabled) {
            this.showGhost = !!enabled;
            try { localStorage.setItem("mdk_graph_ghost", this.showGhost ? "1" : "0"); } catch (e) {}
            var chk = document.getElementById("mdk-ghost-toggle");
            if (chk) chk.checked = this.showGhost;
            this.scheduleOverlayRender();
        },

        setGhostOpacity: function (val) {
            this.ghostOpacity = Math.max(0.05, Math.min(1.0, parseFloat(val) || 0.38));
            try { localStorage.setItem("mdk_graph_ghost_op", String(this.ghostOpacity)); } catch (e) {}
            var sel = document.getElementById("mdk-ghost-opacity");
            if (sel) sel.value = String(this.ghostOpacity);
            this.scheduleOverlayRender();
        },

        // Sample Bezier points and instantaneous derivative velocity v(t) = |dy/dx|
        // Uses 48 steps for maximum performance
        sampleBezier: function (x1, y1, x2, y2, N) {
            N = N || 48;
            var pts = [];
            var maxVel = 0.001;

            for (var i = 0; i <= N; i++) {
                var t = i / N;
                var mt = 1 - t;

                // Position B(t)
                var x = 3 * mt * mt * t * x1 + 3 * mt * t * t * x2 + t * t * t;
                var y = 3 * mt * mt * t * y1 + 3 * mt * t * t * y2 + t * t * t;

                // Derivatives dx/dt and dy/dt
                var dxdt = 3 * mt * mt * x1 + 6 * mt * t * (x2 - x1) + 3 * t * t * (1 - x2);
                var dydt = 3 * mt * mt * y1 + 6 * mt * t * (y2 - y1) + 3 * t * t * (1 - y2);

                var vel = Math.abs(dydt / Math.max(0.0001, Math.abs(dxdt)));
                if (vel > maxVel) maxVel = vel;

                pts.push({ t: t, x: x, y: y, vel: vel });
            }

            return { pts: pts, maxVel: maxVel };
        },

        renderDualOverlay: function () {
            var pts = this.getCurrentBezierPts();
            var x1 = pts[0], y1 = pts[1], x2 = pts[2], y2 = pts[3];

            var sampled = this.sampleBezier(x1, y1, x2, y2, 48);
            var maxVel = sampled.maxVel;

            // Generate Value SVG Path d (0,100 to 100,0)
            var valD = "M 0,100 C " + (x1 * 100).toFixed(1) + "," + ((1 - y1) * 100).toFixed(1) +
                " " + (x2 * 100).toFixed(1) + "," + ((1 - y2) * 100).toFixed(1) + " 100,0";

            // Generate Speed SVG Path d (normalized height inside SVG box)
            var speedD = "";
            var vScale = Math.max(2.6, maxVel);
            for (var i = 0; i < sampled.pts.length; i++) {
                var p = sampled.pts[i];
                var sx = (p.x * 100).toFixed(1);
                var sy = (100 - (p.vel / vScale) * 90).toFixed(1);
                sy = Math.max(6, Math.min(98, parseFloat(sy)));
                speedD += (i === 0 ? "M " : " L ") + sx + "," + sy;
            }

            var mainPath = document.getElementById("bezier-path");
            var ghostPath = document.getElementById("mdk-ghost-path");
            var onionPath = document.getElementById("mdk-onion-path");

            var svg = document.getElementById("bezier-svg");
            if (svg && !ghostPath) {
                ghostPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
                ghostPath.id = "mdk-ghost-path";
                ghostPath.setAttribute("fill", "none");
                ghostPath.setAttribute("stroke-width", "2.2");
                ghostPath.setAttribute("stroke-dasharray", "4,3");
                ghostPath.setAttribute("vector-effect", "non-scaling-stroke");
                ghostPath.setAttribute("stroke-linecap", "round");
                svg.insertBefore(ghostPath, mainPath);
            }
            if (svg && !onionPath) {
                onionPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
                onionPath.id = "mdk-onion-path";
                onionPath.setAttribute("fill", "none");
                onionPath.setAttribute("stroke", "#666666");
                onionPath.setAttribute("stroke-width", "1.5");
                onionPath.setAttribute("stroke-dasharray", "2,2");
                onionPath.setAttribute("opacity", "0.22");
                onionPath.setAttribute("vector-effect", "non-scaling-stroke");
                onionPath.setAttribute("stroke-linecap", "round");
                svg.insertBefore(onionPath, ghostPath);
            }

            var activeThemeObj = MDK_ThemeEngine.getTheme(MDK_ThemeEngine.activeTheme);
            var velocityAccent = "#00f0ff";
            if (activeThemeObj.id === "cyber_cyan") velocityAccent = "#ff7a00";

            if (this.mode === "value") {
                if (mainPath) {
                    mainPath.setAttribute("d", valD);
                    mainPath.setAttribute("stroke", "#ffffff");
                }
                if (ghostPath) {
                    ghostPath.setAttribute("d", speedD);
                    ghostPath.setAttribute("stroke", velocityAccent);
                    ghostPath.style.display = this.showGhost ? "block" : "none";
                    ghostPath.style.opacity = String(this.ghostOpacity);
                }
            } else {
                if (mainPath) {
                    mainPath.setAttribute("d", speedD);
                    mainPath.setAttribute("stroke", activeThemeObj.accent);
                }
                if (ghostPath) {
                    ghostPath.setAttribute("d", valD);
                    ghostPath.setAttribute("stroke", "#ffffff");
                    ghostPath.style.display = this.showGhost ? "block" : "none";
                    ghostPath.style.opacity = String(this.ghostOpacity);
                }
            }

            // Onion Skin Rendering
            if (onionPath) {
                if (this.lastAppliedCurve && Array.isArray(this.lastAppliedCurve)) {
                    var lx1 = this.lastAppliedCurve[0], ly1 = this.lastAppliedCurve[1];
                    var lx2 = this.lastAppliedCurve[2], ly2 = this.lastAppliedCurve[3];
                    var oD = "M 0,100 C " + (lx1 * 100).toFixed(1) + "," + ((1 - ly1) * 100).toFixed(1) +
                        " " + (lx2 * 100).toFixed(1) + "," + ((1 - ly2) * 100).toFixed(1) + " 100,0";
                    onionPath.setAttribute("d", oD);
                    onionPath.style.display = "block";
                } else {
                    onionPath.style.display = "none";
                }
            }

            // Update Dynamics Readout
            var peakVelEl = document.getElementById("mdk-peak-vel");
            var infInEl = document.getElementById("mdk-inf-in");
            var infOutEl = document.getElementById("mdk-inf-out");
            var curveLabelEl = document.getElementById("mdk-curve-label");

            if (peakVelEl) peakVelEl.textContent = maxVel.toFixed(2) + "x";
            if (infInEl) infInEl.textContent = Math.round(x1 * 100) + "%";
            if (infOutEl) infOutEl.textContent = Math.round((1 - x2) * 100) + "%";

            if (curveLabelEl) {
                var lbl = "Custom";
                if (x1 < 0.05 && y1 < 0.05 && x2 > 0.95 && y2 > 0.95) lbl = "Linear";
                else if (x1 > 0.6 && x2 > 0.6) lbl = "Aggressive Ease-In";
                else if (x1 < 0.4 && x2 < 0.4) lbl = "Aggressive Ease-Out";
                else if (x1 > 0.45 && x2 < 0.55) lbl = "Smooth In-Out (S-Curve)";
                else if (x1 > 0.7 && x2 < 0.3) lbl = "High Velocity Peak (Whip)";
                else if (y1 > 1.05 || y2 > 1.05) lbl = "Overshoot / Rebound";
                curveLabelEl.textContent = lbl;
            }
        },

        // 📋 Copy Temporal Ease from AE Keyframe
        copyEaseFromAE: function () {
            if (!cs) {
                MDK_Toast.show("ExtendScript CSInterface unavailable", "error");
                return;
            }
            MDK_Toast.show("Reading keyframe ease from After Effects...", "info");
            var script = '(function() {' +
                '  if (typeof $._MDK_PRO === "undefined") {' +
                '    var f = new File(' + JSON.stringify(getHostScriptPath()) + ');' +
                '    if (f.exists) { try { $.evalFile(f); } catch(e){} }' +
                '  }' +
                '  if (typeof $._MDK_PRO !== "undefined" && $._MDK_PRO.copyEase) return $._MDK_PRO.copyEase();' +
                '  return JSON.stringify({ ok: false, error: "Helper script not loaded." });' +
                '})();';

            cs.evalScript(script, function (resRaw) {
                try {
                    var res = JSON.parse(resRaw);
                    if (res && res.ok) {
                        MDK_Toast.show("✓ Ease copied (" + res.prop + ": In " + res.inInfluence + "%, Out " + res.outInfluence + "%)");
                    } else {
                        MDK_Toast.show(res ? res.error : "Failed to copy ease", "error");
                    }
                } catch (err) {
                    MDK_Toast.show("Parse Error: " + err.toString(), "error");
                }
            });
        },

        // 📋 Paste Temporal Ease to AE Keyframes
        pasteEaseToAE: function () {
            if (!cs) {
                MDK_Toast.show("ExtendScript CSInterface unavailable", "error");
                return;
            }
            MDK_Toast.show("Applying ease to selected keyframes...", "info");
            var script = '(function() {' +
                '  if (typeof $._MDK_PRO === "undefined") {' +
                '    var f = new File(' + JSON.stringify(getHostScriptPath()) + ');' +
                '    if (f.exists) { try { $.evalFile(f); } catch(e){} }' +
                '  }' +
                '  if (typeof $._MDK_PRO !== "undefined" && $._MDK_PRO.pasteEase) return $._MDK_PRO.pasteEase(false);' +
                '  return JSON.stringify({ ok: false, error: "Helper script not loaded." });' +
                '})();';

            cs.evalScript(script, function (resRaw) {
                try {
                    var res = JSON.parse(resRaw);
                    if (res && res.ok) {
                        MDK_Toast.show("✓ " + res.msg);
                    } else {
                        MDK_Toast.show(res ? res.error : "Failed to paste ease", "error");
                    }
                } catch (err) {
                    MDK_Toast.show("Parse Error: " + err.toString(), "error");
                }
            });
        }
    };

    // =========================================================================
    // 4. SIDE-BY-SIDE DUAL VIEW WORKSPACE (WORKFLOW ON LEFT + TOOLS ON RIGHT)
    // =========================================================================
    var MDK_DualView = {
        isDual: false,
        rightTool: "graph",
        placeholders: {},

        init: function () {
            var self = this;
            try {
                var saved = localStorage.getItem("mdk_dual_view");
                if (saved === "1") {
                    setTimeout(function () { self.enable(false); }, 300);
                }
            } catch (e) {}

            this.initDividerDrag();
        },

        toggleDualView: function () {
            if (this.isDual) {
                this.disable(true);
            } else {
                this.enable(true);
            }
        },

        enable: function (showToast) {
            var ws = document.getElementById("mdk-dual-workspace");
            var leftSlot = document.getElementById("mdk-dual-slot-left");
            var rightSlot = document.getElementById("mdk-dual-slot-right");
            var navbar = document.getElementById("main-navbar");
            var easyPanel = document.getElementById("easy");
            var rightPanel = document.getElementById(this.rightTool);

            if (!ws || !leftSlot || !rightSlot || !easyPanel || !rightPanel) return;

            // Close any floating windows to prevent duplicates
            MDK_Layout.dockAll();

            this.isDual = true;
            try { localStorage.setItem("mdk_dual_view", "1"); } catch (e) {}

            // Save placeholders in original DOM tree
            if (!this.placeholders["easy"]) {
                var phEasy = document.createElement("div");
                phEasy.id = "mdk-ph-easy";
                phEasy.style.display = "none";
                easyPanel.parentNode.insertBefore(phEasy, easyPanel);
                this.placeholders["easy"] = phEasy;
            }
            if (!this.placeholders[this.rightTool]) {
                var phRight = document.createElement("div");
                phRight.id = "mdk-ph-" + this.rightTool;
                phRight.style.display = "none";
                rightPanel.parentNode.insertBefore(phRight, rightPanel);
                this.placeholders[this.rightTool] = phRight;
            }

            // Move panels into dual slots
            leftSlot.appendChild(easyPanel);
            easyPanel.style.display = "block";
            easyPanel.classList.add("active");

            rightSlot.appendChild(rightPanel);
            rightPanel.style.display = "block";
            rightPanel.classList.add("active");

            // Show workspace, hide standard navbar
            ws.style.display = "flex";
            if (navbar) navbar.style.display = "none";

            // Update Header button style
            var btnDual = document.getElementById("mdk-btn-dual");
            if (btnDual) {
                btnDual.classList.add("active");
                btnDual.innerHTML = '<i class="fa-solid fa-table-columns" style="color:var(--accent-orange);"></i> Split: ON';
                btnDual.title = "Click to return to Single Tab layout";
            }

            this.updatePills();

            // Refresh right tool engine
            if (this.rightTool === "graph") {
                setTimeout(function () { MDK_GraphEngine.renderDualOverlay(); }, 100);
            } else if (this.rightTool === "carousel3d" && typeof Carousel3D !== "undefined") {
                try { Carousel3D.init(); } catch (e) {}
            } else if (this.rightTool === "mousedock" && typeof MouseDock !== "undefined") {
                try { MouseDock.init(); } catch (e) {}
            }

            if (showToast) {
                MDK_Toast.show("✓ Split View Active: Workflow (Left) + " + this.getToolName(this.rightTool) + " (Right)");
            }
        },

        disable: function (showToast) {
            var ws = document.getElementById("mdk-dual-workspace");
            var navbar = document.getElementById("main-navbar");
            var easyPanel = document.getElementById("easy");
            var rightPanel = document.getElementById(this.rightTool);

            this.isDual = false;
            try { localStorage.removeItem("mdk_dual_view"); } catch (e) {}

            // Restore panels to original DOM locations
            if (easyPanel && this.placeholders["easy"] && this.placeholders["easy"].parentNode) {
                this.placeholders["easy"].parentNode.insertBefore(easyPanel, this.placeholders["easy"]);
                this.placeholders["easy"].parentNode.removeChild(this.placeholders["easy"]);
                delete this.placeholders["easy"];
            }
            if (rightPanel && this.placeholders[this.rightTool] && this.placeholders[this.rightTool].parentNode) {
                this.placeholders[this.rightTool].parentNode.insertBefore(rightPanel, this.placeholders[this.rightTool]);
                this.placeholders[this.rightTool].parentNode.removeChild(this.placeholders[this.rightTool]);
                delete this.placeholders[this.rightTool];
            }

            if (ws) ws.style.display = "none";
            if (navbar) navbar.style.display = "flex";

            // Update Header button style
            var btnDual = document.getElementById("mdk-btn-dual");
            if (btnDual) {
                btnDual.classList.remove("active");
                btnDual.innerHTML = '<i class="fa-solid fa-table-columns"></i> Split View';
                btnDual.title = "Split View: Access Workflow and Graph/Tools simultaneously side-by-side";
            }

            // Restore Single tab
            if (typeof window.openTab === "function") {
                window.openTab("easy");
            }

            if (showToast) {
                MDK_Toast.show("✓ Restored Single Tab View");
            }
        },

        setRightTool: function (toolId) {
            if (!this.isDual) {
                this.rightTool = toolId;
                this.enable(true);
                return;
            }

            if (toolId === this.rightTool) return;

            var oldRightPanel = document.getElementById(this.rightTool);
            var newRightPanel = document.getElementById(toolId);
            var rightSlot = document.getElementById("mdk-dual-slot-right");

            if (!oldRightPanel || !newRightPanel || !rightSlot) return;

            // Reparent old right panel back to placeholder
            if (this.placeholders[this.rightTool] && this.placeholders[this.rightTool].parentNode) {
                oldRightPanel.style.display = "none";
                oldRightPanel.classList.remove("active");
                this.placeholders[this.rightTool].parentNode.insertBefore(oldRightPanel, this.placeholders[this.rightTool]);
                this.placeholders[this.rightTool].parentNode.removeChild(this.placeholders[this.rightTool]);
                delete this.placeholders[this.rightTool];
            }

            this.rightTool = toolId;

            // Create placeholder for new right tool
            var phNew = document.createElement("div");
            phNew.id = "mdk-ph-" + toolId;
            phNew.style.display = "none";
            newRightPanel.parentNode.insertBefore(phNew, newRightPanel);
            this.placeholders[toolId] = phNew;

            // Move new right tool into slot
            rightSlot.innerHTML = "";
            rightSlot.appendChild(newRightPanel);
            newRightPanel.style.display = "block";
            newRightPanel.classList.add("active");

            this.updatePills();

            // Refresh specific tool engines
            if (toolId === "graph") {
                setTimeout(function () { MDK_GraphEngine.renderDualOverlay(); }, 100);
            } else if (toolId === "carousel3d" && typeof Carousel3D !== "undefined") {
                try { Carousel3D.init(); } catch (e) {}
            } else if (toolId === "mousedock" && typeof MouseDock !== "undefined") {
                try { MouseDock.init(); } catch (e) {}
            }

            MDK_Toast.show("Right Panel switched to <strong>" + this.getToolName(toolId) + "</strong>");
        },

        updatePills: function () {
            var pills = document.querySelectorAll(".dual-tool-pill");
            for (var i = 0; i < pills.length; i++) {
                pills[i].classList.toggle("active", pills[i].dataset.rtool === this.rightTool);
            }
        },

        getToolName: function (id) {
            var names = {
                "graph": "Graph Editor",
                "carousel3d": "3D Carousel",
                "mousedock": "Mouse Dock",
                "shape": "Shape Tools"
            };
            return names[id] || id;
        },

        initDividerDrag: function () {
            var divider = document.getElementById("mdk-dual-divider");
            var colLeft = document.getElementById("mdk-dual-col-left");
            var colRight = document.getElementById("mdk-dual-col-right");
            var ws = document.getElementById("mdk-dual-workspace");

            if (!divider || !colLeft || !colRight || !ws) return;

            divider.onmousedown = function (e) {
                e.preventDefault();
                var startX = e.clientX;
                var startLeftWidth = colLeft.offsetWidth;
                var totalWidth = ws.offsetWidth;

                document.onmousemove = function (ev) {
                    var dx = ev.clientX - startX;
                    var newLeftWidth = startLeftWidth + dx;
                    var minW = 220;
                    var maxW = totalWidth - 220;

                    if (newLeftWidth >= minW && newLeftWidth <= maxW) {
                        var leftPercent = (newLeftWidth / totalWidth) * 100;
                        colLeft.style.flex = "0 0 " + leftPercent + "%";
                        colRight.style.flex = "0 0 " + (100 - leftPercent) + "%";
                    }
                };

                document.onmouseup = function () {
                    document.onmousemove = null;
                    document.onmouseup = null;
                };
            };
        }
    };

    // =========================================================================
    // 5. DETACHABLE / UNDOCKABLE TAB PALETTES & 1-CLICK RESET LAYOUT
    // =========================================================================
    var MDK_Layout = {
        detachedTabs: {},

        TAB_NAMES: {
            "easy": "Workflow Suite",
            "graph": "Graph Editor",
            "carousel3d": "3D Carousel Studio",
            "mousedock": "macOS Mouse Dock",
            "shape": "Shape Tools Suite"
        },

        init: function () {
            // Restore any previously saved detached state
            try {
                var saved = localStorage.getItem("mdk_detached_tabs");
                if (saved) {
                    var list = JSON.parse(saved);
                    for (var i = 0; i < list.length; i++) {
                        this.detachTab(list[i], false);
                    }
                }
            } catch (e) {}
        },

        isDetached: function (tabId) {
            return !!this.detachedTabs[tabId];
        },

        // Native AE Extension Pop-Out (Window > Extensions in After Effects)
        popoutAEWindow: function (tabId) {
            if (cs && typeof cs.requestOpenExtension === "function") {
                var extId = "com.motionbydk.aeworkflow." + (tabId === "shape" ? "shapes" : tabId);
                try {
                    cs.requestOpenExtension(extId);
                    MDK_Toast.show("Opened native After Effects window for <strong>" + (this.TAB_NAMES[tabId] || tabId) + "</strong>");
                    return;
                } catch (e) {}
            }
            // Fallback to in-panel floating palette
            this.detachTab(tabId, true);
        },

        detachTab: function (tabId, notify) {
            if (this.detachedTabs[tabId]) return;

            // If in dual view, disable dual view first so tab is clean
            if (MDK_DualView.isDual) {
                MDK_DualView.disable(false);
            }

            var panel = document.getElementById(tabId);
            if (!panel) return;

            var title = this.TAB_NAMES[tabId] || tabId;

            // Create floating window container
            var win = document.createElement("div");
            win.id = "mdk-float-" + tabId;
            win.className = "mdk-float-window";
            win.style.cssText = "position:fixed; top:42px; left:12px; width:330px; max-width:calc(100vw - 24px); " +
                "max-height:calc(100vh - 60px); display:flex; flex-direction:column; background:#111111; " +
                "border:1px solid var(--accent-orange, #ff7a00); border-radius:8px; box-shadow:0 12px 45px rgba(0,0,0,0.92); " +
                "z-index:9000; overflow:hidden; transition:box-shadow 0.2s;";

            // Window Header
            var hdr = document.createElement("div");
            hdr.className = "mdk-float-header";
            hdr.style.cssText = "display:flex; align-items:center; justify-content:space-between; padding:6px 10px; " +
                "background:#181818; border-bottom:1px solid #282828; cursor:grab; user-select:none; -webkit-user-select:none;";
            hdr.innerHTML =
                '<div style="display:flex; align-items:center; gap:6px; font-weight:800; font-size:11px; color:#fff;">' +
                '  <i class="fa-solid fa-grip-vertical" style="color:var(--accent-orange); cursor:grab;"></i> ' + title +
                '  <span style="font-size:9px; background:rgba(255,122,0,0.18); color:var(--accent-orange); padding:1px 6px; border-radius:10px;">Floating</span>' +
                '</div>' +
                '<div style="display:flex; align-items:center; gap:6px;">' +
                '  <button onclick="MDK_Layout.dockTab(\'' + tabId + '\', true)" style="background:none; border:none; color:#aaa; cursor:pointer; font-size:10px; padding:2px 5px;" title="Dock back into main panel">' +
                '    <i class="fa-solid fa-arrow-down-to-bracket"></i> Dock' +
                '  </button>' +
                '</div>';

            // Window Content Body
            var body = document.createElement("div");
            body.className = "mdk-float-body";
            body.style.cssText = "overflow-y:auto; overflow-x:hidden; flex:1; padding:8px;";

            // Reparent panel content into floating window body
            var placeholder = document.createElement("div");
            placeholder.id = "mdk-placeholder-" + tabId;
            placeholder.style.display = "none";
            panel.parentNode.insertBefore(placeholder, panel);

            panel.style.display = "block";
            panel.classList.remove("active");
            body.appendChild(panel);

            win.appendChild(hdr);
            win.appendChild(body);
            document.body.appendChild(win);

            this.makeDraggable(win, hdr);
            this.detachedTabs[tabId] = { win: win, placeholder: placeholder };

            // Update Tab Button in Navbar
            var navBtn = document.querySelector('.nav-btn[data-tab="' + tabId + '"]');
            if (navBtn) {
                navBtn.classList.add("is-detached");
                navBtn.title = title + " (Floating Window - Click to bring to front)";
            }

            this.saveDetachedState();

            if (notify) {
                MDK_Toast.show("Detached <strong>" + title + "</strong> into floating window");
            }
        },

        dockTab: function (tabId, notify) {
            var rec = this.detachedTabs[tabId];
            if (!rec) return;

            var panel = document.getElementById(tabId);
            if (panel && rec.placeholder && rec.placeholder.parentNode) {
                panel.style.display = "none";
                rec.placeholder.parentNode.insertBefore(panel, rec.placeholder);
                rec.placeholder.parentNode.removeChild(rec.placeholder);
            }

            if (rec.win && rec.win.parentNode) {
                rec.win.parentNode.removeChild(rec.win);
            }

            delete this.detachedTabs[tabId];

            var navBtn = document.querySelector('.nav-btn[data-tab="' + tabId + '"]');
            if (navBtn) {
                navBtn.classList.remove("is-detached");
                navBtn.title = "";
            }

            this.saveDetachedState();

            if (notify) {
                var title = this.TAB_NAMES[tabId] || tabId;
                MDK_Toast.show("Docked <strong>" + title + "</strong> back into main panel");
            }
        },

        dockAll: function () {
            var tabs = Object.keys(this.detachedTabs);
            for (var i = 0; i < tabs.length; i++) {
                this.dockTab(tabs[i], false);
            }
            try { localStorage.removeItem("mdk_detached_tabs"); } catch (e) {}
        },

        // 🔄 1-CLICK RESET LAYOUT (RESETS FLOATING TABS AND DUAL VIEW BACK TO CLEAN SINGLE TAB VIEW)
        resetLayout: function () {
            this.dockAll();

            if (MDK_DualView.isDual) {
                MDK_DualView.disable(false);
            }

            // Open default Workflow tab
            if (typeof window.openTab === "function") {
                window.openTab("easy");
            }

            MDK_Toast.show("✓ Layout Reset! Restored standard clean workspace.");
        },

        saveDetachedState: function () {
            var list = Object.keys(this.detachedTabs);
            try { localStorage.setItem("mdk_detached_tabs", JSON.stringify(list)); } catch (e) {}
        },

        makeDraggable: function (win, handle) {
            var posX = 0, posY = 0, mouseX = 0, mouseY = 0;
            handle.onmousedown = dragMouseDown;

            function dragMouseDown(e) {
                e = e || window.event;
                e.preventDefault();
                mouseX = e.clientX;
                mouseY = e.clientY;
                document.onmouseup = closeDragElement;
                document.onmousemove = elementDrag;
                handle.style.cursor = "grabbing";
                win.style.zIndex = String(9000 + Date.now() % 1000);
            }

            function elementDrag(e) {
                e = e || window.event;
                e.preventDefault();
                posX = mouseX - e.clientX;
                posY = mouseY - e.clientY;
                mouseX = e.clientX;
                mouseY = e.clientY;

                var newTop = win.offsetTop - posY;
                var newLeft = win.offsetLeft - posX;

                newTop = Math.max(10, Math.min(window.innerHeight - 60, newTop));
                newLeft = Math.max(5, Math.min(window.innerWidth - 80, newLeft));

                win.style.top = newTop + "px";
                win.style.left = newLeft + "px";
            }

            function closeDragElement() {
                document.onmouseup = null;
                document.onmousemove = null;
                handle.style.cursor = "grab";
            }
        }
    };

    // =========================================================================
    // 6. SMART MEDIA CLIPBOARD ENGINE (COPY PASTA PRO + VIDEO DOWNLOADER)
    // =========================================================================
    var MDK_Clipboard = {
        isProcessing: false,

        getNodeFs: function () {
            try { return (typeof require === "function") ? require("fs") : null; } catch (e) { return null; }
        },
        getNodePath: function () {
            try { return (typeof require === "function") ? require("path") : null; } catch (e) { return null; }
        },
        getNodeOs: function () {
            try { return (typeof require === "function") ? require("os") : null; } catch (e) { return null; }
        },
        getNodeCp: function () {
            try { return (typeof require === "function") ? require("child_process") : null; } catch (e) { return null; }
        },

        getBinDir: function () {
            try {
                var path = this.getNodePath();
                var fs = this.getNodeFs();
                var root = getExtensionRoot();
                if (root && path && fs) {
                    var p = path.join(root, "bin");
                    if (fs.existsSync(p)) return p;
                }
                if (typeof __dirname !== "undefined" && path && fs) {
                    var p2 = path.resolve(__dirname, "..", "bin");
                    if (fs.existsSync(p2)) return p2;
                    var p3 = path.resolve(__dirname, "bin");
                    if (fs.existsSync(p3)) return p3;
                }
                return null;
            } catch (e) { return null; }
        },

        getMediaStorageDir: function () {
            var os = this.getNodeOs();
            var fs = this.getNodeFs();
            var path = this.getNodePath();
            var targetDir = null;
            try {
                if (os && typeof os.homedir === "function" && path) {
                    targetDir = path.join(os.homedir(), "Downloads", "MotionByDk");
                }
            } catch (e) {}
            if (!targetDir && os && typeof os.tmpdir === "function" && path) {
                targetDir = path.join(os.tmpdir(), "MotionByDk");
            }
            if (!targetDir) targetDir = "/tmp/MotionByDk";

            try {
                if (fs && !fs.existsSync(targetDir)) {
                    fs.mkdirSync(targetDir, { recursive: true });
                }
            } catch (mkErr) {}

            return targetDir;
        },

        getTempDir: function () {
            return this.getMediaStorageDir();
        },

        evalHost: function (scriptCode, callback) {
            if (!cs) {
                if (callback) callback({ ok: false, error: "CSInterface unavailable" });
                return;
            }
            var hostFileStr = JSON.stringify(getHostScriptPath());
            var wrapper = '(function() {' +
                '  if (typeof $._MDK_PRO === "undefined" || !$._MDK_PRO.importAndInsertMedia || !$._MDK_PRO.exportActiveCompFrameViaRQ) {' +
                '    var f = new File(' + hostFileStr + ');' +
                '    if (f.exists) { try { $.evalFile(f); } catch(e){ return JSON.stringify({ ok: false, error: "Host eval error: " + e.toString() }); } }' +
                '    else { return JSON.stringify({ ok: false, error: "Host features script not found at: " + ' + hostFileStr + ' }); }' +
                '  }' +
                '  if (typeof $._MDK_PRO === "undefined") return JSON.stringify({ ok: false, error: "Host features script not loaded: " + ' + hostFileStr + ' });' +
                '  return ' + scriptCode + ';' +
                '})();';

            cs.evalScript(wrapper, function (rawRes) {
                var parsed = null;
                try {
                    parsed = JSON.parse(rawRes);
                } catch (e) {
                    parsed = { ok: false, error: rawRes || e.message };
                }
                if (callback) callback(parsed);
            });
        },

        pasteMedia: function () {
            if (this.isProcessing) return;
            var self = this;
            self.isProcessing = true;

            MDK_Toast.show("Checking clipboard for image...", "info");

            // 1. Check for image on system clipboard first!
            self.extractClipboardImage(function (imagePath) {
                if (imagePath) {
                    MDK_Toast.show("Importing image into After Effects...", "info");
                    var script = '$._MDK_PRO.importAndInsertMedia(' + JSON.stringify(imagePath.replace(/\\/g, "/")) + ', true)';
                    self.evalHost(script, function (res) {
                        self.isProcessing = false;
                        if (res && res.ok) {
                            MDK_Toast.show("Pasted image directly onto timeline!", "success");
                        } else {
                            MDK_Toast.show((res && res.error) ? res.error : "Failed to import image.", "error");
                        }
                    });
                    return;
                }

                // 2. If no image found, check if a file path or URL is copied on clipboard
                self.readClipboardTextSync(function (text) {
                    var cleanText = (text || "").trim();
                    var fs = self.getNodeFs();

                    // Check if clipboard contains a local file path (e.g. copied from Finder or Explorer)
                    var isLocalFile = false;
                    try {
                        if (cleanText && fs && fs.existsSync(cleanText)) {
                            var stat = fs.statSync(cleanText);
                            if (stat.isFile() && /\.(png|jpe?g|gif|webp|tiff?|bmp|psd|ai|mp4|mov|avi|wav|mp3)$/i.test(cleanText)) {
                                isLocalFile = true;
                            }
                        }
                    } catch(e) {}

                    if (isLocalFile) {
                        MDK_Toast.show("Importing media file from clipboard...", "info");
                        var script = '$._MDK_PRO.importAndInsertMedia(' + JSON.stringify(cleanText.replace(/\\/g, "/")) + ', true)';
                        self.evalHost(script, function (res) {
                            self.isProcessing = false;
                            if (res && res.ok) {
                                MDK_Toast.show("Pasted media file onto timeline!", "success");
                            } else {
                                MDK_Toast.show((res && res.error) ? res.error : "Failed to import file.", "error");
                            }
                        });
                        return;
                    }

                    self.isProcessing = false;
                    MDK_Toast.show("No image or media file path found on clipboard.", "error");
                });
            });
        },

        readClipboardTextSync: function (callback) {
            var cp = this.getNodeCp();
            var isWin = (process.platform === "win32");
            if (!cp) {
                callback("");
                return;
            }
            try {
                if (isWin) {
                    var res = cp.spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "Get-Clipboard"], { windowsHide: true, encoding: "utf8" });
                    callback((res.stdout || "").trim());
                } else {
                    var resMac = cp.spawnSync("pbpaste", [], { encoding: "utf8" });
                    callback((resMac.stdout || "").trim());
                }
            } catch (e) {
                callback("");
            }
        },

        extractClipboardImage: function (callback) {
            var fs = this.getNodeFs();
            var path = this.getNodePath();
            var cp = this.getNodeCp();
            var isWin = (process.platform === "win32");
            var storageDir = this.getMediaStorageDir();
            var outPng = path ? path.join(storageDir, "MotionByDk_Image_" + Date.now() + ".png") : (storageDir + "/MotionByDk_Image_" + Date.now() + ".png");
            var binDir = this.getBinDir();

            if (isWin) {
                var exePath = binDir ? path.join(binDir, "copypasta_clipboard.exe") : null;
                if (exePath && fs && fs.existsSync(exePath) && cp) {
                    try {
                        var res = cp.spawnSync(exePath, ["paste", outPng], { windowsHide: true });
                        if (res.status === 0 && fs.existsSync(outPng) && fs.statSync(outPng).size > 0) {
                            callback(outPng);
                            return;
                        }
                    } catch (e) { }
                }
                if (cp) {
                    var psCode = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; " +
                        "$img = [System.Windows.Forms.Clipboard]::GetImage(); " +
                        "if ($img) { $bmp = New-Object System.Drawing.Bitmap($img); $bmp.Save('" + outPng.replace(/\\/g, "\\\\") + "', [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose(); $img.Dispose(); exit 0; } else { exit 2; }";
                    try {
                        var psRes = cp.spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", psCode], { windowsHide: true });
                        if (psRes.status === 0 && fs.existsSync(outPng) && fs.statSync(outPng).size > 0) {
                            callback(outPng);
                            return;
                        }
                    } catch (e) { }
                }
                callback(null);
            } else {
                var macBin = binDir ? path.join(binDir, "copypasta_clipboard.app/Contents/MacOS/copypasta_clipboard") : null;
                if (macBin && fs && fs.existsSync(macBin) && cp) {
                    try {
                        try { fs.chmodSync(macBin, "755"); } catch (e) { }
                        var resMac = cp.spawnSync(macBin, ["paste", outPng]);
                        if (resMac.status === 0 && fs.existsSync(outPng) && fs.statSync(outPng).size > 0) {
                            callback(outPng);
                            return;
                        }
                    } catch (e) { }
                }
                if (cp) {
                    var asCode = "try\n" +
                        "  set imgData to (the clipboard as «class PNGf»)\n" +
                        "  set outFile to open for access POSIX file \"" + outPng + "\" with write permission\n" +
                        "  set eof outFile to 0\n" +
                        "  write imgData to outFile\n" +
                        "  close access outFile\n" +
                        "on error\n" +
                        "  try\n    close access POSIX file \"" + outPng + "\"\n  end try\n" +
                        "end try";
                    try {
                        var asRes = cp.spawnSync("osascript", ["-e", asCode]);
                        if (asRes.status === 0 && fs && fs.existsSync(outPng) && fs.statSync(outPng).size > 0) {
                            callback(outPng);
                            return;
                        }
                    } catch (e) { }
                }
                try {
                    if (fs && fs.existsSync(outPng) && fs.statSync(outPng).size === 0) {
                        fs.unlinkSync(outPng);
                    }
                } catch (e) { }
                callback(null);
            }
        },

        _writePngToClipboard: function (pngPath) {
            var cp = this.getNodeCp();
            var isWin = (process.platform === "win32");
            if (!cp) {
                MDK_Toast.show("Frame saved: " + pngPath, "success");
                return;
            }
            if (isWin) {
                var psCmd = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; " +
                    "[System.Windows.Forms.Clipboard]::SetImage([System.Drawing.Image]::FromFile('" + pngPath.replace(/'/g, "''") + "'));";
                var wr = cp.spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", psCmd], { windowsHide: true });
                if (wr && wr.status === 0) {
                    MDK_Toast.show("Frame copied to clipboard! Ready to paste anywhere.", "success");
                } else {
                    MDK_Toast.show("Frame saved, clipboard copy failed.", "error");
                }
            } else {
                var asCmd = 'set the clipboard to (read POSIX file ' + JSON.stringify(pngPath) + ' as «class PNGf»)';
                var mr = cp.spawnSync("osascript", ["-e", asCmd]);
                if (mr && mr.status === 0) {
                    MDK_Toast.show("Frame copied to clipboard! Ready to paste anywhere.", "success");
                } else {
                    MDK_Toast.show("Frame saved, macOS clipboard error.", "error");
                }
            }
        },

        copyCurrentFrame: function () {
            var self = this;
            var fs = self.getNodeFs();
            var path = self.getNodePath();
            var cp = self.getNodeCp();
            var isWin = (process.platform === "win32");
            var storageDir = self.getMediaStorageDir();
            var ts = Date.now();
            var outPng = path ? path.join(storageDir, "MotionByDk_Frame_" + ts + ".png") : (storageDir + "/MotionByDk_Frame_" + ts + ".png");

            MDK_Toast.show("Rendering frame to clipboard...", "info");

            var script = '$._MDK_PRO.exportActiveCompFrameToPNG(' + JSON.stringify(outPng.replace(/\\/g, "/")) + ')';
            self.evalHost(script, function (res) {
                if (!res || !res.ok) {
                    MDK_Toast.show((res && res.error) ? res.error : "Failed to export frame.", "error");
                    return;
                }

                if (!fs) {
                    self._writePngToClipboard(outPng);
                    return;
                }

                // Wait asynchronously without blocking AE's main thread until saveFrameToPng finishes flushing to disk
                var waited = 0;
                var lastSize = -1;
                var checkFlush = function () {
                    var size = 0;
                    try {
                        if (fs.existsSync(outPng)) size = fs.statSync(outPng).size;
                    } catch (eStat) { size = 0; }

                    if (size > 0 && size === lastSize) {
                        self._writePngToClipboard(outPng);
                        return;
                    }
                    lastSize = size;
                    waited += 80;

                    if (waited < 2500) {
                        setTimeout(checkFlush, 80);
                        return;
                    }

                    // Fallback: synchronous single-frame RenderQueue render + PNG conversion if saveFrameToPng timed out
                    var prefix = path ? path.join(storageDir, "MotionByDk_RQ_" + ts) : (storageDir + "/MotionByDk_RQ_" + ts);
                    self.evalHost('$._MDK_PRO.exportActiveCompFrameViaRQ(' + JSON.stringify(prefix.replace(/\\/g, "/")) + ')', function (rqRes) {
                        if (!rqRes || !rqRes.ok || !rqRes.tifPath) {
                            MDK_Toast.show((rqRes && rqRes.error) ? rqRes.error : "Failed to render frame to PNG.", "error");
                            return;
                        }
                        if (!isWin && cp) {
                            cp.spawnSync("sips", ["-s", "format", "png", rqRes.tifPath, "--out", outPng]);
                            try { if (fs.existsSync(rqRes.tifPath)) fs.unlinkSync(rqRes.tifPath); } catch (uE) {}
                        } else if (isWin && cp) {
                            var psConv = "Add-Type -AssemblyName System.Drawing; $img=[System.Drawing.Image]::FromFile('" + rqRes.tifPath.replace(/'/g, "''") + "'); $img.Save('" + outPng.replace(/'/g, "''") + "', [System.Drawing.Imaging.ImageFormat]::Png); $img.Dispose();";
                            cp.spawnSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", psConv], { windowsHide: true });
                            try { if (fs.existsSync(rqRes.tifPath)) fs.unlinkSync(rqRes.tifPath); } catch (uE2) {}
                        }
                        if (fs.existsSync(outPng) && fs.statSync(outPng).size > 0) {
                            self._writePngToClipboard(outPng);
                        } else {
                            MDK_Toast.show("Failed to convert rendered frame to PNG.", "error");
                        }
                    });
                };

                setTimeout(checkFlush, sizeReadyDelay(res));
            });

            function sizeReadyDelay(resObj) {
                return (resObj && resObj.ready) ? 40 : 120;
            }
        }
    };

    // =========================================================================
    // 7. SUPER MORPHING PRO SUITE CONTROLLER
    // =========================================================================
    var MDK_SuperMorph = {
        _evalPro: function (methodName, opts, pendingMsg, successFallback, errorFallback) {
            if (!cs) {
                MDK_Toast.show("CSInterface unavailable", "error");
                return;
            }
            if (pendingMsg) MDK_Toast.show(pendingMsg, "info");

            var hostPath = getHostScriptPath();
            var wrapper = '(function() {' +
                '  if (typeof $._MDK_PRO === "undefined" || typeof $._MDK_PRO[' + JSON.stringify(methodName) + '] !== "function") {' +
                '    var f = new File(' + JSON.stringify(hostPath) + ');' +
                '    if (f.exists) {' +
                '      try { $.evalFile(f); } catch(e){ return JSON.stringify({ ok: false, error: "Super Morph eval error: " + e.toString() + " (line " + e.line + ")" }); }' +
                '    } else {' +
                '      return JSON.stringify({ ok: false, error: "Features file not found at: " + ' + JSON.stringify(hostPath) + ' });' +
                '    }' +
                '  }' +
                '  if (typeof $._MDK_PRO !== "undefined" && typeof $._MDK_PRO[' + JSON.stringify(methodName) + '] === "function") {' +
                '    return $._MDK_PRO[' + JSON.stringify(methodName) + '](' + JSON.stringify(JSON.stringify(opts || {})) + ');' +
                '  }' +
                '  return JSON.stringify({ ok: false, error: "Super Morph engine not loaded. Path checked: " + ' + JSON.stringify(hostPath) + ' });' +
                '})();';

            cs.evalScript(wrapper, function (raw) {
                var res = null;
                try { res = JSON.parse(raw); } catch (err) { res = { ok: false, error: raw || err.message }; }

                if (res && res.ok) {
                    MDK_Toast.show(res.msg || successFallback, "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : errorFallback, "error");
                }
            });
        },

        runMorph: function (durationFrames, easeType, style) {
            var modeEl = document.getElementById("morph-mode");
            var arcEl = document.getElementById("morph-arc");
            var durEl = document.getElementById("morph-duration");
            var easeEl = document.getElementById("morph-ease");
            var styleEl = document.getElementById("morph-style");
            var orderEl = document.getElementById("morph-order");
            var stretchEl = document.getElementById("morph-stretch");
            var colorEl = document.getElementById("morph-color-tween");
            var trailsEl = document.getElementById("morph-trails");
            var trailCountEl = document.getElementById("morph-trail-count");

            var mode = modeEl ? modeEl.value : "kinetic";
            var arcVal = arcEl ? arcEl.value : "arc_back";
            var useArc = (arcVal !== "linear_back" && arcVal !== "linear");
            var straight = (arcVal === "arc_direct");
            var stretch = stretchEl ? stretchEl.checked : true;
            var d = parseInt(durationFrames || (durEl ? durEl.value : 16), 10) || 16;
            var e = easeType || (easeEl ? easeEl.value : "snappy");
            var s = style || (styleEl ? styleEl.value : "liquid");
            var order = orderEl ? orderEl.value : "selection";
            var morphColor = colorEl ? colorEl.checked : true;
            var addTrails = trailsEl ? trailsEl.checked : false;
            var trailCount = trailCountEl ? (parseInt(trailCountEl.value, 10) || 4) : 4;

            var opts = {
                mode: mode,
                arc: useArc,
                straight: straight,
                stretch: stretch,
                durationFrames: d,
                easeType: e,
                style: s,
                order: order,
                morphColor: morphColor,
                morphPosition: true,
                addTrails: addTrails,
                trailCount: trailCount,
                hideEndLayer: true
            };

            this._evalPro(
                "createSuperMorph",
                opts,
                "Building Super Morph (" + mode + ")...",
                "Super Morph created successfully!",
                "Failed to create morph."
            );
        },

        runTrails: function () {
            var trailCountEl = document.getElementById("morph-trail-count");
            var count = trailCountEl ? Math.max(1, Math.min(12, parseInt(trailCountEl.value, 10) || 4)) : 4;
            this._evalPro(
                "addSuperTrails",
                { count: count, dashed: true, width: 5 },
                "Generating Super Morph Trails...",
                "Super Morph Trails created!",
                "Failed to generate trails."
            );
        },

        runSlice: function () {
            var sliceCountEl = document.getElementById("morph-slice-count");
            var sliceDirEl = document.getElementById("morph-slice-dir");
            var count = sliceCountEl ? Math.max(2, Math.min(25, parseInt(sliceCountEl.value, 10) || 4)) : 4;
            var direction = sliceDirEl ? sliceDirEl.value : "diagonal";
            this._evalPro(
                "sliceLayer",
                { count: count, direction: direction, staggerFrames: 0 },
                "Slicing layer into " + count + " " + direction + " pieces...",
                "Layer sliced cleanly!",
                "Failed to slice layer."
            );
        },

        swapDirection: function () {
            var orderEl = document.getElementById("morph-order");
            if (orderEl) {
                if (orderEl.value === "selection") {
                    orderEl.value = "bottom_to_top";
                    MDK_Toast.show("Order: Bottom Layer ➔ Top Layer", "info");
                } else if (orderEl.value === "bottom_to_top") {
                    orderEl.value = "top_to_bottom";
                    MDK_Toast.show("Order: Top Layer ➔ Bottom Layer", "info");
                } else {
                    orderEl.value = "selection";
                    MDK_Toast.show("Order: Click Selection Order (1st Clicked ➔ Last)", "info");
                }
            }
        }
    };

    // =========================================================================
    // 8. SHARED HOST INVOKER + COMP & PROJECT MANAGER (RESIZE, NEW COMP, FOLDER)
    // =========================================================================
    function callProHost(methodName, argsExprList, callback) {
        if (!cs) {
            MDK_Toast.show("CSInterface unavailable", "error");
            return;
        }
        var hostPath = getHostScriptPath();
        var argsJoined = (argsExprList && argsExprList.length) ? argsExprList.join(", ") : "";
        var script = '(function() {' +
            '  if (typeof $._MDK_PRO === "undefined" || typeof $._MDK_PRO.setShapeDash !== "function" || typeof $._MDK_PRO.' + methodName + ' !== "function") {' +
            '    var f = new File(' + JSON.stringify(hostPath) + ');' +
            '    if (f.exists) { try { $.evalFile(f); } catch(e){} }' +
            '  }' +
            '  if (typeof $._MDK_PRO !== "undefined" && typeof $._MDK_PRO.' + methodName + ' === "function") {' +
            '    return $._MDK_PRO.' + methodName + '(' + argsJoined + ');' +
            '  }' +
            '  return JSON.stringify({ ok: false, error: "Pro helper not loaded: ' + methodName + '" });' +
            '})();';

        cs.evalScript(script, function (raw) {
            var res = null;
            try { res = JSON.parse(raw); } catch (e) {}
            if (callback) callback(res, raw);
        });
    }

    function getTrailColorRgbaOrNull() {
        var colEl = document.getElementById("morph-trail-color");
        if (!colEl || !colEl.value) return null;
        var hex = String(colEl.value).trim().toLowerCase();
        // Default #ffffff stays null so AE uses pure default white [1, 1, 1, 1]
        if (hex === "#ffffff" || hex === "#fff") return null;
        var m = hex.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
        if (!m) return null;
        return [
            parseInt(m[1], 16) / 255,
            parseInt(m[2], 16) / 255,
            parseInt(m[3], 16) / 255,
            1
        ];
    }

    function getValById(id, fallback) {
        var el = document.getElementById(id);
        return el ? el.value : fallback;
    }

    function isCheckedById(id, fallback) {
        var el = document.getElementById(id);
        return el ? !!el.checked : !!fallback;
    }

    var MDK_CompResize = {
        getInputDims: function () {
            var w = parseInt(getValById("mdk-comp-w", "1920"), 10);
            var h = parseInt(getValById("mdk-comp-h", "1080"), 10);
            if (isNaN(w) || w <= 0 || isNaN(h) || h <= 0) return null;
            return { w: w, h: h };
        },

        setSize: function (w, h) {
            var wInput = document.getElementById("mdk-comp-w");
            var hInput = document.getElementById("mdk-comp-h");
            if (wInput) wInput.value = w;
            if (hInput) hInput.value = h;
            this.applyDimensions(w, h);
        },

        applyCustom: function () {
            var dims = this.getInputDims();
            if (!dims) {
                MDK_Toast.show("Please enter valid width and height numbers.", "error");
                return;
            }
            this.applyDimensions(dims.w, dims.h);
        },

        applyDimensions: function (w, h) {
            MDK_Toast.show("Resizing composition to " + w + " × " + h + "...", "info");
            callProHost("resizeActiveComp", [String(parseInt(w, 10)), String(parseInt(h, 10))], function (res, raw) {
                if (res && res.ok) {
                    MDK_Toast.show(res.msg || "Composition resized successfully!", "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : ("Resize error: " + raw), "error");
                }
            });
        },

        createNewComp: function () {
            var dims = this.getInputDims() || { w: 1920, h: 1080 };
            var payload = JSON.stringify({ width: dims.w, height: dims.h });
            MDK_Toast.show("Creating new " + dims.w + " × " + dims.h + " composition...", "info");
            callProHost("createNewComp", [JSON.stringify(payload)], function (res, raw) {
                if (res && res.ok) {
                    MDK_Toast.show(res.msg || "Created new composition!", "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : ("Create comp error: " + raw), "error");
                }
            });
        },

        createNewFolder: function () {
            callProHost("createProjectFolder", [JSON.stringify("{}")], function (res, raw) {
                if (res && res.ok) {
                    MDK_Toast.show(res.msg || "Created new project folder!", "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : ("Create folder error: " + raw), "error");
                }
            });
        }
    };

    // =========================================================================
    // 8B. SHAPE DASHES INTEGER CONTROLLER & SUPER MORPH WHITE-TRAIL BRIDGE
    // =========================================================================
    var MDK_ShapeDashes = {
        _timer: null,
        _busy: false,
        _pending: null,

        setInputs: function (d, g, o) {
            var dInt = Math.max(0, Math.round(parseFloat(d)));
            var gInt = Math.max(0, Math.round(parseFloat(g)));
            var oInt = Math.round(parseFloat(o));
            if (isNaN(dInt)) dInt = 10;
            if (isNaN(gInt)) gInt = 10;
            if (isNaN(oInt)) oInt = 0;

            var pairs = [
                ["shpDash", "shpDashSlider", dInt],
                ["shpGap", "shpGapSlider", gInt],
                ["shpOffset", "shpOffsetSlider", oInt]
            ];
            for (var i = 0; i < pairs.length; i++) {
                var numEl = document.getElementById(pairs[i][0]);
                var sldEl = document.getElementById(pairs[i][1]);
                if (numEl && document.activeElement !== numEl) numEl.value = String(pairs[i][2]);
                if (sldEl) sldEl.value = String(pairs[i][2]);
            }
        },

        applyDash: function (subProp, rawVal) {
            var intVal = Math.round(parseFloat(rawVal));
            if (isNaN(intVal)) intVal = (subProp === "offset") ? 0 : 10;
            if (subProp === "dash" || subProp === "gap") intVal = Math.max(0, intVal);

            if (subProp === "dash") {
                var ds = document.getElementById("shpDashSlider");
                var dn = document.getElementById("shpDash");
                if (ds) ds.value = String(intVal);
                if (dn && document.activeElement !== dn) dn.value = String(intVal);
            } else if (subProp === "gap") {
                var gs = document.getElementById("shpGapSlider");
                var gn = document.getElementById("shpGap");
                if (gs) gs.value = String(intVal);
                if (gn && document.activeElement !== gn) gn.value = String(intVal);
            } else if (subProp === "offset") {
                var os = document.getElementById("shpOffsetSlider");
                var on = document.getElementById("shpOffset");
                if (os) os.value = String(intVal);
                if (on && document.activeElement !== on) on.value = String(intVal);
            }

            var self = this;
            self._pending = { sub: subProp, val: intVal };
            if (self._timer) clearTimeout(self._timer);
            self._timer = setTimeout(function () {
                self._flushPending();
            }, 40);
        },

        _flushPending: function () {
            var self = this;
            if (self._busy || !self._pending) return;
            var job = self._pending;
            self._pending = null;
            self._busy = true;
            callProHost("setShapeDash", [JSON.stringify(job.sub), String(job.val)], function (res) {
                self._busy = false;
                if (self._pending) {
                    self._flushPending();
                } else if (res && res.ok) {
                    self.setInputs(res.dash, res.gap, res.offset);
                } else if (res && res.error && document.activeElement && (document.activeElement.id || "").indexOf("shp") === 0) {
                    MDK_Toast.show(res.error, "info");
                }
            });
        },

        syncFromAE: function () {
            var self = this;
            callProHost("getShapeDashes", [], function (res) {
                if (res && res.ok) {
                    self.setInputs(res.dash, res.gap, res.offset);
                } else {
                    self.setInputs(10, 10, 0);
                }
            });
        },

        init: function () {
            var self = this;
            self.setInputs(10, 10, 0);

            if (typeof window.runShape === "function" && !window._mdkRunShapeDashHooked) {
                var origRunShape = window.runShape;
                window.runShape = function (cat, prop, val) {
                    if (cat === "dash") {
                        self.applyDash(prop, val);
                        return;
                    }
                    return origRunShape.apply(this, arguments);
                };
                window._mdkRunShapeDashHooked = true;
            }

            if (typeof window.moveSlide === "function" && !window._mdkMoveSlideDashHooked) {
                var origMoveSlide = window.moveSlide;
                window.moveSlide = function (el, cat, prop) {
                    if (cat === "dash") {
                        self.applyDash(prop, el ? el.value : 10);
                        return;
                    }
                    return origMoveSlide.apply(this, arguments);
                };
                window._mdkMoveSlideDashHooked = true;
            }

            if (typeof window.updateShapeUI === "function" && !window._mdkUpdateShapeUIDashHooked) {
                var origUpdateShape = window.updateShapeUI;
                window.updateShapeUI = function () {
                    var r = origUpdateShape.apply(this, arguments);
                    self.syncFromAE();
                    return r;
                };
                window._mdkUpdateShapeUIDashHooked = true;
            }

            if (typeof window.openTab === "function" && !window._mdkOpenTabDashHooked) {
                var origOpenTab = window.openTab;
                window.openTab = function (tabName) {
                    var r = origOpenTab.apply(this, arguments);
                    if (tabName === "shape") {
                        setTimeout(function () { self.syncFromAE(); }, 60);
                    }
                    return r;
                };
                window._mdkOpenTabDashHooked = true;
            }

            window.addEventListener("focus", function () {
                var shapeTab = document.getElementById("shape");
                if (shapeTab && shapeTab.classList.contains("active")) {
                    self.syncFromAE();
                }
            });
        }
    };

    function setTrailColorHex(hex) {
        var norm = String(hex || "#ffffff").trim().toLowerCase();
        if (!/^#[0-9a-f]{6}$/i.test(norm)) norm = "#ffffff";
        var inp = document.getElementById("morph-trail-color");
        var btn = document.getElementById("morph-trail-color-btn");
        if (inp) inp.value = norm;
        if (btn) btn.style.background = norm;
    }

    function hsvToHex(h, s, v) {
        var c = v * s;
        var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
        var m = v - c;
        var r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        var toHex = function (n) {
            var s2 = Math.round((n + m) * 255).toString(16);
            return s2.length === 1 ? "0" + s2 : s2;
        };
        return "#" + toHex(r) + toHex(g) + toHex(b);
    }

    function hexToHsv(hex) {
        var m = String(hex || "#ffffff").match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i);
        if (!m) return { h: 0, s: 0, v: 1 };
        var r = parseInt(m[1], 16) / 255, g = parseInt(m[2], 16) / 255, b = parseInt(m[3], 16) / 255;
        var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
        var h = 0;
        if (d !== 0) {
            if (max === r) h = 60 * (((g - b) / d) % 6);
            else if (max === g) h = 60 * ((b - r) / d + 2);
            else h = 60 * ((r - g) / d + 4);
        }
        if (h < 0) h += 360;
        return { h: h, s: max === 0 ? 0 : d / max, v: max };
    }

    function installKineticMorphAndCarouselPolish() {
        // Custom CEP-safe Trail Color Picker Modal (replaces Chromium's broken <input type="color"> in macOS CEP)
        MDK_SuperMorph.openTrailColorPicker = function () {
            var curHex = (document.getElementById("morph-trail-color") && document.getElementById("morph-trail-color").value) || "#ffffff";
            var hsv = hexToHsv(curHex);

            var modal = document.getElementById("mdk-trail-cp-modal");
            if (!modal) {
                modal = document.createElement("div");
                modal.id = "mdk-trail-cp-modal";
                modal.className = "cp-modal";
                modal.style.display = "none";
                modal.innerHTML =
                    '<div class="cp-container">' +
                    '  <div class="cp-header">' +
                    '    <span>Super Morph Trail Color</span>' +
                    '    <button type="button" class="cp-close" id="mdk-tcp-close">×</button>' +
                    '  </div>' +
                    '  <div class="cp-body">' +
                    '    <div class="cp-sat-val" id="mdk-tcp-sv">' +
                    '      <div class="cp-white"></div><div class="cp-black"></div>' +
                    '      <div class="cp-cursor" id="mdk-tcp-sv-cur"></div>' +
                    '    </div>' +
                    '    <div class="cp-controls">' +
                    '      <div class="cp-hue-track" id="mdk-tcp-hue"><div class="cp-hue-cursor" id="mdk-tcp-hue-cur"></div></div>' +
                    '      <div class="cp-preview-box"><div id="mdk-tcp-preview" class="cp-preview"></div></div>' +
                    '    </div>' +
                    '    <div style="display:flex; gap:5px; margin:8px 0 6px 0; justify-content:space-between;" id="mdk-tcp-presets"></div>' +
                    '    <div class="cp-input-row">' +
                    '      <label>HEX</label>' +
                    '      <input type="text" id="mdk-tcp-hex" value="#FFFFFF">' +
                    '    </div>' +
                    '  </div>' +
                    '  <div class="cp-footer" style="display:flex; gap:6px;">' +
                    '    <button type="button" class="btn-layer" id="mdk-tcp-reset" style="flex:0.8; font-size:10px; padding:7px 4px;">White</button>' +
                    '    <button type="button" class="btn-orange" id="mdk-tcp-apply" style="flex:1.4; font-size:10px; padding:7px 4px;">Apply Color</button>' +
                    '  </div>' +
                    '</div>';
                document.body.appendChild(modal);

                var presetsEl = document.getElementById("mdk-tcp-presets");
                var swatchColors = ["#ffffff", "#ff7a00", "#00d4ff", "#ff2a85", "#ffd500", "#00e676", "#a855f7"];
                for (var pi = 0; pi < swatchColors.length; pi++) {
                    (function (colHex) {
                        var sw = document.createElement("button");
                        sw.type = "button";
                        sw.title = colHex.toUpperCase();
                        sw.style.cssText = "width:22px; height:16px; border-radius:3px; border:1px solid #555; cursor:pointer; padding:0; background:" + colHex + ";";
                        sw.onclick = function () {
                            hsv = hexToHsv(colHex);
                            renderTCP(colHex);
                        };
                        presetsEl.appendChild(sw);
                    })(swatchColors[pi]);
                }

                var svBox = document.getElementById("mdk-tcp-sv");
                var svCur = document.getElementById("mdk-tcp-sv-cur");
                var hueTrack = document.getElementById("mdk-tcp-hue");
                var hueCur = document.getElementById("mdk-tcp-hue-cur");
                var preview = document.getElementById("mdk-tcp-preview");
                var hexIn = document.getElementById("mdk-tcp-hex");

                function renderTCP(overrideHex) {
                    var hx = overrideHex || hsvToHex(hsv.h, hsv.s, hsv.v);
                    svBox.style.background = "hsl(" + Math.round(hsv.h) + ", 100%, 50%)";
                    svCur.style.left = (hsv.s * 100) + "%";
                    svCur.style.top = ((1 - hsv.v) * 100) + "%";
                    hueCur.style.left = (hsv.h / 360 * 100) + "%";
                    preview.style.background = hx;
                    hexIn.value = hx.toUpperCase();
                }
                modal._renderTCP = function (h) {
                    hsv = hexToHsv(h);
                    renderTCP(h);
                };

                function bindDrag(el, onMove) {
                    el.addEventListener("mousedown", function (ev) {
                        ev.preventDefault();
                        onMove(ev);
                        var mv = function (e2) { onMove(e2); };
                        var up = function () {
                            document.removeEventListener("mousemove", mv);
                            document.removeEventListener("mouseup", up);
                        };
                        document.addEventListener("mousemove", mv);
                        document.addEventListener("mouseup", up);
                    });
                }

                bindDrag(svBox, function (ev) {
                    var r = svBox.getBoundingClientRect();
                    hsv.s = Math.max(0, Math.min(1, (ev.clientX - r.left) / Math.max(1, r.width)));
                    hsv.v = 1 - Math.max(0, Math.min(1, (ev.clientY - r.top) / Math.max(1, r.height)));
                    renderTCP();
                });

                bindDrag(hueTrack, function (ev) {
                    var r = hueTrack.getBoundingClientRect();
                    var ratio = Math.max(0, Math.min(1, (ev.clientX - r.left) / Math.max(1, r.width)));
                    hsv.h = ratio * 360;
                    renderTCP();
                });

                hexIn.addEventListener("input", function () {
                    var val = String(hexIn.value || "").trim();
                    if (/^#[0-9a-f]{6}$/i.test(val)) {
                        hsv = hexToHsv(val);
                        preview.style.background = val;
                        svBox.style.background = "hsl(" + Math.round(hsv.h) + ", 100%, 50%)";
                        svCur.style.left = (hsv.s * 100) + "%";
                        svCur.style.top = ((1 - hsv.v) * 100) + "%";
                        hueCur.style.left = (hsv.h / 360 * 100) + "%";
                    }
                });

                document.getElementById("mdk-tcp-close").onclick = function () { modal.style.display = "none"; };
                document.getElementById("mdk-tcp-reset").onclick = function () {
                    setTrailColorHex("#ffffff");
                    modal.style.display = "none";
                    MDK_Toast.show("Trail color reset to default White (#FFFFFF)", "info");
                };
                document.getElementById("mdk-tcp-apply").onclick = function () {
                    var chosen = String(hexIn.value || "#ffffff").trim();
                    if (!/^#[0-9a-f]{6}$/i.test(chosen)) chosen = "#ffffff";
                    setTrailColorHex(chosen);
                    modal.style.display = "none";
                    MDK_Toast.show("Trail Color set: <strong>" + chosen.toUpperCase() + "</strong>", "success");
                };
                modal.addEventListener("mousedown", function (e) {
                    if (e.target === modal) modal.style.display = "none";
                });
            }

            modal.style.display = "flex";
            if (modal._renderTCP) modal._renderTCP(curHex);
        };

        // Ensure Super Morph Pro always uses Kinetic mode + White Default Trails unless color picker changed
        MDK_SuperMorph.runMorph = function () {
            var opts = {
                mode: "kinetic",
                order: getValById("morph-order", "selection"),
                durationFrames: parseInt(getValById("morph-duration", "16"), 10) || 16,
                ease: getValById("morph-ease", "snappy"),
                arcType: getValById("morph-arc", "arc_back"),
                style: getValById("morph-style", "liquid"),
                stretch: isCheckedById("morph-stretch", true),
                addTrails: isCheckedById("morph-trails", false),
                trailColor: getTrailColorRgbaOrNull(),
                trailCount: parseInt(getValById("morph-trail-count", "4"), 10) || 4,
                sliceCount: parseInt(getValById("morph-slice-count", "4"), 10) || 4
            };
            MDK_Toast.show("Running Super Morphings...", "info");
            callProHost("createSuperMorph", [JSON.stringify(JSON.stringify(opts))], function (res, raw) {
                if (res && res.ok) {
                    MDK_Toast.show(res.msg || "Super Morph Applied!", "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : ("Morph Error: " + raw), "error");
                }
            });
        };

        MDK_SuperMorph.runTrails = function () {
            var count = Math.max(1, Math.min(12, parseInt(getValById("morph-trail-count", "4"), 10) || 4));
            var opts = { count: count, color: getTrailColorRgbaOrNull() };
            MDK_Toast.show("Adding " + count + " Speed Trails...", "info");
            callProHost("addSuperTrails", [JSON.stringify(JSON.stringify(opts))], function (res, raw) {
                if (res && res.ok) {
                    MDK_Toast.show(res.msg || "Speed Trails Added!", "success");
                } else {
                    MDK_Toast.show((res && res.error) ? res.error : ("Trails Error: " + raw), "error");
                }
            });
        };

        // Smooth 3D Carousel Live Preview coalescing (prevents Classic 3D Artisan crash on fast slider drags)
        if (window.Carousel3D && !window.Carousel3D._mdkPolished) {
            window.Carousel3D._liveTimer = null;
            window.Carousel3D._c3dBusy = false;
            window.Carousel3D._c3dQueued = null;

            window.Carousel3D.onParamChange = function () {
                var cbLive = document.getElementById("c3d-live-preview");
                if (!cbLive || !cbLive.checked) return;
                if (this._liveTimer) clearTimeout(this._liveTimer);
                var self = this;
                this._liveTimer = setTimeout(function () {
                    self.update(true);
                }, 140);
            };

            var origC3dRunAction = window.Carousel3D.runAction;
            window.Carousel3D.runAction = function (actionName, isLive, callback) {
                var self = this;
                if (isLive && self._c3dBusy) {
                    self._c3dQueued = { actionName: actionName, isLive: isLive, callback: callback };
                    return;
                }
                self._c3dBusy = true;
                origC3dRunAction.call(self, actionName, isLive, function (res) {
                    self._c3dBusy = false;
                    if (callback) callback(res);
                    if (self._c3dQueued) {
                        var next = self._c3dQueued;
                        self._c3dQueued = null;
                        self.runAction(next.actionName, next.isLive, next.callback);
                    }
                });
            };
            window.Carousel3D._mdkPolished = true;
        }
    }

    // =========================================================================
    // 9. EXTENSION AUTO-ROUTER FOR NATIVE STANDALONE SUB-PANELS
    // =========================================================================
    function checkUrlRoute() {
        var query = window.location.search || window.location.hash || "";
        var match = query.match(/[?&#]tab=([a-zA-Z0-9_-]+)/);
        if (match && match[1]) {
            var targetTab = match[1];
            // Hide navbar for dedicated single-tool window
            var navbar = document.getElementById("main-navbar");
            if (navbar) navbar.style.display = "none";

            setTimeout(function () {
                if (typeof window.openTab === "function") {
                    window.openTab(targetTab);
                }
            }, 100);
        }
    }

    // =========================================================================
    // 9.5 NATIVE EFFECT AUTO-INSTALLER (LIQUID GLASS INSIDE ZXP)
    // =========================================================================
    var MDK_PluginInstaller = {
        _node: function (mod) {
            try { return (typeof require === "function") ? require(mod) : null; } catch (e) { return null; }
        },

        _shQuote: function (s) {
            return "'" + String(s || "").replace(/'/g, "'\\''") + "'";
        },

        getPaths: function (appPkgPath) {
            var fs = this._node("fs");
            var path = this._node("path");
            if (!fs || !path) return null;

            var isWin = (typeof process !== "undefined" && process.platform === "win32");
            var root = getExtensionRoot();
            if (!root) return null;

            var src = isWin
                ? path.join(root, "extra_plugins", "Windows", "ToolsForMotion", "LiquidGlass.aex")
                : path.join(root, "extra_plugins", "Mac", "ToolsForMotion", "LiquidGlass.plugin");

            var pluginsRoot = null;
            if (appPkgPath) {
                if (isWin) {
                    var winCandidate = path.join(appPkgPath, "Plug-ins");
                    if (fs.existsSync(winCandidate)) pluginsRoot = winCandidate;
                } else {
                    var aeFolder = /\.app[\\/]?$/i.test(appPkgPath) ? path.dirname(appPkgPath) : appPkgPath;
                    var macCandidate = path.join(aeFolder, "Plug-ins");
                    if (fs.existsSync(macCandidate)) pluginsRoot = macCandidate;
                }
            }

            if (!pluginsRoot) {
                var baseDir = isWin ? path.join(process.env.ProgramFiles || "C:\\Program Files", "Adobe") : "/Applications";
                try {
                    var entries = fs.readdirSync(baseDir).filter(function (n) { return /^Adobe After Effects/i.test(n); }).sort().reverse();
                    for (var i = 0; i < entries.length; i++) {
                        var cand = isWin ? path.join(baseDir, entries[i], "Support Files", "Plug-ins") : path.join(baseDir, entries[i], "Plug-ins");
                        if (fs.existsSync(cand)) { pluginsRoot = cand; break; }
                    }
                } catch (e) {}
            }

            if (!pluginsRoot) return null;
            var dstDir = path.join(pluginsRoot, "ToolsForMotion");
            var dst = path.join(dstDir, isWin ? "LiquidGlass.aex" : "LiquidGlass.plugin");
            return { isWin: isWin, src: src, dstDir: dstDir, dst: dst, srcExists: fs.existsSync(src), dstExists: fs.existsSync(dst) };
        },

        promptInstallLiquidGlass: function (appPkgPath) {
            var self = this;
            var info = self.getPaths(appPkgPath);
            if (!info || !info.srcExists) {
                if (window.MDK_System) {
                    window.MDK_System.showAlert(
                        "🌊 Liquid Glass Plugin Required",
                        "Liquid Glass plugin was not detected in After Effects.\n\nPlease install ToolsForMotion Liquid Glass into your After Effects Plug-ins folder and restart AE.",
                        false
                    );
                }
                return;
            }

            if (info.dstExists) {
                if (window.MDK_System) {
                    window.MDK_System.showAlert(
                        "✓ Restart After Effects",
                        "Liquid Glass plugin is already installed at:\n" + info.dst + "\n\nPlease restart Adobe After Effects once so it can load the effect.",
                        true
                    );
                }
                return;
            }

            if (window.MDK_System) {
                window.MDK_System.showAlert(
                    "🌊 Install Liquid Glass Plugin",
                    "Liquid Glass effect is not installed in After Effects yet.\n\nClick below to copy the bundled plugin into:\n" + info.dstDir,
                    false,
                    {
                        label: "⚡ 1-Click Install Liquid Glass",
                        cancelLabel: "Later",
                        onClick: function (btn, cancelBtn) {
                            btn.disabled = true;
                            btn.innerText = "Installing...";
                            if (cancelBtn) cancelBtn.disabled = true;
                            self.installLiquidGlass(info, function (ok, errMsg) {
                                if (cancelBtn) cancelBtn.disabled = false;
                                if (ok) {
                                    window.MDK_System.showAlert(
                                        "✓ Liquid Glass Installed!",
                                        "Installed cleanly to:\n" + info.dst + "\n\nPlease restart Adobe After Effects once, then click Liquid Glass again.",
                                        true
                                    );
                                } else {
                                    btn.disabled = false;
                                    btn.innerText = "⚡ Retry Install Liquid Glass";
                                    if (window.MDK_Toast) window.MDK_Toast.show(errMsg || "Installation cancelled or failed.", "error");
                                }
                            });
                        }
                    }
                );
            }
        },

        installLiquidGlass: function (info, callback) {
            var fs = this._node("fs");
            var cp = this._node("child_process");
            var self = this;
            if (!fs || !cp || !info) {
                callback(false, "Installer API unavailable.");
                return;
            }

            if (info.isWin) {
                try {
                    if (!fs.existsSync(info.dstDir)) fs.mkdirSync(info.dstDir, { recursive: true });
                    fs.copyFileSync(info.src, info.dst);
                    if (fs.existsSync(info.dst)) { callback(true); return; }
                } catch (e) {}

                var psEsc = function (s) { return String(s).replace(/'/g, "''"); };
                var innerCmd = "New-Item -ItemType Directory -Force -Path '" + psEsc(info.dstDir) + "' | Out-Null; Copy-Item -Force -LiteralPath '" + psEsc(info.src) + "' -Destination '" + psEsc(info.dst) + "'";
                var enc = (typeof Buffer !== "undefined") ? Buffer.from(innerCmd, "utf16le").toString("base64") : "";
                var runPs = enc
                    ? ("Start-Process powershell.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand','" + enc + "'")
                    : ("Start-Process cmd.exe -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '/c','mkdir \"" + info.dstDir + "\" & copy /Y \"" + info.src + "\" \"" + info.dst + "\"'");
                cp.execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", runPs], { windowsHide: true }, function (err) {
                    if (!err && fs.existsSync(info.dst)) callback(true);
                    else callback(false, "Admin permission is required to write to After Effects Plug-ins.");
                });
                return;
            }

            var shCmd = "mkdir -p " + self._shQuote(info.dstDir) +
                " && rm -rf " + self._shQuote(info.dst) +
                " && cp -R " + self._shQuote(info.src) + " " + self._shQuote(info.dst) +
                " && (xattr -dr com.apple.quarantine " + self._shQuote(info.dst) + " >/dev/null 2>&1 || true)";

            try {
                cp.execFileSync("/bin/sh", ["-c", shCmd]);
                if (fs.existsSync(info.dst)) { callback(true); return; }
            } catch (e) {}

            var asScript = 'do shell script "' + shCmd.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '" with administrator privileges';
            cp.execFile("osascript", ["-e", asScript], function (err) {
                if (!err && fs.existsSync(info.dst)) callback(true);
                else callback(false, "Admin permission cancelled or failed.");
            });
        }
    };

    // =========================================================================
    // 10. GLOBAL EXPOSURE & BOOTSTRAP
    // =========================================================================
    window.MDK_Toast = MDK_Toast;
    window.MDK_ThemeEngine = MDK_ThemeEngine;
    window.MDK_GraphEngine = MDK_GraphEngine;
    window.MDK_DualView = MDK_DualView;
    window.MDK_Layout = MDK_Layout;
    window.MDK_Clipboard = MDK_Clipboard;
    window.MDK_SuperMorph = MDK_SuperMorph;
    window.MDK_CompResize = MDK_CompResize;
    window.MDK_ShapeDashes = MDK_ShapeDashes;
    window.MDK_PluginInstaller = MDK_PluginInstaller;

    function boot() {
        MDK_Toast.init();
        MDK_ThemeEngine.init();
        MDK_GraphEngine.init();
        MDK_DualView.init();
        MDK_Layout.init();
        installKineticMorphAndCarouselPolish();
        MDK_ShapeDashes.init();
        checkUrlRoute();

        // Eagerly pre-load ProFeatures.jsx so all features (incl. Dashes, Comp/Folder) are hot-ready
        if (cs) {
            try {
                var hp = getHostScriptPath();
                if (hp) {
                    cs.evalScript('(function(){ try { if (typeof $._MDK_PRO === "undefined" || !$._MDK_PRO.setShapeDash || !$._MDK_PRO.createNewComp) { var f = new File(' + JSON.stringify(hp) + '); if (f.exists) $.evalFile(f); } } catch(e){} })();');
                }
            } catch (e) { }
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", boot);
    } else {
        setTimeout(boot, 100);
    }

})(window, document);
