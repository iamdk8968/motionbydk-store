MotionByDk Free Starter Pack
===============================
Included in this package:
1. MotionByDk_3D_Carousel_Automation.jsx (3D Rotating layer automation script)
2. MotionByDk_Scale_Fade_Tool.jsx (Instant Scale & Fade in/out animation script)
3. Cinematic SFX Pack Open Drive Link Below
https://drive.google.com/drive/folders/1_9C3Ic0YvY7F4nMuiSYhQai6OzeAGwKV
4. MotionByDk_Installation_Guide.pdf (Step-by-step setup guide for Windows & Mac)

Installation:
1. Open Adobe After Effects.
2. Go to File -> Scripts -> Run Script File...
3. Select any .jsx script and enjoy!
For permanent dock installation, read MotionByDk_Installation_Guide.pdf.

Need the full Pro Extension or 50GB 4K Video Editing Vault?
Visit: https://www.motionbydk.in
Support: support@motionbydk.in
Instagram: @motionbydk
